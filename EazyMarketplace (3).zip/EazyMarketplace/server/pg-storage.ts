import { eq, count, and, desc, asc, sql } from 'drizzle-orm';
import { db } from './db';
import { IStorage } from './storage';
import * as schema from '../shared/schema';
import { 
  users, products, categories, services, orders, conversations, 
  messages, blogs, groups, events, jobs, pointsTransactions, 
  notifications, groupMembers, eventAttendees, conversationParticipants,
  InsertUser, User, InsertProduct, Product, InsertCategory, Category,
  InsertService, Service, InsertOrder, Order, InsertConversation, Conversation,
  InsertMessage, Message, InsertBlog, Blog, InsertGroup, Group,
  InsertEvent, Event, InsertJob, Job, InsertPointsTransaction,
  PointsTransaction, InsertNotification, Notification
} from '../shared/schema';
import bcrypt from 'bcryptjs';

function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w\-]+/g, '')
    .replace(/\-\-+/g, '-');
}

function generateReferralCode(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

export class PgStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return results[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return results[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return results[0];
  }

  async getUserByReferralCode(referralCode: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.referralCode, referralCode)).limit(1);
    return results[0];
  }

  async createUser(userData: InsertUser, referralCode?: string): Promise<User> {
    // Hash the password
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    
    // Generate a unique referral code
    const userReferralCode = generateReferralCode();
    
    const newUser = {
      ...userData,
      password: hashedPassword,
      referralCode: userReferralCode,
      points: 100, // Default starting points
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(users).values(newUser).returning();
    
    // If referral code provided, update referrer's points
    if (referralCode) {
      const referrer = await this.getUserByReferralCode(referralCode);
      if (referrer) {
        await this.updateUserPoints(referrer.id, referrer.points + 50);
      }
    }
    
    return result[0];
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const updateData = {
      ...data,
      updatedAt: new Date()
    };
    
    const result = await db.update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    
    return result[0];
  }

  async updateUserPoints(id: number, points: number): Promise<User | undefined> {
    const result = await db.update(users)
      .set({
        points,
        updatedAt: new Date()
      })
      .where(eq(users.id, id))
      .returning();
    
    return result[0];
  }

  // Product operations
  async getProducts(limit = 20, offset = 0): Promise<Product[]> {
    return db.select()
      .from(products)
      .where(eq(products.status, 'active'))
      .limit(limit)
      .offset(offset)
      .orderBy(desc(products.createdAt));
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return db.select()
      .from(products)
      .where(and(
        eq(products.categoryId, categoryId),
        eq(products.status, 'active')
      ))
      .orderBy(desc(products.createdAt));
  }

  async getProductsByUser(userId: number): Promise<Product[]> {
    return db.select()
      .from(products)
      .where(eq(products.userId, userId))
      .orderBy(desc(products.createdAt));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const results = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return results[0];
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const results = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
    return results[0];
  }

  async createProduct(productData: InsertProduct): Promise<Product> {
    // Generate slug from title
    const slug = slugify(productData.title);
    
    const newProduct = {
      ...productData,
      slug,
      views: 0,
      favorites: 0,
      status: 'active',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(products).values(newProduct).returning();
    return result[0];
  }

  async updateProduct(id: number, data: Partial<Product>): Promise<Product | undefined> {
    // If title is updated, regenerate the slug
    let updateData = { ...data };
    if (data.title) {
      updateData.slug = slugify(data.title);
    }
    
    updateData.updatedAt = new Date();
    
    const result = await db.update(products)
      .set(updateData)
      .where(eq(products.id, id))
      .returning();
    
    return result[0];
  }

  async incrementProductViews(id: number): Promise<Product | undefined> {
    const product = await this.getProduct(id);
    if (!product) return undefined;
    
    const result = await db.update(products)
      .set({
        views: product.views + 1,
        updatedAt: new Date()
      })
      .where(eq(products.id, id))
      .returning();
    
    return result[0];
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.update(products)
      .set({
        status: 'deleted',
        updatedAt: new Date()
      })
      .where(eq(products.id, id))
      .returning();
    
    return result.length > 0;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories).orderBy(asc(categories.name));
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const results = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
    return results[0];
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const results = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
    return results[0];
  }

  async createCategory(categoryData: InsertCategory): Promise<Category> {
    // Generate slug from name
    const slug = slugify(categoryData.name);
    
    const newCategory = {
      ...categoryData,
      slug,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(categories).values(newCategory).returning();
    return result[0];
  }

  // Service operations
  async getServices(limit = 20, offset = 0): Promise<Service[]> {
    return db.select()
      .from(services)
      .where(eq(services.status, 'active'))
      .limit(limit)
      .offset(offset)
      .orderBy(desc(services.createdAt));
  }

  async getServicesByCategory(categoryId: number): Promise<Service[]> {
    return db.select()
      .from(services)
      .where(and(
        eq(services.categoryId, categoryId),
        eq(services.status, 'active')
      ))
      .orderBy(desc(services.createdAt));
  }

  async getServicesByUser(userId: number): Promise<Service[]> {
    return db.select()
      .from(services)
      .where(eq(services.userId, userId))
      .orderBy(desc(services.createdAt));
  }

  async getService(id: number): Promise<Service | undefined> {
    const results = await db.select().from(services).where(eq(services.id, id)).limit(1);
    return results[0];
  }

  async createService(serviceData: InsertService): Promise<Service> {
    // Generate slug from title
    const slug = slugify(serviceData.title);
    
    const newService = {
      ...serviceData,
      slug,
      status: 'active',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(services).values(newService).returning();
    return result[0];
  }

  async updateService(id: number, data: Partial<Service>): Promise<Service | undefined> {
    // If title is updated, regenerate the slug
    let updateData = { ...data };
    if (data.title) {
      updateData.slug = slugify(data.title);
    }
    
    updateData.updatedAt = new Date();
    
    const result = await db.update(services)
      .set(updateData)
      .where(eq(services.id, id))
      .returning();
    
    return result[0];
  }

  async deleteService(id: number): Promise<boolean> {
    const result = await db.update(services)
      .set({
        status: 'deleted',
        updatedAt: new Date()
      })
      .where(eq(services.id, id))
      .returning();
    
    return result.length > 0;
  }

  // Order operations
  async getOrders(): Promise<Order[]> {
    return db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrdersByBuyer(buyerId: number): Promise<Order[]> {
    return db.select()
      .from(orders)
      .where(eq(orders.buyerId, buyerId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrdersBySeller(sellerId: number): Promise<Order[]> {
    return db.select()
      .from(orders)
      .where(eq(orders.sellerId, sellerId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const results = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
    return results[0];
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const newOrder = {
      ...orderData,
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(orders).values(newOrder).returning();
    return result[0];
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const result = await db.update(orders)
      .set({
        status,
        updatedAt: new Date()
      })
      .where(eq(orders.id, id))
      .returning();
    
    return result[0];
  }

  // Conversation operations
  async getConversations(): Promise<Conversation[]> {
    return db.select().from(conversations).orderBy(desc(conversations.updatedAt));
  }

  async getConversationsByUser(userId: number): Promise<Conversation[]> {
    // Join with conversationParticipants to get conversations where user is a participant
    const subquery = db.select({ conversationId: conversationParticipants.conversationId })
      .from(conversationParticipants)
      .where(eq(conversationParticipants.userId, userId));
    
    return db.select()
      .from(conversations)
      .where(sql`${conversations.id} IN (${subquery})`)
      .orderBy(desc(conversations.updatedAt));
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    const results = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
    return results[0];
  }

  async createConversation(conversationData: InsertConversation): Promise<Conversation> {
    const newConversation = {
      ...conversationData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(conversations).values(newConversation).returning();
    return result[0];
  }

  async addParticipantToConversation(conversationId: number, userId: number): Promise<boolean> {
    try {
      await db.insert(conversationParticipants).values({
        conversationId,
        userId,
        createdAt: new Date()
      });
      return true;
    } catch (error) {
      console.error('Error adding participant to conversation:', error);
      return false;
    }
  }

  // Message operations
  async getMessages(conversationId: number): Promise<Message[]> {
    return db.select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(asc(messages.createdAt));
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const newMessage = {
      ...messageData,
      isRead: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(messages).values(newMessage).returning();
    
    // Update conversation's updatedAt timestamp
    await db.update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, messageData.conversationId));
    
    return result[0];
  }

  async markMessagesAsRead(conversationId: number, userId: number): Promise<boolean> {
    try {
      await db.update(messages)
        .set({ isRead: true, updatedAt: new Date() })
        .where(and(
          eq(messages.conversationId, conversationId),
          eq(messages.receiverId, userId),
          eq(messages.isRead, false)
        ));
      return true;
    } catch (error) {
      console.error('Error marking messages as read:', error);
      return false;
    }
  }

  // Blog operations
  async getBlogs(limit = 20, offset = 0): Promise<Blog[]> {
    return db.select()
      .from(blogs)
      .limit(limit)
      .offset(offset)
      .orderBy(desc(blogs.createdAt));
  }

  async getBlogsByUser(userId: number): Promise<Blog[]> {
    return db.select()
      .from(blogs)
      .where(eq(blogs.userId, userId))
      .orderBy(desc(blogs.createdAt));
  }

  async getBlog(id: number): Promise<Blog | undefined> {
    const results = await db.select().from(blogs).where(eq(blogs.id, id)).limit(1);
    return results[0];
  }

  async getBlogBySlug(slug: string): Promise<Blog | undefined> {
    const results = await db.select().from(blogs).where(eq(blogs.slug, slug)).limit(1);
    return results[0];
  }

  async createBlog(blogData: InsertBlog): Promise<Blog> {
    // Generate slug from title
    const slug = slugify(blogData.title);
    
    const newBlog = {
      ...blogData,
      slug,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(blogs).values(newBlog).returning();
    return result[0];
  }

  async updateBlog(id: number, data: Partial<Blog>): Promise<Blog | undefined> {
    // If title is updated, regenerate the slug
    let updateData = { ...data };
    if (data.title) {
      updateData.slug = slugify(data.title);
    }
    
    updateData.updatedAt = new Date();
    
    const result = await db.update(blogs)
      .set(updateData)
      .where(eq(blogs.id, id))
      .returning();
    
    return result[0];
  }

  async deleteBlog(id: number): Promise<boolean> {
    const result = await db.delete(blogs).where(eq(blogs.id, id)).returning();
    return result.length > 0;
  }

  // Group operations
  async getGroups(limit = 20, offset = 0): Promise<Group[]> {
    return db.select()
      .from(groups)
      .limit(limit)
      .offset(offset)
      .orderBy(desc(groups.createdAt));
  }

  async getGroupsByUser(userId: number): Promise<Group[]> {
    // Join with groupMembers to get groups where user is a member
    const subquery = db.select({ groupId: groupMembers.groupId })
      .from(groupMembers)
      .where(eq(groupMembers.userId, userId));
    
    return db.select()
      .from(groups)
      .where(sql`${groups.id} IN (${subquery})`)
      .orderBy(desc(groups.createdAt));
  }

  async getGroup(id: number): Promise<Group | undefined> {
    const results = await db.select().from(groups).where(eq(groups.id, id)).limit(1);
    return results[0];
  }

  async createGroup(groupData: InsertGroup): Promise<Group> {
    // Generate slug from name
    const slug = slugify(groupData.name);
    
    const newGroup = {
      ...groupData,
      slug,
      memberCount: 1, // Creator counts as first member
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(groups).values(newGroup).returning();
    
    // Add creator as a member with 'admin' role
    await this.addMemberToGroup(result[0].id, groupData.creatorId, 'admin');
    
    return result[0];
  }

  async addMemberToGroup(groupId: number, userId: number, role = 'member'): Promise<boolean> {
    try {
      await db.insert(groupMembers).values({
        groupId,
        userId,
        role,
        createdAt: new Date()
      });
      
      // Increment member count if not the creator (who was already counted)
      if (role !== 'admin') {
        await this.incrementGroupMembers(groupId);
      }
      
      return true;
    } catch (error) {
      console.error('Error adding member to group:', error);
      return false;
    }
  }

  async incrementGroupMembers(groupId: number): Promise<Group | undefined> {
    const group = await this.getGroup(groupId);
    if (!group) return undefined;
    
    const result = await db.update(groups)
      .set({
        memberCount: group.memberCount + 1,
        updatedAt: new Date()
      })
      .where(eq(groups.id, groupId))
      .returning();
    
    return result[0];
  }

  // Event operations
  async getEvents(limit = 20, offset = 0): Promise<Event[]> {
    return db.select()
      .from(events)
      .limit(limit)
      .offset(offset)
      .orderBy(asc(events.startDate));
  }

  async getEventsByUser(userId: number): Promise<Event[]> {
    // Return events created by the user or events they're attending
    const createdEvents = await db.select()
      .from(events)
      .where(eq(events.creatorId, userId))
      .orderBy(asc(events.startDate));
    
    const attendingSubquery = db.select({ eventId: eventAttendees.eventId })
      .from(eventAttendees)
      .where(eq(eventAttendees.userId, userId));
    
    const attendingEvents = await db.select()
      .from(events)
      .where(sql`${events.id} IN (${attendingSubquery})`)
      .orderBy(asc(events.startDate));
    
    // Combine and deduplicate
    const combinedEvents = [...createdEvents, ...attendingEvents];
    const dedupEvents = combinedEvents.reduce((acc, current) => {
      const x = acc.find(item => item.id === current.id);
      if (!x) {
        return acc.concat([current]);
      } else {
        return acc;
      }
    }, [] as Event[]);
    
    return dedupEvents;
  }

  async getEvent(id: number): Promise<Event | undefined> {
    const results = await db.select().from(events).where(eq(events.id, id)).limit(1);
    return results[0];
  }

  async createEvent(eventData: InsertEvent): Promise<Event> {
    // Generate slug from title
    const slug = slugify(eventData.title);
    
    const newEvent = {
      ...eventData,
      slug,
      attendeeCount: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(events).values(newEvent).returning();
    return result[0];
  }

  async addAttendeeToEvent(eventId: number, userId: number): Promise<boolean> {
    try {
      await db.insert(eventAttendees).values({
        eventId,
        userId,
        createdAt: new Date()
      });
      
      await this.incrementEventAttendees(eventId);
      return true;
    } catch (error) {
      console.error('Error adding attendee to event:', error);
      return false;
    }
  }

  async incrementEventAttendees(eventId: number): Promise<Event | undefined> {
    const event = await this.getEvent(eventId);
    if (!event) return undefined;
    
    const result = await db.update(events)
      .set({
        attendeeCount: event.attendeeCount + 1,
        updatedAt: new Date()
      })
      .where(eq(events.id, eventId))
      .returning();
    
    return result[0];
  }

  // Job operations
  async getJobs(limit = 20, offset = 0): Promise<Job[]> {
    return db.select()
      .from(jobs)
      .where(eq(jobs.status, 'active'))
      .limit(limit)
      .offset(offset)
      .orderBy(desc(jobs.createdAt));
  }

  async getJobsByUser(userId: number): Promise<Job[]> {
    return db.select()
      .from(jobs)
      .where(eq(jobs.userId, userId))
      .orderBy(desc(jobs.createdAt));
  }

  async getJob(id: number): Promise<Job | undefined> {
    const results = await db.select().from(jobs).where(eq(jobs.id, id)).limit(1);
    return results[0];
  }

  async createJob(jobData: InsertJob): Promise<Job> {
    const newJob = {
      ...jobData,
      status: 'active',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const result = await db.insert(jobs).values(newJob).returning();
    return result[0];
  }

  async updateJobStatus(id: number, status: string): Promise<Job | undefined> {
    const result = await db.update(jobs)
      .set({
        status,
        updatedAt: new Date()
      })
      .where(eq(jobs.id, id))
      .returning();
    
    return result[0];
  }

  // Points operations
  async createPointsTransaction(transactionData: InsertPointsTransaction): Promise<PointsTransaction> {
    const newTransaction = {
      ...transactionData,
      createdAt: new Date()
    };
    
    const result = await db.insert(pointsTransactions).values(newTransaction).returning();
    
    // Update user's points balance
    const user = await this.getUser(transactionData.userId);
    if (user) {
      const newPointsBalance = user.points + transactionData.points;
      await this.updateUserPoints(user.id, newPointsBalance);
    }
    
    return result[0];
  }

  async getPointsTransactionsByUser(userId: number): Promise<PointsTransaction[]> {
    return db.select()
      .from(pointsTransactions)
      .where(eq(pointsTransactions.userId, userId))
      .orderBy(desc(pointsTransactions.createdAt));
  }

  // Notification operations
  async getNotificationsByUser(userId: number): Promise<Notification[]> {
    return db.select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const newNotification = {
      ...notificationData,
      isRead: false,
      createdAt: new Date()
    };
    
    const result = await db.insert(notifications).values(newNotification).returning();
    return result[0];
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const result = await db.update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    
    return result[0];
  }
}

export const pgStorage = new PgStorage();