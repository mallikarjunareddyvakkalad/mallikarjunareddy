import { 
  users, products, categories, services, orders, conversations, messages,
  blogs, groups, events, jobs, pointsTransactions, notifications, userBadges,
  userSocialLinks, userLoginStreaks, groupMembers, eventAttendees, conversationParticipants,
  type User, type InsertUser, type Product, type InsertProduct, type Category, 
  type InsertCategory, type Service, type InsertService, type Order, type InsertOrder,
  type Conversation, type InsertConversation, type Message, type InsertMessage,
  type Blog, type InsertBlog, type Group, type InsertGroup, type Event, type InsertEvent,
  type Job, type InsertJob, type PointsTransaction, type InsertPointsTransaction,
  type Notification, type InsertNotification
} from "@shared/schema";
import { v4 as uuidv4 } from 'uuid';
import * as crypto from 'crypto';

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByReferralCode(referralCode: string): Promise<User | undefined>;
  createUser(user: InsertUser, referralCode?: string): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  updateUserPoints(id: number, points: number): Promise<User | undefined>;
  
  // Product operations
  getProducts(limit?: number, offset?: number): Promise<Product[]>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getProductsByUser(userId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, data: Partial<Product>): Promise<Product | undefined>;
  incrementProductViews(id: number): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Service operations
  getServices(limit?: number, offset?: number): Promise<Service[]>;
  getServicesByCategory(categoryId: number): Promise<Service[]>;
  getServicesByUser(userId: number): Promise<Service[]>;
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, data: Partial<Service>): Promise<Service | undefined>;
  deleteService(id: number): Promise<boolean>;
  
  // Order operations
  getOrders(): Promise<Order[]>;
  getOrdersByBuyer(buyerId: number): Promise<Order[]>;
  getOrdersBySeller(sellerId: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Conversation operations
  getConversations(): Promise<Conversation[]>;
  getConversationsByUser(userId: number): Promise<Conversation[]>;
  getConversation(id: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  addParticipantToConversation(conversationId: number, userId: number): Promise<boolean>;
  
  // Message operations
  getMessages(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessagesAsRead(conversationId: number, userId: number): Promise<boolean>;
  
  // Blog operations
  getBlogs(limit?: number, offset?: number): Promise<Blog[]>;
  getBlogsByUser(userId: number): Promise<Blog[]>;
  getBlog(id: number): Promise<Blog | undefined>;
  getBlogBySlug(slug: string): Promise<Blog | undefined>;
  createBlog(blog: InsertBlog): Promise<Blog>;
  updateBlog(id: number, data: Partial<Blog>): Promise<Blog | undefined>;
  deleteBlog(id: number): Promise<boolean>;
  
  // Group operations
  getGroups(limit?: number, offset?: number): Promise<Group[]>;
  getGroupsByUser(userId: number): Promise<Group[]>;
  getGroup(id: number): Promise<Group | undefined>;
  createGroup(group: InsertGroup): Promise<Group>;
  addMemberToGroup(groupId: number, userId: number, role?: string): Promise<boolean>;
  incrementGroupMembers(groupId: number): Promise<Group | undefined>;
  
  // Event operations
  getEvents(limit?: number, offset?: number): Promise<Event[]>;
  getEventsByUser(userId: number): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  addAttendeeToEvent(eventId: number, userId: number): Promise<boolean>;
  incrementEventAttendees(eventId: number): Promise<Event | undefined>;
  
  // Job operations
  getJobs(limit?: number, offset?: number): Promise<Job[]>;
  getJobsByUser(userId: number): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJobStatus(id: number, status: string): Promise<Job | undefined>;
  
  // Points operations
  createPointsTransaction(transaction: InsertPointsTransaction): Promise<PointsTransaction>;
  getPointsTransactionsByUser(userId: number): Promise<PointsTransaction[]>;
  
  // Notification operations
  getNotificationsByUser(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
}

// Utility functions
function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^\w\-]+/g, '')
    .replace(/\-\-+/g, '-')
    .replace(/^-+/, '')
    .replace(/-+$/, '') + '-' + Math.floor(Math.random() * 1000);
}

function generateReferralCode(): string {
  return crypto.randomBytes(4).toString('hex').toUpperCase();
}

export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private productsMap: Map<number, Product>;
  private categoriesMap: Map<number, Category>;
  private servicesMap: Map<number, Service>;
  private ordersMap: Map<number, Order>;
  private conversationsMap: Map<number, Conversation>;
  private messagesMap: Map<number, Message>;
  private blogsMap: Map<number, Blog>;
  private groupsMap: Map<number, Group>;
  private eventsMap: Map<number, Event>;
  private jobsMap: Map<number, Job>;
  private pointsTransactionsMap: Map<number, PointsTransaction>;
  private notificationsMap: Map<number, Notification>;
  private userBadgesMap: Map<number, any>;
  private userSocialLinksMap: Map<number, any>;
  private userLoginStreaksMap: Map<number, any>;
  private groupMembersMap: Map<number, any>;
  private eventAttendeesMap: Map<number, any>;
  private conversationParticipantsMap: Map<number, any>;
  
  private currentIds: {
    users: number;
    products: number;
    categories: number;
    services: number;
    orders: number;
    conversations: number;
    messages: number;
    blogs: number;
    groups: number;
    events: number;
    jobs: number;
    pointsTransactions: number;
    notifications: number;
    userBadges: number;
    userSocialLinks: number;
    userLoginStreaks: number;
    groupMembers: number;
    eventAttendees: number;
    conversationParticipants: number;
  };

  constructor() {
    this.usersMap = new Map();
    this.productsMap = new Map();
    this.categoriesMap = new Map();
    this.servicesMap = new Map();
    this.ordersMap = new Map();
    this.conversationsMap = new Map();
    this.messagesMap = new Map();
    this.blogsMap = new Map();
    this.groupsMap = new Map();
    this.eventsMap = new Map();
    this.jobsMap = new Map();
    this.pointsTransactionsMap = new Map();
    this.notificationsMap = new Map();
    this.userBadgesMap = new Map();
    this.userSocialLinksMap = new Map();
    this.userLoginStreaksMap = new Map();
    this.groupMembersMap = new Map();
    this.eventAttendeesMap = new Map();
    this.conversationParticipantsMap = new Map();
    
    this.currentIds = {
      users: 1,
      products: 1,
      categories: 1,
      services: 1,
      orders: 1,
      conversations: 1,
      messages: 1,
      blogs: 1,
      groups: 1,
      events: 1,
      jobs: 1,
      pointsTransactions: 1,
      notifications: 1,
      userBadges: 1,
      userSocialLinks: 1,
      userLoginStreaks: 1,
      groupMembers: 1,
      eventAttendees: 1,
      conversationParticipants: 1
    };
    
    // Initialize with some categories
    const categories = [
      { name: 'Electronics', slug: 'electronics', icon: 'ri-smartphone-line' },
      { name: 'Fashion', slug: 'fashion', icon: 'ri-t-shirt-line' },
      { name: 'Home', slug: 'home', icon: 'ri-home-4-line' },
      { name: 'Services', slug: 'services', icon: 'ri-service-line' },
      { name: 'Jobs', slug: 'jobs', icon: 'ri-briefcase-4-line' },
      { name: 'Digital Products', slug: 'digital-products', icon: 'ri-file-code-line' }
    ];
    
    categories.forEach(cat => {
      this.createCategory({
        name: cat.name,
        slug: cat.slug,
        icon: cat.icon
      });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }
  
  async getUserByReferralCode(referralCode: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.referralCode === referralCode
    );
  }

  async createUser(userData: InsertUser, referralCode?: string): Promise<User> {
    const id = this.currentIds.users++;
    const now = new Date();
    const userReferralCode = generateReferralCode();
    
    let referredBy: number | null = null;
    if (referralCode) {
      const referrer = await this.getUserByReferralCode(referralCode);
      if (referrer) {
        referredBy = referrer.id;
      }
    }

    const user: User = {
      ...userData,
      id,
      referralCode: userReferralCode,
      referredBy: referredBy || undefined,
      points: 2, // Initial points for signup
      status: 'active',
      createdAt: now,
      updatedAt: now
    };
    
    this.usersMap.set(id, user);
    
    // Add points transaction for signup
    await this.createPointsTransaction({
      userId: id,
      amount: 2,
      type: 'signup',
      description: 'Points awarded for signup'
    });

    // If user was referred, add points to referrer
    if (referredBy) {
      await this.updateUserPoints(referredBy, 2);
      await this.createPointsTransaction({
        userId: referredBy,
        amount: 2,
        type: 'referral',
        referenceId: id.toString(),
        description: `Points awarded for referring ${userData.username}`
      });
    }
    
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.usersMap.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data, updatedAt: new Date() };
    this.usersMap.set(id, updatedUser);
    
    return updatedUser;
  }
  
  async updateUserPoints(id: number, points: number): Promise<User | undefined> {
    const user = this.usersMap.get(id);
    if (!user) return undefined;
    
    const updatedUser = { 
      ...user, 
      points: user.points + points,
      updatedAt: new Date() 
    };
    this.usersMap.set(id, updatedUser);
    
    return updatedUser;
  }

  // Product operations
  async getProducts(limit?: number, offset = 0): Promise<Product[]> {
    const products = Array.from(this.productsMap.values())
      .filter(product => product.status === 'active')
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    if (limit) {
      return products.slice(offset, offset + limit);
    }
    
    return products;
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.productsMap.values())
      .filter(product => product.categoryId === categoryId && product.status === 'active')
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getProductsByUser(userId: number): Promise<Product[]> {
    return Array.from(this.productsMap.values())
      .filter(product => product.sellerId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.productsMap.get(id);
  }
  
  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.productsMap.values()).find(
      (product) => product.slug === slug
    );
  }

  async createProduct(productData: InsertProduct): Promise<Product> {
    const id = this.currentIds.products++;
    const now = new Date();
    const slug = slugify(productData.title);

    const product: Product = {
      ...productData,
      id,
      slug,
      views: 0,
      status: 'active',
      createdAt: now,
      updatedAt: now
    };
    
    this.productsMap.set(id, product);
    return product;
  }

  async updateProduct(id: number, data: Partial<Product>): Promise<Product | undefined> {
    const product = this.productsMap.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { ...product, ...data, updatedAt: new Date() };
    this.productsMap.set(id, updatedProduct);
    
    return updatedProduct;
  }
  
  async incrementProductViews(id: number): Promise<Product | undefined> {
    const product = this.productsMap.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { 
      ...product,
      views: product.views + 1,
      updatedAt: new Date()
    };
    this.productsMap.set(id, updatedProduct);
    
    return updatedProduct;
  }
  
  async deleteProduct(id: number): Promise<boolean> {
    const product = this.productsMap.get(id);
    if (!product) return false;
    
    const updatedProduct = { 
      ...product,
      status: 'deleted',
      updatedAt: new Date()
    };
    this.productsMap.set(id, updatedProduct);
    
    return true;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categoriesMap.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categoriesMap.get(id);
  }
  
  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categoriesMap.values()).find(
      (category) => category.slug === slug
    );
  }

  async createCategory(categoryData: InsertCategory): Promise<Category> {
    const id = this.currentIds.categories++;
    const now = new Date();

    const category: Category = {
      ...categoryData,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.categoriesMap.set(id, category);
    return category;
  }
  
  // Service operations
  async getServices(limit?: number, offset = 0): Promise<Service[]> {
    const services = Array.from(this.servicesMap.values())
      .filter(service => service.status === 'active')
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    if (limit) {
      return services.slice(offset, offset + limit);
    }
    
    return services;
  }

  async getServicesByCategory(categoryId: number): Promise<Service[]> {
    return Array.from(this.servicesMap.values())
      .filter(service => service.categoryId === categoryId && service.status === 'active')
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getServicesByUser(userId: number): Promise<Service[]> {
    return Array.from(this.servicesMap.values())
      .filter(service => service.sellerId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getService(id: number): Promise<Service | undefined> {
    return this.servicesMap.get(id);
  }

  async createService(serviceData: InsertService): Promise<Service> {
    const id = this.currentIds.services++;
    const now = new Date();
    const slug = slugify(serviceData.title);

    const service: Service = {
      ...serviceData,
      id,
      slug,
      views: 0,
      status: 'active',
      createdAt: now,
      updatedAt: now
    };
    
    this.servicesMap.set(id, service);
    return service;
  }

  async updateService(id: number, data: Partial<Service>): Promise<Service | undefined> {
    const service = this.servicesMap.get(id);
    if (!service) return undefined;
    
    const updatedService = { ...service, ...data, updatedAt: new Date() };
    this.servicesMap.set(id, updatedService);
    
    return updatedService;
  }
  
  async deleteService(id: number): Promise<boolean> {
    const service = this.servicesMap.get(id);
    if (!service) return false;
    
    const updatedService = { 
      ...service,
      status: 'deleted',
      updatedAt: new Date()
    };
    this.servicesMap.set(id, updatedService);
    
    return true;
  }
  
  // Order operations
  async getOrders(): Promise<Order[]> {
    return Array.from(this.ordersMap.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getOrdersByBuyer(buyerId: number): Promise<Order[]> {
    return Array.from(this.ordersMap.values())
      .filter(order => order.buyerId === buyerId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getOrdersBySeller(sellerId: number): Promise<Order[]> {
    return Array.from(this.ordersMap.values())
      .filter(order => order.sellerId === sellerId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.ordersMap.get(id);
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.currentIds.orders++;
    const now = new Date();

    const order: Order = {
      ...orderData,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.ordersMap.set(id, order);
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.ordersMap.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { 
      ...order,
      status,
      updatedAt: new Date()
    };
    this.ordersMap.set(id, updatedOrder);
    
    return updatedOrder;
  }
  
  // Conversation operations
  async getConversations(): Promise<Conversation[]> {
    return Array.from(this.conversationsMap.values())
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getConversationsByUser(userId: number): Promise<Conversation[]> {
    const participantEntries = Array.from(this.conversationParticipantsMap.values())
      .filter(participant => participant.userId === userId);
    
    const conversationIds = participantEntries.map(entry => entry.conversationId);
    
    return Array.from(this.conversationsMap.values())
      .filter(conversation => conversationIds.includes(conversation.id))
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversationsMap.get(id);
  }

  async createConversation(conversationData: InsertConversation): Promise<Conversation> {
    const id = this.currentIds.conversations++;
    const now = new Date();

    const conversation: Conversation = {
      ...conversationData,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.conversationsMap.set(id, conversation);
    
    // Add creator as participant
    if (conversationData.createdBy) {
      await this.addParticipantToConversation(id, conversationData.createdBy);
    }
    
    return conversation;
  }

  async addParticipantToConversation(conversationId: number, userId: number): Promise<boolean> {
    const conversation = this.conversationsMap.get(conversationId);
    const user = this.usersMap.get(userId);
    
    if (!conversation || !user) return false;
    
    const id = this.currentIds.conversationParticipants++;
    const now = new Date();
    
    const participant = {
      id,
      conversationId,
      userId,
      joinedAt: now
    };
    
    this.conversationParticipantsMap.set(id, participant);
    return true;
  }
  
  // Message operations
  async getMessages(conversationId: number): Promise<Message[]> {
    return Array.from(this.messagesMap.values())
      .filter(message => message.conversationId === conversationId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const id = this.currentIds.messages++;
    const now = new Date();

    const message: Message = {
      ...messageData,
      id,
      createdAt: now
    };
    
    this.messagesMap.set(id, message);
    
    // Update conversation updatedAt
    const conversation = this.conversationsMap.get(messageData.conversationId);
    if (conversation) {
      const updatedConversation = {
        ...conversation,
        updatedAt: now
      };
      this.conversationsMap.set(conversation.id, updatedConversation);
    }
    
    return message;
  }

  async markMessagesAsRead(conversationId: number, userId: number): Promise<boolean> {
    const messages = await this.getMessages(conversationId);
    
    messages
      .filter(message => message.senderId !== userId && !message.read)
      .forEach(message => {
        const updatedMessage = { ...message, read: true };
        this.messagesMap.set(message.id, updatedMessage);
      });
    
    return true;
  }
  
  // Blog operations
  async getBlogs(limit?: number, offset = 0): Promise<Blog[]> {
    const blogs = Array.from(this.blogsMap.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    if (limit) {
      return blogs.slice(offset, offset + limit);
    }
    
    return blogs;
  }

  async getBlogsByUser(userId: number): Promise<Blog[]> {
    return Array.from(this.blogsMap.values())
      .filter(blog => blog.authorId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getBlog(id: number): Promise<Blog | undefined> {
    return this.blogsMap.get(id);
  }
  
  async getBlogBySlug(slug: string): Promise<Blog | undefined> {
    return Array.from(this.blogsMap.values()).find(
      (blog) => blog.slug === slug
    );
  }

  async createBlog(blogData: InsertBlog): Promise<Blog> {
    const id = this.currentIds.blogs++;
    const now = new Date();
    const slug = slugify(blogData.title);

    const blog: Blog = {
      ...blogData,
      id,
      slug,
      likes: 0,
      comments: 0,
      createdAt: now,
      updatedAt: now
    };
    
    this.blogsMap.set(id, blog);
    return blog;
  }

  async updateBlog(id: number, data: Partial<Blog>): Promise<Blog | undefined> {
    const blog = this.blogsMap.get(id);
    if (!blog) return undefined;
    
    const updatedBlog = { ...blog, ...data, updatedAt: new Date() };
    this.blogsMap.set(id, updatedBlog);
    
    return updatedBlog;
  }
  
  async deleteBlog(id: number): Promise<boolean> {
    return this.blogsMap.delete(id);
  }
  
  // Group operations
  async getGroups(limit?: number, offset = 0): Promise<Group[]> {
    const groups = Array.from(this.groupsMap.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    if (limit) {
      return groups.slice(offset, offset + limit);
    }
    
    return groups;
  }

  async getGroupsByUser(userId: number): Promise<Group[]> {
    const memberEntries = Array.from(this.groupMembersMap.values())
      .filter(member => member.userId === userId);
    
    const groupIds = memberEntries.map(entry => entry.groupId);
    
    return Array.from(this.groupsMap.values())
      .filter(group => groupIds.includes(group.id))
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getGroup(id: number): Promise<Group | undefined> {
    return this.groupsMap.get(id);
  }

  async createGroup(groupData: InsertGroup): Promise<Group> {
    const id = this.currentIds.groups++;
    const now = new Date();

    const group: Group = {
      ...groupData,
      id,
      members: 1, // Creator is the first member
      createdAt: now,
      updatedAt: now
    };
    
    this.groupsMap.set(id, group);
    
    // Add creator as member with admin role
    await this.addMemberToGroup(id, groupData.createdBy, 'admin');
    
    return group;
  }

  async addMemberToGroup(groupId: number, userId: number, role = 'member'): Promise<boolean> {
    const group = this.groupsMap.get(groupId);
    const user = this.usersMap.get(userId);
    
    if (!group || !user) return false;
    
    const id = this.currentIds.groupMembers++;
    const now = new Date();
    
    const member = {
      id,
      groupId,
      userId,
      role,
      joinedAt: now
    };
    
    this.groupMembersMap.set(id, member);
    
    if (role === 'member') {
      await this.incrementGroupMembers(groupId);
    }
    
    return true;
  }
  
  async incrementGroupMembers(groupId: number): Promise<Group | undefined> {
    const group = this.groupsMap.get(groupId);
    if (!group) return undefined;
    
    const updatedGroup = { 
      ...group,
      members: group.members + 1,
      updatedAt: new Date()
    };
    this.groupsMap.set(groupId, updatedGroup);
    
    return updatedGroup;
  }
  
  // Event operations
  async getEvents(limit?: number, offset = 0): Promise<Event[]> {
    const events = Array.from(this.eventsMap.values())
      .sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
    
    if (limit) {
      return events.slice(offset, offset + limit);
    }
    
    return events;
  }

  async getEventsByUser(userId: number): Promise<Event[]> {
    return Array.from(this.eventsMap.values())
      .filter(event => event.organizedBy === userId)
      .sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
  }

  async getEvent(id: number): Promise<Event | undefined> {
    return this.eventsMap.get(id);
  }

  async createEvent(eventData: InsertEvent): Promise<Event> {
    const id = this.currentIds.events++;
    const now = new Date();

    const event: Event = {
      ...eventData,
      id,
      attendees: 0,
      createdAt: now,
      updatedAt: now
    };
    
    this.eventsMap.set(id, event);
    return event;
  }

  async addAttendeeToEvent(eventId: number, userId: number): Promise<boolean> {
    const event = this.eventsMap.get(eventId);
    const user = this.usersMap.get(userId);
    
    if (!event || !user) return false;
    
    const id = this.currentIds.eventAttendees++;
    const now = new Date();
    
    const attendee = {
      id,
      eventId,
      userId,
      registeredAt: now
    };
    
    this.eventAttendeesMap.set(id, attendee);
    await this.incrementEventAttendees(eventId);
    
    return true;
  }
  
  async incrementEventAttendees(eventId: number): Promise<Event | undefined> {
    const event = this.eventsMap.get(eventId);
    if (!event) return undefined;
    
    const updatedEvent = { 
      ...event,
      attendees: event.attendees + 1,
      updatedAt: new Date()
    };
    this.eventsMap.set(eventId, updatedEvent);
    
    return updatedEvent;
  }
  
  // Job operations
  async getJobs(limit?: number, offset = 0): Promise<Job[]> {
    const jobs = Array.from(this.jobsMap.values())
      .filter(job => job.status === 'open')
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    if (limit) {
      return jobs.slice(offset, offset + limit);
    }
    
    return jobs;
  }

  async getJobsByUser(userId: number): Promise<Job[]> {
    return Array.from(this.jobsMap.values())
      .filter(job => job.postedBy === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getJob(id: number): Promise<Job | undefined> {
    return this.jobsMap.get(id);
  }

  async createJob(jobData: InsertJob): Promise<Job> {
    const id = this.currentIds.jobs++;
    const now = new Date();

    const job: Job = {
      ...jobData,
      id,
      status: 'open',
      createdAt: now,
      updatedAt: now
    };
    
    this.jobsMap.set(id, job);
    return job;
  }

  async updateJobStatus(id: number, status: string): Promise<Job | undefined> {
    const job = this.jobsMap.get(id);
    if (!job) return undefined;
    
    const updatedJob = { 
      ...job,
      status,
      updatedAt: new Date()
    };
    this.jobsMap.set(id, updatedJob);
    
    return updatedJob;
  }
  
  // Points operations
  async createPointsTransaction(transactionData: InsertPointsTransaction): Promise<PointsTransaction> {
    const id = this.currentIds.pointsTransactions++;
    const now = new Date();

    const transaction: PointsTransaction = {
      ...transactionData,
      id,
      createdAt: now
    };
    
    this.pointsTransactionsMap.set(id, transaction);
    return transaction;
  }

  async getPointsTransactionsByUser(userId: number): Promise<PointsTransaction[]> {
    return Array.from(this.pointsTransactionsMap.values())
      .filter(transaction => transaction.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  // Notification operations
  async getNotificationsByUser(userId: number): Promise<Notification[]> {
    return Array.from(this.notificationsMap.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const id = this.currentIds.notifications++;
    const now = new Date();

    const notification: Notification = {
      ...notificationData,
      id,
      read: false,
      createdAt: now
    };
    
    this.notificationsMap.set(id, notification);
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notificationsMap.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, read: true };
    this.notificationsMap.set(id, updatedNotification);
    
    return updatedNotification;
  }
}

// Import the PostgreSQL storage implementation
import { pgStorage } from './pg-storage';

// Export the PostgreSQL storage implementation instead of MemStorage
export const storage = pgStorage;
