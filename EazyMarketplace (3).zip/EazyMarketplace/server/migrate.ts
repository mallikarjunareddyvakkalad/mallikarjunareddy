import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';
import * as schema from '../shared/schema';

async function runMigration() {
  console.log('Running database migrations...');
  
  try {
    const connectionString = process.env.DATABASE_URL || '';
    
    if (!connectionString) {
      throw new Error('DATABASE_URL environment variable is not set');
    }
    
    console.log('Connecting to database...');
    const sql = postgres(connectionString, { max: 1 });
    const db = drizzle(sql, { schema });
    
    console.log('Starting migration...');
    // This will create tables for all your schemas if they don't exist already
    await migrate(db, { migrationsFolder: './migrations' });
    
    console.log('Migration completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

runMigration();