import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';
import * as schema from '../shared/schema';
import { writeFileSync, mkdirSync, existsSync } from 'fs';

async function generateMigrations() {
  console.log('Generating database migrations...');
  
  try {
    const connectionString = process.env.DATABASE_URL || '';
    
    if (!connectionString) {
      throw new Error('DATABASE_URL environment variable is not set');
    }
    
    console.log('Connecting to database...');
    const sql = postgres(connectionString, { max: 1 });
    
    // Create migrations directory if it doesn't exist
    const migrationsDir = './migrations';
    if (!existsSync(migrationsDir)) {
      mkdirSync(migrationsDir, { recursive: true });
    }
    
    // Generate SQL for creating all tables
    let createTablesSql = '';
    
    // Add SQL for all enums and tables defined in schema
    for (const key in schema) {
      const item = (schema as any)[key];
      if (item?.getSQL) {
        createTablesSql += item.getSQL() + ';\n\n';
      }
    }
    
    // Write to migration file
    const timestamp = new Date().toISOString().replace(/[-:.TZ]/g, '');
    const migrationFileName = `${migrationsDir}/${timestamp}_initial_migration.sql`;
    
    writeFileSync(migrationFileName, createTablesSql);
    console.log(`Migration file created at ${migrationFileName}`);
    process.exit(0);
  } catch (error) {
    console.error('Migration generation failed:', error);
    process.exit(1);
  }
}

generateMigrations();