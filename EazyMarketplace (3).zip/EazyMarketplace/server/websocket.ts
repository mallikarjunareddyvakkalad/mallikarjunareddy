import { WebSocketServer } from 'ws';
import { Server } from 'http';
import { storage } from './storage';
import WebSocket from 'ws';

type ConnectedClient = {
  userId: number;
  socket: WebSocket;
};

export class ChatWebSocketServer {
  private wss: WebSocketServer;
  private clients: Map<string, ConnectedClient> = new Map();

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });
    this.setupWebSocketServer();
  }

  private setupWebSocketServer() {
    this.wss.on('connection', (socket, request) => {
      const clientId = this.generateClientId();
      console.log(`Client connected: ${clientId}`);

      // Authentication should happen first
      socket.on('message', async (data) => {
        try {
          const message = JSON.parse(data.toString());
          
          // Handle authentication message first
          if (message.type === 'auth') {
            const { userId } = message;
            if (userId) {
              this.clients.set(clientId, { userId, socket });
              console.log(`User ${userId} authenticated`);
              
              // Send successful authentication response
              this.sendToClient(socket, {
                type: 'auth_response',
                success: true
              });
              
              // Send any unread messages or notifications
              await this.sendUnreadMessages(userId, socket);
            }
            return;
          }
          
          // All other messages require authentication
          const client = this.clients.get(clientId);
          if (!client) {
            this.sendToClient(socket, {
              type: 'error',
              message: 'Unauthorized',
              code: 401
            });
            return;
          }
          
          // Handle different message types
          await this.handleMessage(client.userId, message, socket);
        } catch (error) {
          console.error('Error processing message:', error);
          this.sendToClient(socket, {
            type: 'error',
            message: 'Invalid message format',
            code: 400
          });
        }
      });

      // Handle disconnection
      socket.on('close', () => {
        console.log(`Client disconnected: ${clientId}`);
        this.clients.delete(clientId);
      });
      
      // Send welcome message
      this.sendToClient(socket, {
        type: 'system',
        message: 'Connected to EazyBuySells Chat Server'
      });
    });
  }

  private async handleMessage(userId: number, message: any, socket: WebSocket) {
    switch (message.type) {
      case 'chat_message':
        await this.handleChatMessage(userId, message, socket);
        break;
        
      case 'read_messages':
        await this.handleReadMessages(userId, message, socket);
        break;
        
      case 'typing':
        await this.handleTypingStatus(userId, message);
        break;
        
      default:
        this.sendToClient(socket, {
          type: 'error',
          message: 'Unknown message type',
          code: 400
        });
    }
  }

  private async handleChatMessage(userId: number, message: any, socket: WebSocket) {
    const { conversationId, content, messageType = 'text' } = message;
    
    if (!conversationId || !content) {
      this.sendToClient(socket, {
        type: 'error',
        message: 'Missing required fields',
        code: 400
      });
      return;
    }
    
    try {
      // Save message to database
      const newMessage = await storage.createMessage({
        conversationId,
        senderId: userId,
        content,
        type: messageType,
        read: false
      });
      
      // Get conversation participants to broadcast message
      const conversation = await storage.getConversation(conversationId);
      if (!conversation) {
        this.sendToClient(socket, {
          type: 'error',
          message: 'Conversation not found',
          code: 404
        });
        return;
      }
      
      // Broadcast to all participants except sender
      this.broadcastToConversation(conversationId, {
        type: 'new_message',
        message: newMessage
      }, userId);
      
      // Send confirmation to sender
      this.sendToClient(socket, {
        type: 'message_sent',
        messageId: newMessage.id,
        timestamp: newMessage.createdAt
      });
    } catch (error) {
      console.error('Error sending message:', error);
      this.sendToClient(socket, {
        type: 'error',
        message: 'Failed to send message',
        code: 500
      });
    }
  }

  private async handleReadMessages(userId: number, message: any, socket: WebSocket) {
    const { conversationId } = message;
    
    if (!conversationId) {
      this.sendToClient(socket, {
        type: 'error',
        message: 'Missing conversationId',
        code: 400
      });
      return;
    }
    
    try {
      // Mark messages as read in database
      await storage.markMessagesAsRead(conversationId, userId);
      
      // Broadcast read status to other participants
      this.broadcastToConversation(conversationId, {
        type: 'messages_read',
        conversationId,
        userId
      }, userId);
      
      // Confirm to sender
      this.sendToClient(socket, {
        type: 'read_confirmed',
        conversationId
      });
    } catch (error) {
      console.error('Error marking messages as read:', error);
      this.sendToClient(socket, {
        type: 'error',
        message: 'Failed to mark messages as read',
        code: 500
      });
    }
  }

  private async handleTypingStatus(userId: number, message: any) {
    const { conversationId, isTyping } = message;
    
    if (!conversationId) {
      return;
    }
    
    // Broadcast typing status to conversation participants
    this.broadcastToConversation(conversationId, {
      type: 'typing_status',
      conversationId,
      userId,
      isTyping
    }, userId);
  }

  private async sendUnreadMessages(userId: number, socket: WebSocket) {
    try {
      // Get conversations for this user
      const conversations = await storage.getConversationsByUser(userId);
      
      // For each conversation, check unread messages
      for (const conversation of conversations) {
        const messages = await storage.getMessages(conversation.id);
        const unreadMessages = messages.filter(msg => msg.senderId !== userId && !msg.read);
        
        if (unreadMessages.length > 0) {
          this.sendToClient(socket, {
            type: 'unread_messages',
            conversationId: conversation.id,
            count: unreadMessages.length,
            messages: unreadMessages
          });
        }
      }
      
      // Also send notifications
      const notifications = await storage.getNotificationsByUser(userId);
      const unreadNotifications = notifications.filter(n => !n.read);
      
      if (unreadNotifications.length > 0) {
        this.sendToClient(socket, {
          type: 'notifications',
          count: unreadNotifications.length,
          notifications: unreadNotifications
        });
      }
    } catch (error) {
      console.error('Error sending unread messages:', error);
    }
  }

  private broadcastToConversation(conversationId: number, data: any, excludeUserId?: number) {
    // Find all clients in this conversation
    this.clients.forEach((client) => {
      if (excludeUserId && client.userId === excludeUserId) {
        return; // Skip the sender
      }
      
      // In a real implementation, we would check if user is part of conversation
      // For simplicity, we're broadcasting to all authenticated users here
      this.sendToClient(client.socket, data);
    });
  }

  private sendToClient(socket: WebSocket, data: any) {
    if (socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(data));
    }
  }

  private generateClientId(): string {
    return Math.random().toString(36).substring(2, 15);
  }
}

export const initWebSocketServer = (server: Server): ChatWebSocketServer => {
  return new ChatWebSocketServer(server);
};
