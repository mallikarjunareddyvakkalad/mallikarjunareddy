import { storage } from '../storage';
import { InsertPointsTransaction } from '@shared/schema';

export class PointsService {
  // Award points to a user and create a transaction record
  async awardPoints(userId: number, amount: number, type: string, referenceId?: string, description?: string): Promise<boolean> {
    try {
      // Update user points
      const updatedUser = await storage.updateUserPoints(userId, amount);
      
      if (!updatedUser) {
        return false;
      }
      
      // Create transaction record
      const transactionData: InsertPointsTransaction = {
        userId,
        amount,
        type: type as any, // Type assertion since we have a constrained enum
        referenceId,
        description: description || `${amount} points ${amount > 0 ? 'awarded' : 'deducted'} for ${type}`
      };
      
      await storage.createPointsTransaction(transactionData);
      
      // Create notification for the user
      await storage.createNotification({
        userId,
        title: `Points ${amount > 0 ? 'Awarded' : 'Deducted'}`,
        content: `${amount > 0 ? '+' : ''}${amount} points have been ${amount > 0 ? 'added to' : 'deducted from'} your account.`,
        type: 'points',
        referenceId: transactionData.referenceId
      });
      
      return true;
    } catch (error) {
      console.error('Error awarding points:', error);
      return false;
    }
  }
  
  // Process referral points when a user signs up with a referral
  async processReferralPoints(referredUserId: number, referrerId: number): Promise<boolean> {
    try {
      // Award 2 points to the referrer
      const referrerSuccess = await this.awardPoints(
        referrerId,
        2,
        'referral',
        referredUserId.toString(),
        `Points awarded for referring a new user`
      );
      
      if (!referrerSuccess) {
        return false;
      }
      
      // Create notification for referrer
      await storage.createNotification({
        userId: referrerId,
        title: 'Referral Bonus',
        content: 'You received 2 points for referring a new user!',
        type: 'referral',
        referenceId: referredUserId.toString()
      });
      
      return true;
    } catch (error) {
      console.error('Error processing referral points:', error);
      return false;
    }
  }
  
  // Award login streak points
  async processLoginStreakPoints(userId: number, streakDays: number): Promise<boolean> {
    try {
      // Determine points based on streak length
      let points = 1; // Default daily login point
      
      if (streakDays % 7 === 0) {
        // Bonus points for weekly streak milestones
        points = 5;
      } else if (streakDays % 30 === 0) {
        // Bigger bonus for monthly streak milestones
        points = 20;
      }
      
      // Award the points
      const success = await this.awardPoints(
        userId,
        points,
        'login_streak',
        `streak_${streakDays}`,
        `Points awarded for ${streakDays}-day login streak`
      );
      
      return success;
    } catch (error) {
      console.error('Error processing streak points:', error);
      return false;
    }
  }
  
  // Process withdrawal
  async processWithdrawal(userId: number, amount: number): Promise<{
    success: boolean;
    message: string;
  }> {
    try {
      // Get user to check points balance
      const user = await storage.getUser(userId);
      
      if (!user) {
        return {
          success: false,
          message: 'User not found'
        };
      }
      
      // Check if they have enough points (100 minimum)
      if (user.points < amount) {
        return {
          success: false,
          message: 'Insufficient points balance'
        };
      }
      
      if (amount < 100) {
        return {
          success: false,
          message: 'Minimum withdrawal amount is 100 points'
        };
      }
      
      // Deduct points
      const success = await this.awardPoints(
        userId,
        -amount,
        'withdrawal',
        `withdrawal_${Date.now()}`,
        `Withdrawal of ${amount} points (₹${amount})`
      );
      
      if (success) {
        return {
          success: true,
          message: `Successfully processed withdrawal of ${amount} points (₹${amount})`
        };
      } else {
        return {
          success: false,
          message: 'Error processing withdrawal'
        };
      }
      
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      return {
        success: false,
        message: 'An error occurred while processing withdrawal'
      };
    }
  }
  
  // Get user points summary
  async getUserPointsSummary(userId: number): Promise<{
    currentBalance: number;
    totalEarned: number;
    totalSpent: number;
    transactions: any[];
  }> {
    try {
      const user = await storage.getUser(userId);
      if (!user) {
        throw new Error('User not found');
      }
      
      const transactions = await storage.getPointsTransactionsByUser(userId);
      
      // Calculate total earned and spent
      let totalEarned = 0;
      let totalSpent = 0;
      
      transactions.forEach(transaction => {
        if (transaction.amount > 0) {
          totalEarned += transaction.amount;
        } else {
          totalSpent += Math.abs(transaction.amount);
        }
      });
      
      return {
        currentBalance: user.points,
        totalEarned,
        totalSpent,
        transactions
      };
    } catch (error) {
      console.error('Error getting points summary:', error);
      throw error;
    }
  }
}

export const pointsService = new PointsService();
