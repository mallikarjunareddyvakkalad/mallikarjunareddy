import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { pointsService } from "./services/pointsService";
import { aiService } from "./services/aiService";
import { initWebSocketServer } from "./websocket";
import bcrypt from "bcryptjs";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { 
  loginSchema, 
  registerSchema, 
  insertProductSchema, 
  insertServiceSchema,
  insertBlogSchema,
  insertGroupSchema,
  insertEventSchema,
  insertJobSchema,
  InsertUser,
  User
} from "@shared/schema";
import session from "express-session";
import slugify from "slugify";

// Extend Express session types to include user fields
declare module "express-session" {
  interface SessionData {
    userId?: number;
    username?: string;
  }
}

// Check if user is authenticated middleware
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.session.userId) {
    next();
  } else {
    res.status(401).json({ message: "Unauthorized" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize WebSocket for chat
  initWebSocketServer(httpServer);
  
  // Set up session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "eazybuysells-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
      },
    })
  );
  

  
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(data.password, 10);
      
      // Process referral code if provided
      let referrerId = null;
      if (data.referralCode) {
        const referrer = await storage.getUserByReferralCode(data.referralCode);
        if (referrer) {
          referrerId = referrer.id;
        }
      }
      
      // Create user without sensitive fields
      const userData: InsertUser = {
        username: data.username,
        password: hashedPassword,
        email: data.email,
        name: data.name,
        avatar: data.avatar,
        bio: data.bio,
        phone: data.phone,
        address: data.address,
        role: data.role || 'buyer'
      };
      
      const newUser = await storage.createUser(userData, data.referralCode);
      
      // Set session data
      req.session.userId = newUser.id;
      req.session.username = newUser.username;
      
      // Return user without password
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to register user" });
    }
  });
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Set session data
      req.session.userId = user.id;
      req.session.username = user.username;
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to log in" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to log out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  
  app.get("/api/auth/me", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        req.session.destroy(() => {});
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });
  
  // User Profile routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });
  
  app.patch("/api/users/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const { name, avatar, bio, phone, address } = req.body;
      
      // Update only allowed fields
      const updatedData: Partial<User> = {};
      if (name) updatedData.name = name;
      if (avatar) updatedData.avatar = avatar;
      if (bio) updatedData.bio = bio;
      if (phone) updatedData.phone = phone;
      if (address) updatedData.address = address;
      
      // Update user profile
      const updatedUser = await storage.updateUser(userId, updatedData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      const categoryId = req.query.category ? parseInt(req.query.category as string) : undefined;
      
      let products;
      if (categoryId) {
        products = await storage.getProductsByCategory(categoryId);
      } else {
        products = await storage.getProducts(limit, offset);
      }
      
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });
  
  app.get("/api/products/:id", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Increment view count
      await storage.incrementProductViews(productId);
      
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });
  
  app.post("/api/products", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const productData = insertProductSchema.parse(req.body);
      
      // Add seller ID to product data
      const product = await storage.createProduct({
        ...productData,
        sellerId: userId
      });
      
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating product:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });
  
  app.patch("/api/products/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const productId = parseInt(req.params.id);
      
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      // Check if product exists and belongs to user
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      if (product.sellerId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this product" });
      }
      
      // Update product
      const updatedProduct = await storage.updateProduct(productId, req.body);
      
      res.json(updatedProduct);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });
  
  app.delete("/api/products/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const productId = parseInt(req.params.id);
      
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      // Check if product exists and belongs to user
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      if (product.sellerId !== userId) {
        return res.status(403).json({ message: "Not authorized to delete this product" });
      }
      
      // Delete product
      await storage.deleteProduct(productId);
      
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });
  
  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });
  
  // Service routes
  app.get("/api/services", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      const categoryId = req.query.category ? parseInt(req.query.category as string) : undefined;
      
      let services;
      if (categoryId) {
        services = await storage.getServicesByCategory(categoryId);
      } else {
        services = await storage.getServices(limit, offset);
      }
      
      res.json(services);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });
  
  app.post("/api/services", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const serviceData = insertServiceSchema.parse(req.body);
      
      // Add seller ID to service data
      const service = await storage.createService({
        ...serviceData,
        sellerId: userId
      });
      
      res.status(201).json(service);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating service:", error);
      res.status(500).json({ message: "Failed to create service" });
    }
  });
  
  // Blog routes
  app.get("/api/blogs", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const blogs = await storage.getBlogs(limit, offset);
      res.json(blogs);
    } catch (error) {
      console.error("Error fetching blogs:", error);
      res.status(500).json({ message: "Failed to fetch blogs" });
    }
  });
  
  app.post("/api/blogs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const blogData = insertBlogSchema.parse(req.body);
      
      // Add author ID to blog data
      const blog = await storage.createBlog({
        ...blogData,
        authorId: userId
      });
      
      res.status(201).json(blog);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating blog:", error);
      res.status(500).json({ message: "Failed to create blog" });
    }
  });
  
  // Group routes
  app.get("/api/groups", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const groups = await storage.getGroups(limit, offset);
      res.json(groups);
    } catch (error) {
      console.error("Error fetching groups:", error);
      res.status(500).json({ message: "Failed to fetch groups" });
    }
  });
  
  app.post("/api/groups", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const groupData = insertGroupSchema.parse(req.body);
      
      // Add creator ID to group data
      const group = await storage.createGroup({
        ...groupData,
        createdBy: userId
      });
      
      res.status(201).json(group);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating group:", error);
      res.status(500).json({ message: "Failed to create group" });
    }
  });
  
  app.post("/api/groups/:id/join", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const groupId = parseInt(req.params.id);
      
      if (isNaN(groupId)) {
        return res.status(400).json({ message: "Invalid group ID" });
      }
      
      // Check if group exists
      const group = await storage.getGroup(groupId);
      if (!group) {
        return res.status(404).json({ message: "Group not found" });
      }
      
      // Add user to group
      await storage.addMemberToGroup(groupId, userId);
      
      res.json({ message: "Joined group successfully" });
    } catch (error) {
      console.error("Error joining group:", error);
      res.status(500).json({ message: "Failed to join group" });
    }
  });
  
  // Event routes
  app.get("/api/events", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const events = await storage.getEvents(limit, offset);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });
  
  app.post("/api/events", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const eventData = insertEventSchema.parse(req.body);
      
      // Add organizer ID to event data
      const event = await storage.createEvent({
        ...eventData,
        organizedBy: userId
      });
      
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating event:", error);
      res.status(500).json({ message: "Failed to create event" });
    }
  });
  
  app.post("/api/events/:id/attend", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const eventId = parseInt(req.params.id);
      
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Check if event exists
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Add user as attendee
      await storage.addAttendeeToEvent(eventId, userId);
      
      res.json({ message: "Registered for event successfully" });
    } catch (error) {
      console.error("Error registering for event:", error);
      res.status(500).json({ message: "Failed to register for event" });
    }
  });
  
  // Job/Gig routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const jobs = await storage.getJobs(limit, offset);
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching jobs:", error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });
  
  app.post("/api/jobs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const jobData = insertJobSchema.parse(req.body);
      
      // Add poster ID to job data
      const job = await storage.createJob({
        ...jobData,
        postedBy: userId
      });
      
      res.status(201).json(job);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating job:", error);
      res.status(500).json({ message: "Failed to create job" });
    }
  });
  
  // Points routes
  app.get("/api/points", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      
      const pointsSummary = await pointsService.getUserPointsSummary(userId);
      res.json(pointsSummary);
    } catch (error) {
      console.error("Error fetching points summary:", error);
      res.status(500).json({ message: "Failed to fetch points summary" });
    }
  });
  
  app.post("/api/points/withdraw", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const { amount } = req.body;
      
      if (!amount || isNaN(amount) || amount < 100) {
        return res.status(400).json({ message: "Invalid amount, minimum withdrawal is 100 points" });
      }
      
      const result = await pointsService.processWithdrawal(userId, amount);
      
      if (result.success) {
        res.json({ message: result.message });
      } else {
        res.status(400).json({ message: result.message });
      }
    } catch (error) {
      console.error("Error processing withdrawal:", error);
      res.status(500).json({ message: "Failed to process withdrawal" });
    }
  });
  
  // Notification routes
  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      
      const notifications = await storage.getNotificationsByUser(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });
  
  app.patch("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const notificationId = parseInt(req.params.id);
      
      if (isNaN(notificationId)) {
        return res.status(400).json({ message: "Invalid notification ID" });
      }
      
      const notification = await storage.markNotificationAsRead(notificationId);
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      res.json(notification);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });
  
  // Chat/Conversation routes
  app.get("/api/conversations", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      
      const conversations = await storage.getConversationsByUser(userId);
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });
  
  app.post("/api/conversations", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const { name, type, participants } = req.body;
      
      // Create new conversation
      const conversation = await storage.createConversation({
        name,
        type: type || 'private',
        createdBy: userId
      });
      
      // Add participants
      if (participants && Array.isArray(participants)) {
        for (const participantId of participants) {
          await storage.addParticipantToConversation(conversation.id, participantId);
        }
      }
      
      res.status(201).json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });
  
  app.get("/api/conversations/:id/messages", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const conversationId = parseInt(req.params.id);
      
      if (isNaN(conversationId)) {
        return res.status(400).json({ message: "Invalid conversation ID" });
      }
      
      // TODO: In a real application, check if user is part of conversation
      
      const messages = await storage.getMessages(conversationId);
      
      // Mark messages as read
      await storage.markMessagesAsRead(conversationId, userId);
      
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  
  // AI integration routes
  app.post("/api/ai/generate-content", isAuthenticated, async (req, res) => {
    try {
      const { type, prompt, length, tone } = req.body;
      
      if (!type || !prompt) {
        return res.status(400).json({ message: "Type and prompt are required" });
      }
      
      const content = await aiService.generateContent({
        type,
        prompt,
        length,
        tone
      });
      
      res.json({ content });
    } catch (error) {
      console.error("Error generating content:", error);
      res.status(500).json({ message: "Failed to generate content" });
    }
  });
  
  app.post("/api/ai/suggest-price", isAuthenticated, async (req, res) => {
    try {
      const { category, title, description, features, condition } = req.body;
      
      if (!category || !title) {
        return res.status(400).json({ message: "Category and title are required" });
      }
      
      const price = await aiService.suggestPrice({
        category,
        title,
        description: description || '',
        features,
        condition
      });
      
      res.json({ price });
    } catch (error) {
      console.error("Error suggesting price:", error);
      res.status(500).json({ message: "Failed to suggest price" });
    }
  });
  
  app.post("/api/ai/moderate-content", isAuthenticated, async (req, res) => {
    try {
      const { content, contentType } = req.body;
      
      if (!content || !contentType) {
        return res.status(400).json({ message: "Content and contentType are required" });
      }
      
      const result = await aiService.moderateContent({
        content,
        contentType
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error moderating content:", error);
      res.status(500).json({ message: "Failed to moderate content" });
    }
  });
  
  app.get("/api/ai/product-recommendations", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const viewedProductIds = req.query.viewed ? 
        (req.query.viewed as string).split(',').map(id => parseInt(id)) : 
        [];
      
      const recommendations = await aiService.getProductRecommendations(userId, viewedProductIds);
      
      res.json({ recommendations });
    } catch (error) {
      console.error("Error getting recommendations:", error);
      res.status(500).json({ message: "Failed to get recommendations" });
    }
  });

  return httpServer;
}
