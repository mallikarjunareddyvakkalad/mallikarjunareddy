import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Order } from "@shared/schema";

interface OrderListItemProps {
  order: Order;
  buyerName?: string;
  buyerAvatar?: string;
  productTitle?: string;
  onViewDetails?: (order: Order) => void;
}

const OrderListItem = ({ 
  order, 
  buyerName = "Customer", 
  buyerAvatar,
  productTitle,
  onViewDetails
}: OrderListItemProps) => {
  // Format the createdAt date
  const orderDate = order.createdAt
    ? formatDistanceToNow(new Date(order.createdAt), { addSuffix: true })
    : "recently";

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    const names = name.split(" ");
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  // Determine badge color based on status
  const getBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case "paid":
        return "success";
      case "processing":
        return "info";
      case "shipped":
        return "warning";
      case "delivered":
        return "success";
      case "cancelled":
        return "destructive";
      default:
        return "secondary";
    }
  };

  return (
    <div 
      className="flex items-center p-2 hover:bg-gray-50 rounded-lg cursor-pointer"
      onClick={() => onViewDetails && onViewDetails(order)}
    >
      <Avatar className="h-10 w-10 mr-3">
        <AvatarImage src={buyerAvatar} />
        <AvatarFallback>{getInitials(buyerName)}</AvatarFallback>
      </Avatar>
      <div className="flex-grow mr-3">
        <div className="flex justify-between">
          <div className="font-medium text-gray-800">{buyerName}</div>
          <div className="text-xs text-gray-500">{orderDate}</div>
        </div>
        <div className="text-xs text-gray-500">
          Ordered {productTitle || `Product #${order.productId || order.serviceId}`}
        </div>
      </div>
      <div className="flex-shrink-0">
        <Badge 
          variant={getBadgeVariant(order.status) as any}
          className="px-2 py-1 text-xs rounded-full"
        >
          {order.status}
        </Badge>
      </div>
    </div>
  );
};

export default OrderListItem;
