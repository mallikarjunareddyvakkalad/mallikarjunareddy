import { formatDistanceToNow } from "date-fns";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Message } from "@shared/schema";

interface MessageListItemProps {
  message: Message;
  senderName: string;
  senderAvatar?: string;
  timestamp: Date;
  unread?: boolean;
  onClick?: () => void;
}

const MessageListItem = ({
  message,
  senderName,
  senderAvatar,
  timestamp,
  unread = false,
  onClick
}: MessageListItemProps) => {
  // Format the timestamp
  const timeAgo = formatDistanceToNow(new Date(timestamp), { addSuffix: true });

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    const names = name.split(" ");
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  // Truncate message content for preview
  const previewText = message.content.length > 40
    ? `${message.content.substring(0, 40)}...`
    : message.content;

  return (
    <div 
      className={`p-2 ${unread ? 'bg-gray-50' : 'hover:bg-gray-50'} rounded-lg cursor-pointer`}
      onClick={onClick}
    >
      <div className="flex items-center mb-1">
        <Avatar className="h-8 w-8 mr-2">
          <AvatarImage src={senderAvatar} />
          <AvatarFallback>{getInitials(senderName)}</AvatarFallback>
        </Avatar>
        <div className="flex-grow">
          <div className="flex justify-between">
            <div className="font-medium text-gray-800">{senderName}</div>
            <div className="text-xs text-gray-500">{timeAgo}</div>
          </div>
        </div>
      </div>
      <div className="pl-10">
        <p className={`text-sm ${unread ? 'font-medium text-gray-800' : 'text-gray-600'} line-clamp-1`}>
          {previewText}
        </p>
        {unread && (
          <span className="inline-block w-2 h-2 bg-primary rounded-full ml-1"></span>
        )}
      </div>
    </div>
  );
};

export default MessageListItem;
