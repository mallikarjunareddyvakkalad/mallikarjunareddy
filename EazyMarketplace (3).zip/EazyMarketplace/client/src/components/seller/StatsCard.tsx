import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowUpIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  iconBgColor: string;
  change?: {
    value: string | number;
    positive: boolean;
  };
  changeText?: string;
}

const StatsCard = ({
  title,
  value,
  icon,
  iconBgColor,
  change,
  changeText,
}: StatsCardProps) => {
  return (
    <Card className="bg-white rounded-lg shadow-md">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-gray-500">{title}</div>
            <div className="text-2xl font-bold text-gray-800">{value}</div>
          </div>
          <div
            className={`h-10 w-10 rounded-full ${iconBgColor} flex items-center justify-center`}
          >
            {icon}
          </div>
        </div>
        {change && (
          <div className="mt-2 flex items-center text-xs">
            {change.positive ? (
              <ArrowUpIcon className="text-accent mr-1 h-3 w-3" />
            ) : (
              <ArrowUpIcon className="text-red-500 mr-1 h-3 w-3 transform rotate-180" />
            )}
            <span className={change.positive ? "text-accent" : "text-red-500"}>
              {change.value}
            </span>
            <span className="text-gray-500 ml-1">{changeText || "vs last month"}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StatsCard;
