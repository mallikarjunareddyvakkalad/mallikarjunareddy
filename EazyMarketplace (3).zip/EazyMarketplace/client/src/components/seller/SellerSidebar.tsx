import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  LayoutDashboard, 
  Store, 
  ShoppingCart, 
  MessageSquare, 
  LineChart, 
  Coins, 
  Settings,
  Star,
  StarHalf
} from "lucide-react";

const SellerSidebar = () => {
  const [location] = useLocation();
  const { user } = useAuth();

  // Get user initials for avatar fallback
  const getUserInitials = () => {
    if (!user?.name) return "US";
    const names = user.name.split(" ");
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return user.name.substring(0, 2).toUpperCase();
  };

  // Navigation items
  const navItems = [
    {
      name: "Dashboard Overview",
      path: "/dashboard",
      icon: <LayoutDashboard className="mr-3 text-lg" />,
    },
    {
      name: "My Products",
      path: "/dashboard/products",
      icon: <Store className="mr-3 text-lg" />,
    },
    {
      name: "Orders",
      path: "/dashboard/orders",
      icon: <ShoppingCart className="mr-3 text-lg" />,
    },
    {
      name: "Messages",
      path: "/dashboard/messages",
      icon: <MessageSquare className="mr-3 text-lg" />,
      badge: 8,
    },
    {
      name: "Analytics",
      path: "/dashboard/analytics",
      icon: <LineChart className="mr-3 text-lg" />,
    },
    {
      name: "Earnings",
      path: "/dashboard/earnings",
      icon: <Coins className="mr-3 text-lg" />,
    },
    {
      name: "Settings",
      path: "/dashboard/settings",
      icon: <Settings className="mr-3 text-lg" />,
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-4 sticky top-20">
      <div className="flex items-center p-2 mb-4">
        <Avatar className="h-12 w-12 mr-3">
          <AvatarImage src={user?.avatar} />
          <AvatarFallback>{getUserInitials()}</AvatarFallback>
        </Avatar>
        <div>
          <div className="font-semibold text-gray-800">
            {user?.name || user?.username || "Seller"}
          </div>
          <div className="text-xs text-gray-500">
            Seller since {new Date(user?.createdAt || Date.now()).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
          </div>
        </div>
      </div>

      <nav>
        {navItems.map((item) => (
          <Link
            key={item.path}
            href={item.path}
            className={`flex items-center p-3 rounded-lg mb-1 ${
              location === item.path
                ? "text-primary bg-primary/5"
                : "text-gray-700 hover:bg-gray-50"
            }`}
          >
            {item.icon}
            <span className={location === item.path ? "font-medium" : ""}>
              {item.name}
            </span>
            {item.badge && (
              <span className="ml-auto bg-secondary text-white text-xs px-2 py-1 rounded-full">
                {item.badge}
              </span>
            )}
          </Link>
        ))}
      </nav>

      <div className="mt-6 p-3 bg-gray-50 rounded-lg">
        <div className="text-sm font-medium text-gray-800 mb-2">Seller Rating</div>
        <div className="flex items-center">
          <div className="flex text-yellow-400 text-lg">
            <Star className="fill-current" />
            <Star className="fill-current" />
            <Star className="fill-current" />
            <Star className="fill-current" />
            <StarHalf className="fill-current" />
          </div>
          <span className="ml-2 font-medium">4.8/5</span>
        </div>
        <div className="text-xs text-gray-500 mt-1">Based on 142 reviews</div>
      </div>
    </div>
  );
};

export default SellerSidebar;
