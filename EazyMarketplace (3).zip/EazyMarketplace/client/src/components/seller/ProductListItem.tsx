import { formatDistanceToNow } from "date-fns";
import { Product } from "@shared/schema";

interface ProductListItemProps {
  product: Product;
  onEdit?: (product: Product) => void;
  onDelete?: (product: Product) => void;
}

const ProductListItem = ({ product, onEdit, onDelete }: ProductListItemProps) => {
  // Format the createdAt date
  const addedOn = product.createdAt
    ? formatDistanceToNow(new Date(product.createdAt), { addSuffix: true })
    : "recently";

  return (
    <div className="flex items-center p-2 hover:bg-gray-50 rounded-lg">
      <div className="h-14 w-14 bg-gray-100 rounded-lg overflow-hidden mr-3">
        <img
          src={
            product.image ||
            `https://via.placeholder.com/100?text=${encodeURIComponent(
              product.title.charAt(0)
            )}`
          }
          alt={product.title}
          className="h-full w-full object-cover"
        />
      </div>
      <div className="flex-grow mr-3">
        <div className="font-medium text-gray-800 truncate">{product.title}</div>
        <div className="text-xs text-gray-500">Added {addedOn}</div>
      </div>
      <div className="text-right">
        <div className="font-semibold text-gray-800">₹{product.price.toLocaleString("en-IN")}</div>
        <div className="text-xs text-accent">{product.views} views today</div>
      </div>
      {(onEdit || onDelete) && (
        <div className="ml-4 flex space-x-2">
          {onEdit && (
            <button
              onClick={() => onEdit(product)}
              className="text-gray-500 hover:text-primary p-1"
              aria-label="Edit product"
            >
              <i className="ri-edit-line"></i>
            </button>
          )}
          {onDelete && (
            <button
              onClick={() => onDelete(product)}
              className="text-gray-500 hover:text-red-500 p-1"
              aria-label="Delete product"
            >
              <i className="ri-delete-bin-line"></i>
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default ProductListItem;
