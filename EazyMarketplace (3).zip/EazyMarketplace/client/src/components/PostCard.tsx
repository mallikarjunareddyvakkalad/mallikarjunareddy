import { useState } from "react";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThumbsUp, MessageSquare, Bookmark, Share2, MoreHorizontal } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type PostCardProps = {
  id: number;
  userId: number;
  username: string;
  userAvatar?: string;
  userTitle?: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  createdAt: string;
  onLike?: (id: number) => void;
  onComment?: (id: number, comment: string) => void;
};

const PostCard = ({
  id,
  userId,
  username,
  userAvatar,
  userTitle,
  content,
  image,
  likes,
  comments: commentCount,
  createdAt,
  onLike,
  onComment,
}: PostCardProps) => {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [comment, setComment] = useState("");
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(likes);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [showCommentInput, setShowCommentInput] = useState(false);

  const timeAgo = formatDistanceToNow(new Date(createdAt), { addSuffix: true });

  const handleLike = async () => {
    if (!isAuthenticated) {
      toast({
        title: "Login Required",
        description: "Please sign in to like posts",
        variant: "destructive",
      });
      return;
    }

    try {
      if (onLike) {
        onLike(id);
      } else {
        await apiRequest("PUT", `/api/posts/${id}/like`, {});
      }
      
      setIsLiked(!isLiked);
      setLikeCount(isLiked ? likeCount - 1 : likeCount + 1);
      
      if (!isLiked) {
        toast({
          title: "Post liked!",
          description: "You liked this post",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to like post",
        variant: "destructive",
      });
    }
  };

  const handleComment = async () => {
    if (!comment.trim()) return;
    
    if (!isAuthenticated) {
      toast({
        title: "Login Required",
        description: "Please sign in to comment on posts",
        variant: "destructive",
      });
      return;
    }

    try {
      if (onComment) {
        onComment(id, comment);
      } else {
        await apiRequest("POST", "/api/comments", {
          postId: id,
          content: comment,
        });
      }
      
      setComment("");
      toast({
        title: "Comment added!",
        description: "Your comment has been posted",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to post comment",
        variant: "destructive",
      });
    }
  };

  const handleBookmark = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login Required",
        description: "Please sign in to bookmark posts",
        variant: "destructive",
      });
      return;
    }

    setIsBookmarked(!isBookmarked);
    toast({
      title: isBookmarked ? "Bookmark removed" : "Bookmark added!",
      description: isBookmarked
        ? "Post removed from your bookmarks"
        : "Post saved to your bookmarks",
    });
  };

  const handleShare = () => {
    const url = `${window.location.origin}/community/post/${id}`;
    navigator.clipboard.writeText(url);
    
    toast({
      title: "Link copied!",
      description: "Post link copied to clipboard",
    });
  };

  return (
    <Card className="bg-white p-5 rounded-xl shadow-sm">
      <CardContent className="p-0">
        <div className="flex justify-between items-start">
          <div className="flex space-x-3">
            <Link href={`/profile/${userId}`}>
              <a>
                <Avatar className="h-10 w-10">
                  <AvatarImage src={userAvatar || `https://ui-avatars.com/api/?name=${username}`} alt={username} />
                  <AvatarFallback>{username.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
              </a>
            </Link>
            <div>
              <Link href={`/profile/${userId}`}>
                <a className="font-medium text-gray-900 hover:text-primary">{username}</a>
              </Link>
              <p className="text-sm text-gray-500">{userTitle || "Member"} • {timeAgo}</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="text-gray-400 hover:text-gray-500">
            <MoreHorizontal size={16} />
          </Button>
        </div>
        
        <div className="mt-4">
          <p className="text-gray-800">{content}</p>
          {image && (
            <img className="mt-3 rounded-lg w-full h-60 object-cover" src={image} alt="Post content" />
          )}
        </div>
        
        <div className="mt-4 flex justify-between">
          <div className="flex space-x-4">
            <Button
              variant="ghost"
              size="sm"
              className={`flex items-center space-x-1 text-gray-500 hover:text-primary ${isLiked ? 'text-primary' : ''}`}
              onClick={handleLike}
            >
              <ThumbsUp size={16} className={isLiked ? "fill-current" : ""} />
              <span>{likeCount}</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-1 text-gray-500 hover:text-primary"
              onClick={() => setShowCommentInput(!showCommentInput)}
            >
              <MessageSquare size={16} />
              <span>{commentCount}</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className={`flex items-center space-x-1 text-gray-500 hover:text-primary ${isBookmarked ? 'text-primary' : ''}`}
              onClick={handleBookmark}
            >
              <Bookmark size={16} className={isBookmarked ? "fill-current" : ""} />
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-500 hover:text-primary flex items-center space-x-1"
            onClick={handleShare}
          >
            <Share2 size={16} />
            <span className="text-sm">Share</span>
          </Button>
        </div>
        
        {showCommentInput && (
          <div className="mt-4 border-t pt-4">
            <div className="flex space-x-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.avatar || `https://ui-avatars.com/api/?name=${user?.username || "U"}`} alt={user?.username || "User"} />
                <AvatarFallback>{user ? user.username.substring(0, 2).toUpperCase() : "U"}</AvatarFallback>
              </Avatar>
              <div className="flex-1 flex space-x-2">
                <Input
                  type="text"
                  placeholder="Write a comment..."
                  className="w-full"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleComment();
                    }
                  }}
                />
                <Button size="sm" onClick={handleComment}>Post</Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PostCard;
