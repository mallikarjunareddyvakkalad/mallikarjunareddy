import { Link } from "wouter";
import { 
  FaFacebookF, 
  FaTwitter, 
  FaInstagram, 
  FaLinkedinIn, 
  FaYoutube 
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          <div className="md:col-span-2">
            <span className="text-2xl font-bold font-montserrat text-white">
              Eazy<span className="text-secondary">Buy</span><span className="text-accent">Sells</span>
            </span>
            <p className="mt-4 text-gray-300">
              A multi-purpose marketplace platform where users can buy, sell, engage, and earn all in one place.
            </p>
            <div className="mt-6 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <FaFacebookF size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <FaTwitter size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <FaInstagram size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <FaLinkedinIn size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <FaYoutube size={18} />
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Marketplace</h3>
            <ul className="space-y-2">
              <li><Link href="/marketplace"><a className="text-gray-400 hover:text-white">Browse Products</a></Link></li>
              <li><Link href="/dashboard?tab=products"><a className="text-gray-400 hover:text-white">Sell Items</a></Link></li>
              <li><Link href="/marketplace?type=service"><a className="text-gray-400 hover:text-white">Services</a></Link></li>
              <li><Link href="/marketplace?featured=true"><a className="text-gray-400 hover:text-white">Featured Listings</a></Link></li>
              <li><Link href="/marketplace"><a className="text-gray-400 hover:text-white">Categories</a></Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Community</h3>
            <ul className="space-y-2">
              <li><Link href="/community?tab=groups"><a className="text-gray-400 hover:text-white">Groups</a></Link></li>
              <li><Link href="/community?tab=forums"><a className="text-gray-400 hover:text-white">Forums</a></Link></li>
              <li><Link href="/community?tab=events"><a className="text-gray-400 hover:text-white">Events</a></Link></li>
              <li><Link href="/community?tab=blog"><a className="text-gray-400 hover:text-white">Blog</a></Link></li>
              <li><Link href="/jobs"><a className="text-gray-400 hover:text-white">Jobs & Gigs</a></Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Earn Points</h3>
            <ul className="space-y-2">
              <li><Link href="/affiliate"><a className="text-gray-400 hover:text-white">Affiliate Program</a></Link></li>
              <li><Link href="/affiliate?tab=referral"><a className="text-gray-400 hover:text-white">Referral System</a></Link></li>
              <li><Link href="/affiliate?tab=rewards"><a className="text-gray-400 hover:text-white">Rewards Center</a></Link></li>
              <li><Link href="/affiliate?tab=withdraw"><a className="text-gray-400 hover:text-white">Point Withdrawal</a></Link></li>
              <li><Link href="/affiliate?tab=history"><a className="text-gray-400 hover:text-white">Earning History</a></Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-gray-700 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} EazyBuySells. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-white text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-white text-sm">Terms of Service</a>
            <a href="#" className="text-gray-400 hover:text-white text-sm">Help Center</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
