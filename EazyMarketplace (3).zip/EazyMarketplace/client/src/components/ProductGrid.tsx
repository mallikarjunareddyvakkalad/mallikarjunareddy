import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import ProductCard, { ProductCardProps } from "@/components/ProductCard";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

type ProductGridProps = {
  title: string;
  category?: string;
  limit?: number;
  showFilters?: boolean;
  showViewAll?: boolean;
};

const ProductGrid = ({
  title,
  category,
  limit = 4,
  showFilters = true,
  showViewAll = true,
}: ProductGridProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(category || "All Categories");

  const { data: products, isLoading, error } = useQuery({
    queryKey: ['/api/products', { category: selectedCategory !== "All Categories" ? selectedCategory : undefined, limit }],
  });

  const handleCategoryChange = (value: string) => {
    setSelectedCategory(value);
  };

  const categories = [
    "All Categories",
    "Electronics",
    "Fashion",
    "Home & Garden",
    "Services",
    "Beauty",
    "Sports",
    "Books & Education",
  ];

  // Create placeholders for loading state
  const loadingPlaceholders = Array(limit).fill(0).map((_, index) => (
    <div key={`loading-${index}`} className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100">
      <Skeleton className="h-48 w-full" />
      <div className="p-4">
        <Skeleton className="h-4 w-3/4 mb-2" />
        <Skeleton className="h-3 w-1/2 mb-3" />
        <Skeleton className="h-5 w-1/4 mb-3" />
        <div className="flex justify-between">
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-4 w-1/4" />
        </div>
      </div>
    </div>
  ));

  return (
    <div className="mb-16">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold font-inter">{title}</h2>
        {showFilters && (
          <div className="flex items-center">
            <div className="relative mr-4">
              <Select value={selectedCategory} onValueChange={handleCategoryChange}>
                <SelectTrigger className="min-w-[160px]">
                  <SelectValue>{selectedCategory}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {showViewAll && (
              <Button variant="link" className="text-primary text-sm font-medium">
                View All
                <svg className="ml-2 w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Button>
            )}
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {isLoading ? (
          loadingPlaceholders
        ) : error ? (
          <div className="col-span-full text-center py-10">
            <p className="text-red-500">Failed to load products. Please try again later.</p>
          </div>
        ) : products && products.length > 0 ? (
          products.map((product: any) => (
            <ProductCard
              key={product.id}
              id={product.id}
              title={product.title}
              price={product.price}
              originalPrice={product.originalPrice}
              category={product.category}
              location={product.location || "Online"}
              rating={product.rating}
              image={product.images ? product.images[0] : undefined}
              isNew={new Date(product.createdAt).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000}
              isService={product.isService}
            />
          ))
        ) : (
          <div className="col-span-full text-center py-10">
            <p className="text-gray-500">No products found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductGrid;
