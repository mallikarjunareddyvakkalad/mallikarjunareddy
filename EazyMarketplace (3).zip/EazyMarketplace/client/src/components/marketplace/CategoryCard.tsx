import { Link } from "wouter";
import { Category } from "@shared/schema";

interface CategoryCardProps {
  category: Category;
}

const CategoryCard = ({ category }: CategoryCardProps) => {
  // Function to determine icon color class
  const getIconColorClass = (slug: string) => {
    const colorMap: Record<string, string> = {
      'electronics': 'primary',
      'fashion': 'secondary',
      'home': 'accent',
      'jobs': 'purple',
      'services': 'blue',
      'digital-products': 'orange'
    };
    
    return colorMap[slug] || 'primary';
  };

  const iconColor = getIconColorClass(category.slug);

  return (
    <Link 
      href={`/category/${category.slug}`} 
      className="bg-white shadow-sm rounded-lg p-4 flex flex-col items-center justify-center hover:shadow-md transition-shadow group"
    >
      <div 
        className={`w-12 h-12 rounded-full bg-${iconColor}/10 flex items-center justify-center text-${iconColor} group-hover:bg-${iconColor} group-hover:text-white transition-colors`}
      >
        <i className={`${category.icon || 'ri-price-tag-3-line'} text-2xl`}></i>
      </div>
      <span className="mt-2 text-center text-sm font-medium text-gray-700">
        {category.name}
      </span>
    </Link>
  );
};

export default CategoryCard;
