import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MapPin, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const [liked, setLiked] = useState(false);

  const toggleLike = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setLiked(!liked);
  };

  // Format the createdAt date
  const timeAgo = product.createdAt 
    ? formatDistanceToNow(new Date(product.createdAt), { addSuffix: true })
    : 'recently';

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img
          src={product.image || "https://via.placeholder.com/400x300?text=No+Image"}
          alt={product.title}
          className="w-full h-48 object-cover"
        />
        {product.status === 'active' && (
          <div className="absolute top-2 right-2 bg-primary text-white text-xs font-semibold px-2 py-1 rounded">
            TRENDING
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="font-montserrat text-lg font-semibold text-gray-800 mb-1 truncate">
            {product.title}
          </h3>
          <button 
            className={`text-gray-400 hover:text-primary ${liked ? 'text-red-500' : ''}`}
            onClick={toggleLike}
            aria-label={liked ? "Unlike" : "Like"}
          >
            <Heart className={`h-5 w-5 ${liked ? 'fill-current' : ''}`} />
          </button>
        </div>

        <div className="flex items-center mb-2">
          <div className="flex text-yellow-400 text-sm">
            <i className="ri-star-fill"></i>
            <i className="ri-star-fill"></i>
            <i className="ri-star-fill"></i>
            <i className="ri-star-fill"></i>
            <i className="ri-star-half-fill"></i>
          </div>
          <span className="text-xs text-gray-500 ml-1">
            ({product.views || 0})
          </span>
        </div>

        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {product.description || "No description available"}
        </p>

        <div className="flex justify-between items-center">
          <div className="font-montserrat text-lg font-semibold text-gray-900">
            ₹{product.price.toLocaleString('en-IN')}
          </div>
          <Button 
            asChild
            size="sm"
            className="bg-primary text-white hover:bg-primary-dark transition"
          >
            <Link href={`/product/${product.id}`}>
              View Details
            </Link>
          </Button>
        </div>

        <div className="mt-3 flex items-center text-xs text-gray-500">
          <MapPin className="mr-1 h-3 w-3" />
          <span>{product.location || "Unknown"}</span>
          <span className="mx-2">•</span>
          <Clock className="mr-1 h-3 w-3" />
          <span>{timeAgo}</span>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;
