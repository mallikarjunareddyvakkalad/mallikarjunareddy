import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const AffiliateSection = () => {
  return (
    <div className="mt-12 bg-gradient-to-r from-secondary to-secondary-dark rounded-xl overflow-hidden shadow-lg">
      <div className="flex flex-col md:flex-row items-center">
        <div className="p-6 md:p-8 md:w-2/3">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-3">
            Become an Affiliate & Earn Points!
          </h2>
          <p className="text-white/90 mb-6">
            Share product links, refer friends, and earn points for every successful conversion. 
            Convert points to rupees when you reach 100 points!
          </p>
          <div className="flex flex-wrap gap-4">
            <Button 
              asChild
              className="bg-white text-secondary font-semibold px-6 py-3 hover:bg-gray-100 transition duration-200"
            >
              <Link href="/affiliates">Start Earning Now</Link>
            </Button>
            <Button 
              asChild
              variant="outline"
              className="bg-secondary-dark text-white border border-white/30 font-semibold px-6 py-3 hover:bg-secondary-dark/80 transition duration-200"
            >
              <Link href="/affiliates/about">Learn More</Link>
            </Button>
          </div>
          <div className="mt-4 text-white/80 text-sm">
            Already earned: <span className="font-semibold">₹248</span> by our top affiliates this month!
          </div>
        </div>
        <div className="hidden md:block md:w-1/3">
          <img
            src="https://images.unsplash.com/photo-1579389083078-4e7018379f7e?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=300&w=300"
            alt="Earn Rewards"
            className="w-full h-64 object-cover"
          />
        </div>
      </div>
    </div>
  );
};

export default AffiliateSection;
