import { Link } from "wouter";
import { Heart, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export type ProductCardProps = {
  id: number;
  title: string;
  price: number;
  originalPrice?: number;
  category: string;
  location: string;
  rating?: number;
  image?: string;
  isNew?: boolean;
  isService?: boolean;
  onShare?: (id: number) => void;
  onFavorite?: (id: number) => void;
};

const ProductCard = ({
  id,
  title,
  price,
  originalPrice,
  category,
  location,
  rating,
  image,
  isNew,
  isService,
  onShare,
  onFavorite,
}: ProductCardProps) => {
  const { toast } = useToast();

  const handleShare = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (onShare) {
      onShare(id);
    } else {
      // Copy product URL to clipboard
      const url = `${window.location.origin}/product/${id}`;
      navigator.clipboard.writeText(url);
      
      toast({
        title: "Link copied!",
        description: "Product link copied to clipboard",
      });
    }
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (onFavorite) {
      onFavorite(id);
    } else {
      toast({
        title: "Added to favorites!",
        description: "This product has been added to your favorites",
      });
    }
  };

  const defaultImage = "https://images.unsplash.com/photo-1553531384-cc64ac80f931?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=350&q=80";

  return (
    <Card className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-md transition group">
      <Link href={`/product/${id}`}>
        <a className="block">
          <div className="relative">
            <img 
              src={image || defaultImage} 
              className="h-48 w-full object-cover" 
              alt={title} 
            />
            <div className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-sm">
              <button 
                className="text-gray-400 hover:text-primary"
                onClick={handleFavorite}
              >
                <Heart size={16} />
              </button>
            </div>
            <div className="absolute bottom-2 left-2">
              {isNew && (
                <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                  New
                </Badge>
              )}
              {isService && (
                <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">
                  Service
                </Badge>
              )}
            </div>
          </div>
          <div className="p-4">
            <div className="flex justify-between items-start">
              <h3 className="text-sm font-medium text-gray-900 group-hover:text-primary">{title}</h3>
              {rating && (
                <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
                  {rating} ⭐
                </Badge>
              )}
            </div>
            <p className="mt-1 text-xs text-gray-500">{category} • {location}</p>
            <div className="mt-3 flex justify-between items-center">
              <span className="text-lg font-semibold">₹{price.toLocaleString()}</span>
              {originalPrice && (
                <span className="text-xs line-through text-gray-400">₹{originalPrice.toLocaleString()}</span>
              )}
            </div>
            <div className="mt-3 flex justify-between">
              <Button 
                variant="link" 
                className="text-primary text-sm font-medium p-0 h-auto"
              >
                Contact Seller
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs bg-gray-100 px-2 py-1 rounded-md text-gray-600 hover:bg-gray-200 h-auto"
                onClick={handleShare}
              >
                <Share2 size={12} className="mr-1" /> Share
              </Button>
            </div>
          </div>
        </a>
      </Link>
    </Card>
  );
};

export default ProductCard;
