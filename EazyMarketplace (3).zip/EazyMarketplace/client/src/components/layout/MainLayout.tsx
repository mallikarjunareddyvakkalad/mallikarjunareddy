import { ReactNode, useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import AIAssistant from "../chat/AIAssistant";
import { Button } from "@/components/ui/button";
import { MessageSquareText } from "lucide-react";

interface MainLayoutProps {
  children: ReactNode;
}

const MainLayout = ({ children }: MainLayoutProps) => {
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);

  const toggleAIAssistant = () => {
    setIsAIAssistantOpen(!isAIAssistantOpen);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">{children}</main>
      <Footer />

      {/* Floating Chat Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <Button
          onClick={toggleAIAssistant}
          className="bg-primary w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-white hover:bg-primary-dark transition-colors"
          aria-label="Chat Assistant"
        >
          <MessageSquareText className="h-6 w-6" />
        </Button>
      </div>

      {/* AI Assistant Dialog */}
      <AIAssistant 
        isOpen={isAIAssistantOpen} 
        onClose={() => setIsAIAssistantOpen(false)} 
      />
    </div>
  );
};

export default MainLayout;
