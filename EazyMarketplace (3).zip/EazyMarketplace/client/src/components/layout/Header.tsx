import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bell, MessageSquare, Search, ChevronDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const Header = () => {
  const [location] = useLocation();
  const [mobileSearchVisible, setMobileSearchVisible] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const [userInitials, setUserInitials] = useState("US");

  // Fetch notifications count
  const { data: notifications } = useQuery({
    queryKey: ["/api/notifications"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Calculate notification and message counts
  const notificationCount = Array.isArray(notifications) 
    ? notifications.filter((n: any) => !n.read).length 
    : 0;
  const messageCount = 0; // This would be fetched from the chat context in a full implementation

  // Set user initials for avatar
  useEffect(() => {
    if (user?.name) {
      const nameParts = user.name.split(" ");
      if (nameParts.length >= 2) {
        setUserInitials(
          `${nameParts[0].charAt(0)}${nameParts[nameParts.length - 1].charAt(0)}`
        );
      } else {
        setUserInitials(user.name.substring(0, 2).toUpperCase());
      }
    } else if (user?.username) {
      setUserInitials(user.username.substring(0, 2).toUpperCase());
    }
  }, [user]);

  // Get initials from username or name
  const getInitials = (user: User | null) => {
    if (!user) return "US";
    if (user.name) {
      const nameParts = user.name.split(" ");
      if (nameParts.length >= 2) {
        return `${nameParts[0].charAt(0)}${nameParts[nameParts.length - 1].charAt(0)}`;
      }
      return user.name.substring(0, 2).toUpperCase();
    }
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50 border-b border-purple-100">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <i className="ri-shopping-bag-3-line text-purple-600 text-3xl mr-2"></i>
              <span className="font-poppins font-bold text-xl underline-effect logo-text">
                <span className="text-purple-900">Eazy</span>
                <span className="text-teal-800">Buy</span>
                <span className="text-amber-700">Sells</span>
              </span>
            </Link>
          </div>

          {/* Search */}
          <div className="hidden md:block flex-grow max-w-xl mx-6">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products, services, or posts..."
                className="w-full bg-gray-100 rounded-full py-2 px-4 pl-10 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:bg-white"
              />
              <Search className="absolute left-3 top-2.5 text-purple-400 h-5 w-5" />
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center space-x-1 md:space-x-3">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileSearchVisible(!mobileSearchVisible)}
            >
              <Search className="text-purple-600 h-5 w-5" />
            </Button>

            {isAuthenticated ? (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  asChild
                  className="relative hover:bg-purple-50"
                >
                  <Link href="/notifications">
                    <Bell className="text-purple-600 h-5 w-5" />
                    {notificationCount > 0 && (
                      <Badge
                        className="absolute top-0 right-0 bg-purple-600 text-white w-4 h-4 flex items-center justify-center p-0 text-xs"
                        style={{ transform: "translate(25%, -25%)" }}
                      >
                        {notificationCount}
                      </Badge>
                    )}
                  </Link>
                </Button>

                <Button
                  variant="ghost"
                  size="icon"
                  asChild
                  className="relative hover:bg-purple-50"
                >
                  <Link href="/chat">
                    <MessageSquare className="text-purple-600 h-5 w-5" />
                    {messageCount > 0 && (
                      <Badge
                        className="absolute top-0 right-0 bg-teal-600 text-white w-4 h-4 flex items-center justify-center p-0 text-xs"
                        style={{ transform: "translate(25%, -25%)" }}
                      >
                        {messageCount}
                      </Badge>
                    )}
                  </Link>
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="p-2 flex items-center text-purple-800 hover:text-purple-500 hover:bg-purple-50 btn-glow"
                    >
                      <div className="flex items-center space-x-1">
                        <Avatar className="h-8 w-8 border-2 border-purple-200">
                          <AvatarImage src={user?.avatar || ""} />
                          <AvatarFallback className="bg-purple-100 text-purple-800">{userInitials}</AvatarFallback>
                        </Avatar>
                        <span className="hidden md:block text-sm font-medium">
                          {user?.name || user?.username}
                        </span>
                        <ChevronDown className="h-4 w-4" />
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 border border-purple-200 rounded-lg shadow-lg">
                    <DropdownMenuLabel className="bg-purple-50">
                      <div className="font-semibold text-purple-900">{user?.name || user?.username}</div>
                      <div className="text-xs text-purple-600">{user?.email}</div>
                    </DropdownMenuLabel>
                    <DropdownMenuItem asChild>
                      <Link href="/profile" className="flex items-center cursor-pointer text-purple-700 hover:text-purple-900 hover:bg-purple-50">
                        <i className="ri-user-line mr-2 text-purple-500"></i> My Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard" className="flex items-center cursor-pointer text-purple-700 hover:text-purple-900 hover:bg-purple-50">
                        <i className="ri-dashboard-line mr-2 text-purple-500"></i> Seller Dashboard
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild className="cursor-pointer hover:bg-purple-50">
                      <div className="flex items-center text-purple-700">
                        <i className="ri-coins-line mr-2 text-gold-500"></i> Points:{" "}
                        <span className="font-semibold ml-1 text-purple-900">{user?.points || 0}</span>
                      </div>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-purple-100" />
                    <DropdownMenuItem
                      onClick={() => logout()}
                      className="text-red-600 cursor-pointer hover:bg-red-50"
                    >
                      <i className="ri-logout-box-line mr-2"></i> Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" asChild className="border-purple-600 text-purple-700 hover:bg-purple-50 hover:text-purple-900">
                  <Link href="/login">Log In</Link>
                </Button>
                <Button size="sm" asChild className="bg-primary-gradient text-white hover:opacity-90">
                  <Link href="/register">Sign Up</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Search (Hidden by Default) */}
      {mobileSearchVisible && (
        <div className="md:hidden px-4 pb-3">
          <div className="relative">
            <input
              type="text"
              placeholder="Search..."
              className="w-full bg-gray-100 rounded-full py-2 px-4 pl-10 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:bg-white"
            />
            <Search className="absolute left-3 top-2.5 text-purple-400 h-5 w-5" />
          </div>
        </div>
      )}

      {/* Navigation Bar */}
      <nav className="bg-white border-t border-purple-100 text-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center overflow-x-auto scrollbar-hide">
            <Link
              href="/"
              className={`flex-shrink-0 py-3 px-4 ${
                location === "/" 
                  ? "text-purple-600 border-b-2 border-purple-600 font-medium" 
                  : "text-gray-600 hover:text-purple-500"
              }`}
            >
              Marketplace
            </Link>
            <Link
              href="/community"
              className={`flex-shrink-0 py-3 px-4 ${
                location === "/community" 
                  ? "text-teal-600 border-b-2 border-teal-600 font-medium" 
                  : "text-gray-600 hover:text-teal-500"
              }`}
            >
              Community
            </Link>
            <Link
              href="/jobs"
              className={`flex-shrink-0 py-3 px-4 ${
                location === "/jobs" 
                  ? "text-purple-600 border-b-2 border-purple-600 font-medium" 
                  : "text-gray-600 hover:text-purple-500"
              }`}
            >
              Jobs & Gigs
            </Link>
            <Link
              href="/events"
              className={`flex-shrink-0 py-3 px-4 ${
                location === "/events" 
                  ? "text-teal-600 border-b-2 border-teal-600 font-medium" 
                  : "text-gray-600 hover:text-teal-500"
              }`}
            >
              Events
            </Link>
            <Link
              href="/blogs"
              className={`flex-shrink-0 py-3 px-4 ${
                location === "/blogs" 
                  ? "text-gold-600 border-b-2 border-gold-600 font-medium" 
                  : "text-gray-600 hover:text-gold-500"
              }`}
            >
              Blogs
            </Link>
            <Link
              href="/groups"
              className={`flex-shrink-0 py-3 px-4 ${
                location === "/groups" 
                  ? "text-purple-600 border-b-2 border-purple-600 font-medium" 
                  : "text-gray-600 hover:text-purple-500"
              }`}
            >
              Groups
            </Link>
            <Link
              href="/affiliates"
              className={`flex-shrink-0 py-3 px-4 ${
                location === "/affiliates" 
                  ? "text-gold-600 border-b-2 border-gold-600 font-medium" 
                  : "text-gray-600 hover:text-gold-500"
              }`}
            >
              Affiliates
            </Link>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;
