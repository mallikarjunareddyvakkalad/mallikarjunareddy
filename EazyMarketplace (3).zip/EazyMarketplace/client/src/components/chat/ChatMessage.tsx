import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from "date-fns";
import { PlayCircle, PauseCircle } from "lucide-react";
import { Message } from "@shared/schema";

interface ChatMessageProps {
  message: Message;
  isOwn: boolean;
  senderName: string;
  senderAvatar?: string;
  showSender?: boolean;
}

const ChatMessage = ({
  message,
  isOwn,
  senderName,
  senderAvatar,
  showSender = true,
}: ChatMessageProps) => {
  const [isPlaying, setIsPlaying] = useState(false);

  // Format timestamp
  const formattedTime = format(
    new Date(message.createdAt),
    "h:mm a"
  );

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    const names = name.split(" ");
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  // Handle voice message
  const handleVoicePlayback = () => {
    setIsPlaying(!isPlaying);
    // In a real implementation, we would play/pause the audio here
  };

  // Render different message types
  const renderMessageContent = () => {
    switch (message.type) {
      case "voice":
        return (
          <div className="flex items-center space-x-2 w-48 bg-gray-100 p-2 rounded-lg">
            <button 
              className="w-8 h-8 rounded-full bg-secondary text-white flex items-center justify-center"
              onClick={handleVoicePlayback}
            >
              {isPlaying ? <PauseCircle className="h-5 w-5" /> : <PlayCircle className="h-5 w-5" />}
            </button>
            <div className="w-full">
              <div className="h-1 bg-gray-300 rounded-full overflow-hidden">
                <div className="h-full w-1/3 bg-secondary"></div>
              </div>
              <div className="text-xs text-gray-500 mt-1">0:12 / 0:36</div>
            </div>
          </div>
        );
      case "image":
        return (
          <img 
            src={message.content} 
            alt="Image message" 
            className="max-w-xs rounded-md"
          />
        );
      default:
        return <p className={isOwn ? "text-white" : "text-gray-800"}>{message.content}</p>;
    }
  };

  return (
    <div className={`flex max-w-xs ${isOwn ? "ml-auto justify-end" : ""}`}>
      {!isOwn && showSender && (
        <Avatar className="flex-shrink-0 h-8 w-8 mr-2">
          <AvatarImage src={senderAvatar} />
          <AvatarFallback>{getInitials(senderName)}</AvatarFallback>
        </Avatar>
      )}
      <div>
        <div
          className={`p-3 rounded-lg shadow-sm ${
            isOwn
              ? "bg-primary chat-bubble-user"
              : "bg-white chat-bubble-others"
          }`}
        >
          {renderMessageContent()}
        </div>
        <div
          className={`text-xs text-gray-500 mt-1 ${
            isOwn ? "text-right mr-2" : "ml-2"
          }`}
        >
          {formattedTime}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
