import { useState, useRef, useEffect } from "react";
import { 
  Card, 
  CardHeader, 
  CardContent, 
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { X, Send, Bot } from "lucide-react";

interface Message {
  id: string;
  type: "ai" | "user";
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

const AIAssistant = ({ isOpen, onClose }: AIAssistantProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "initial",
      type: "ai",
      content: "👋 Hello! I'm your AI assistant. How can I help you with EazyBuySells today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  // Generate AI response
  const generateResponse = useMutation({
    mutationFn: async (prompt: string) => {
      const res = await apiRequest("POST", "/api/ai/generate-content", {
        type: "message_response",
        prompt,
        tone: "casual"
      });
      return res.json();
    },
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          type: "ai",
          content: data.content,
          timestamp: new Date(),
        },
      ]);
    },
    onError: () => {
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          type: "ai",
          content: "I'm sorry, I'm having trouble processing your request right now. Please try again later.",
          timestamp: new Date(),
        },
      ]);
    },
  });

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    
    // Generate AI response
    generateResponse.mutate(inputValue);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <Card className={`fixed bottom-24 right-6 w-80 bg-white rounded-xl shadow-2xl overflow-hidden z-40 transition-all duration-300 ${isOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}>
      <CardHeader className="bg-primary text-white p-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Avatar className="w-8 h-8 mr-2 bg-white/20">
              <AvatarFallback>AI</AvatarFallback>
              <AvatarImage>
                <Bot className="text-white" />
              </AvatarImage>
            </Avatar>
            <h3 className="font-medium">AI Assistant</h3>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose}
            className="text-white/80 hover:text-white hover:bg-white/10"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="h-80 overflow-y-auto p-4 flex flex-col space-y-3">
        {messages.map((message) => (
          <div key={message.id} className="flex max-w-xs">
            {message.type === "ai" ? (
              <>
                <Avatar className="h-8 w-8 mr-2 bg-primary/10 text-primary">
                  <AvatarFallback>AI</AvatarFallback>
                  <AvatarImage>
                    <Bot className="h-4 w-4 text-primary" />
                  </AvatarImage>
                </Avatar>
                <div>
                  <div className="bg-gray-100 p-3 rounded-lg chat-bubble-others">
                    <p className="text-gray-800 text-sm">{message.content}</p>
                  </div>
                  <div className="text-xs text-gray-500 mt-1 ml-2">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </>
            ) : (
              <div className="flex max-w-xs ml-auto justify-end">
                <div>
                  <div className="bg-primary p-3 rounded-lg chat-bubble-user">
                    <p className="text-white text-sm">{message.content}</p>
                  </div>
                  <div className="text-xs text-gray-500 mt-1 mr-2 text-right">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
        
        {generateResponse.isPending && (
          <div className="flex max-w-xs">
            <Avatar className="h-8 w-8 mr-2 bg-primary/10 text-primary">
              <AvatarFallback>AI</AvatarFallback>
              <AvatarImage>
                <Bot className="h-4 w-4 text-primary" />
              </AvatarImage>
            </Avatar>
            <div>
              <div className="bg-gray-100 p-3 rounded-lg chat-bubble-others flex items-center space-x-1">
                <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                <div className="h-2 w-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></div>
              </div>
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="p-3 border-t">
        <div className="flex items-end w-full">
          <Input
            type="text"
            placeholder="Ask me anything..."
            className="flex-grow text-sm"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={generateResponse.isPending}
          />
          <Button
            size="icon"
            className="ml-2 bg-primary text-white hover:bg-primary-dark"
            onClick={handleSendMessage}
            disabled={generateResponse.isPending || !inputValue.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default AIAssistant;
