import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

interface ChatContactProps {
  id: number;
  name: string;
  avatar?: string;
  lastMessage?: string;
  timestamp?: Date;
  unreadCount?: number;
  isOnline?: boolean;
  isActive?: boolean;
  onClick: (id: number) => void;
}

const ChatContact = ({
  id,
  name,
  avatar,
  lastMessage,
  timestamp,
  unreadCount = 0,
  isOnline = false,
  isActive = false,
  onClick,
}: ChatContactProps) => {
  // Format timestamp
  const timeAgo = timestamp
    ? formatDistanceToNow(new Date(timestamp), { addSuffix: false })
    : "";

  // Get initials for avatar fallback
  const getInitials = (name: string) => {
    const names = name.split(" ");
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  // Is this a group chat?
  const isGroup = name.includes("Group") || name.includes("Team");

  return (
    <div
      className={`flex items-center p-3 hover:bg-gray-50 border-b cursor-pointer ${
        isActive ? "bg-gray-50" : ""
      }`}
      onClick={() => onClick(id)}
    >
      <div className="relative mr-3">
        <Avatar className="h-12 w-12">
          <AvatarImage src={avatar} />
          <AvatarFallback>
            {isGroup ? name.substring(0, 2).toUpperCase() : getInitials(name)}
          </AvatarFallback>
        </Avatar>
        {isOnline && (
          <div className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-white"></div>
        )}
      </div>
      <div className="flex-grow mr-3">
        <div className="flex justify-between">
          <div className="font-medium text-gray-800">{name}</div>
          <div className="text-xs text-gray-500">{timeAgo}</div>
        </div>
        <div className="flex">
          <p className="text-sm text-gray-600 line-clamp-1">{lastMessage || "No messages yet"}</p>
          {unreadCount > 0 && (
            <Badge className="ml-auto flex-shrink-0 bg-primary text-white h-5 w-5 flex items-center justify-center p-0 text-xs">
              {unreadCount}
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatContact;
