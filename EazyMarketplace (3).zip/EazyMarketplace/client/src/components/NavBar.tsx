import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Bell, Mail, Search, Menu, User, LogOut, ShoppingBag, BarChart2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const NavBar = () => {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle search logic here
    console.log("Searching for:", searchQuery);
    window.location.href = `/marketplace?search=${encodeURIComponent(searchQuery)}`;
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <div className="text-2xl font-bold font-montserrat text-primary cursor-pointer">
                  Eazy<span className="text-secondary">Buy</span>
                  <span className="text-accent">Sells</span>
                </div>
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link href="/marketplace">
                <div className={`${
                  location === "/marketplace" 
                    ? "border-primary text-gray-900" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                  Marketplace
                </div>
              </Link>
              <Link href="/community">
                <div className={`${
                  location === "/community" 
                    ? "border-primary text-gray-900" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                  Community
                </div>
              </Link>
              <Link href="/jobs">
                <div className={`${
                  location === "/jobs" 
                    ? "border-primary text-gray-900" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                  Jobs & Gigs
                </div>
              </Link>
              <Link href="/affiliate">
                <div className={`${
                  location === "/affiliate" 
                    ? "border-primary text-gray-900" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium`}>
                  Affiliate Program
                </div>
              </Link>
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            {/* Search bar */}
            <form onSubmit={handleSearch} className="relative mr-4">
              <Input
                type="text"
                placeholder="Search products, services, posts..."
                className="w-64 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button
                type="submit"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-2 text-gray-500"
              >
                <Search size={16} />
              </Button>
            </form>

            {isAuthenticated && user ? (
              <>
                {/* Credits indicator */}
                <div className="bg-gray-100 rounded-full px-3 py-1 flex items-center mr-3">
                  <span className="text-xs font-semibold text-gray-700 mr-1">₹</span>
                  <span className="text-sm font-semibold text-gray-800">{user.points}</span>
                </div>

                {/* Notifications */}
                <Button variant="ghost" size="icon" className="relative">
                  <Bell size={20} className="text-gray-500" />
                  <Badge variant="destructive" className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0">
                    3
                  </Badge>
                </Button>

                {/* Messages */}
                <Button variant="ghost" size="icon" className="ml-3 relative">
                  <Mail size={20} className="text-gray-500" />
                  <Badge variant="default" className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 bg-primary">
                    5
                  </Badge>
                </Button>

                {/* Profile dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="ml-3 relative rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.avatar || "https://ui-avatars.com/api/?name=" + user.username} alt={user.username} />
                        <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => window.location.href = `/profile/${user.id}`}>
                      <User size={16} className="mr-2" /> Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => window.location.href = "/dashboard"}>
                      <BarChart2 size={16} className="mr-2" /> Dashboard
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => window.location.href = "/dashboard?tab=products"}>
                      <ShoppingBag size={16} className="mr-2" /> My Products
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => logout()}>
                      <LogOut size={16} className="mr-2" /> Sign out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex space-x-2">
                <Link href="/login">
                  <Button variant="outline">Sign In</Button>
                </Link>
                <Link href="/register">
                  <Button>Register</Button>
                </Link>
              </div>
            )}
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
            >
              <Menu size={20} />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="sm:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <Link href="/marketplace">
              <div className={`${
                location === "/marketplace" 
                  ? "bg-primary text-white" 
                  : "text-gray-700 hover:bg-gray-100"
              } block px-3 py-2 rounded-md text-base font-medium`}>
                Marketplace
              </div>
            </Link>
            <Link href="/community">
              <div className={`${
                location === "/community" 
                  ? "bg-primary text-white" 
                  : "text-gray-700 hover:bg-gray-100"
              } block px-3 py-2 rounded-md text-base font-medium`}>
                Community
              </div>
            </Link>
            <Link href="/jobs">
              <div className={`${
                location === "/jobs" 
                  ? "bg-primary text-white" 
                  : "text-gray-700 hover:bg-gray-100"
              } block px-3 py-2 rounded-md text-base font-medium`}>
                Jobs & Gigs
              </div>
            </Link>
            <Link href="/affiliate">
              <div className={`${
                location === "/affiliate" 
                  ? "bg-primary text-white" 
                  : "text-gray-700 hover:bg-gray-100"
              } block px-3 py-2 rounded-md text-base font-medium`}>
                Affiliate Program
              </div>
            </Link>
          </div>
          <div className="pt-4 pb-3 border-t border-gray-200">
            {isAuthenticated && user ? (
              <div className="flex items-center px-5">
                <div className="flex-shrink-0">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.avatar || "https://ui-avatars.com/api/?name=" + user.username} alt={user.username} />
                    <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="ml-3">
                  <div className="text-base font-medium text-gray-800">{user.fullName || user.username}</div>
                  <div className="text-sm font-medium text-gray-500">{user.email}</div>
                </div>
                <div className="ml-auto flex space-x-2">
                  <Button variant="ghost" size="icon">
                    <Bell size={20} className="text-gray-500" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Mail size={20} className="text-gray-500" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="px-5 flex flex-col space-y-2">
                <Link href="/login">
                  <Button className="w-full" variant="outline">Sign In</Button>
                </Link>
                <Link href="/register">
                  <Button className="w-full">Register</Button>
                </Link>
              </div>
            )}
            {isAuthenticated && (
              <div className="mt-3 px-2 space-y-1">
                <Link href={`/profile/${user?.id}`}>
                  <div className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100">Profile</div>
                </Link>
                <Link href="/dashboard">
                  <div className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100">Dashboard</div>
                </Link>
                <Link href="/dashboard?tab=products">
                  <div className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100">My Products</div>
                </Link>
                <button 
                  onClick={() => logout()}
                  className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100"
                >
                  Sign out
                </button>
              </div>
            )}
          </div>
          <div className="px-4 py-2 border-t border-gray-200">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Search products, services, posts..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button
                type="submit"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-2 text-gray-500"
              >
                <Search size={16} />
              </Button>
            </form>
          </div>
        </div>
      )}
    </nav>
  );
};

export default NavBar;
