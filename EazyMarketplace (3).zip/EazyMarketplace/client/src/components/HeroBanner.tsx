import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

type HeroBannerProps = {
  onRegister?: () => void;
};

const HeroBanner = ({ onRegister }: HeroBannerProps) => {
  const { isAuthenticated, register } = useAuth();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    username: "",
    referralCode: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.email || !formData.password || !formData.username) {
      toast({
        title: "Missing fields",
        description: "Please fill all required fields",
        variant: "destructive",
      });
      return;
    }
    
    try {
      let referredBy;
      
      // If referral code is provided, look up the user
      if (formData.referralCode) {
        const response = await fetch(`/api/users/referral/${formData.referralCode}`);
        if (response.ok) {
          const data = await response.json();
          referredBy = data.id;
        }
      }
      
      await register({
        email: formData.email,
        password: formData.password,
        username: formData.username,
        referredBy,
      });
      
      if (onRegister) {
        onRegister();
      }
    } catch (error) {
      console.error("Registration failed:", error);
    }
  };

  return (
    <div className="relative bg-primary rounded-xl overflow-hidden mb-8">
      <div className="absolute inset-0">
        <img 
          className="w-full h-full object-cover opacity-20" 
          src="https://images.unsplash.com/photo-1557821552-17105176677c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
          alt="Marketplace background" 
        />
      </div>
      <div className="relative px-6 py-12 sm:px-12 sm:py-16 lg:py-20 lg:px-16 flex flex-col md:flex-row items-center">
        <div className="text-center md:text-left md:w-1/2 mb-8 md:mb-0">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white font-inter leading-tight">
            Buy, Sell & Earn <br />in One Place
          </h1>
          <p className="mt-3 text-lg text-gray-100 sm:mt-5">
            Join our growing community to buy products, sell services, and earn through our affiliate program.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row justify-center md:justify-start gap-4">
            <Link href="/marketplace">
              <Button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-primary bg-white hover:bg-gray-50">
                Start Selling
              </Button>
            </Link>
            <Link href="/affiliate">
              <Button variant="outline" className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white/10">
                Earn ₹ Points
              </Button>
            </Link>
          </div>
        </div>
        <div className="md:w-1/2 flex justify-center md:justify-end">
          {isAuthenticated ? (
            <Card className="bg-white/90 p-6 rounded-lg shadow-lg max-w-md w-full">
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Welcome Back!</h3>
                <p className="text-gray-600">
                  You're already logged in. Explore the marketplace, engage with the community, or check your dashboard.
                </p>
                <div className="mt-6 flex flex-col space-y-3">
                  <Link href="/marketplace">
                    <Button className="w-full">Browse Marketplace</Button>
                  </Link>
                  <Link href="/dashboard">
                    <Button variant="outline" className="w-full">Go to Dashboard</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-white/90 p-6 rounded-lg shadow-lg max-w-md w-full">
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Join Now & Get 2 Free Points</h3>
                <form className="space-y-4" onSubmit={handleSubmit}>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      type="email" 
                      id="email" 
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="mt-1 block w-full" 
                      placeholder="Your email" 
                    />
                  </div>
                  <div>
                    <Label htmlFor="username">Username</Label>
                    <Input 
                      type="text" 
                      id="username" 
                      name="username"
                      value={formData.username}
                      onChange={handleChange}
                      className="mt-1 block w-full" 
                      placeholder="Choose a username" 
                    />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input 
                      type="password" 
                      id="password" 
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      className="mt-1 block w-full" 
                      placeholder="Create a password" 
                    />
                  </div>
                  <div>
                    <Label htmlFor="referralCode">Referral Code (Optional)</Label>
                    <Input 
                      type="text" 
                      id="referralCode" 
                      name="referralCode"
                      value={formData.referralCode}
                      onChange={handleChange}
                      className="mt-1 block w-full" 
                      placeholder="Enter referral code" 
                    />
                  </div>
                  <Button type="submit" className="w-full bg-primary text-white">
                    Sign Up & Get ₹2 Points
                  </Button>
                </form>
                <p className="mt-4 text-sm text-gray-600 text-center">
                  Already have an account? <Link href="/login"><a className="text-primary font-medium">Sign in</a></Link>
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default HeroBanner;
