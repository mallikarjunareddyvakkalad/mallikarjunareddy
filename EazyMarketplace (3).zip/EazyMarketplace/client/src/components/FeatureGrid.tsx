import { Link } from "wouter";
import { Store, Users, BanknoteIcon } from "lucide-react";

type Feature = {
  icon: React.ReactNode;
  title: string;
  description: string;
  linkText: string;
  linkUrl: string;
  iconBgColor: string;
  iconColor: string;
  linkColor: string;
};

const features: Feature[] = [
  {
    icon: <Store className="text-primary text-xl" />,
    title: "Marketplace",
    description: "Buy, sell, or promote products and services with ease. Post your listings and reach potential customers.",
    linkText: "Explore Marketplace",
    linkUrl: "/marketplace",
    iconBgColor: "bg-primary/10",
    iconColor: "text-primary",
    linkColor: "text-primary",
  },
  {
    icon: <Users className="text-secondary text-xl" />,
    title: "Community",
    description: "Join groups, participate in discussions, share blog posts, and connect with like-minded people.",
    linkText: "Join Community",
    linkUrl: "/community",
    iconBgColor: "bg-secondary/10",
    iconColor: "text-secondary",
    linkColor: "text-secondary",
  },
  {
    icon: <BanknoteIcon className="text-accent text-xl" />,
    title: "Earn Points",
    description: "Earn points by referring friends, promoting products as an affiliate, and participating in activities.",
    linkText: "Start Earning",
    linkUrl: "/affiliate",
    iconBgColor: "bg-accent/10",
    iconColor: "text-accent",
    linkColor: "text-accent",
  },
];

const FeatureGrid = () => {
  return (
    <div className="mb-16">
      <h2 className="text-2xl font-bold text-center mb-12 font-inter">Everything You Need in One Platform</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition">
            <div className={`w-12 h-12 ${feature.iconBgColor} rounded-lg flex items-center justify-center mb-4`}>
              {feature.icon}
            </div>
            <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
            <p className="text-gray-600">
              {feature.description}
            </p>
            <div className="mt-4">
              <Link href={feature.linkUrl}>
                <a className={`${feature.linkColor} text-sm font-medium flex items-center`}>
                  {feature.linkText}
                  <svg className="ml-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FeatureGrid;
