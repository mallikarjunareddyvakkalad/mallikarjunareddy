import { Link } from "wouter";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarDays, MapPin, Users } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Event } from "@shared/schema";

interface EventCardProps {
  event: Event;
  isUpcoming?: boolean;
}

const EventCard = ({ event, isUpcoming = false }: EventCardProps) => {
  // Format event date
  const eventDate = event.startTime 
    ? format(new Date(event.startTime), "MMM d, yyyy • h:mm a")
    : "Date not specified";

  // Render avatar stack for attendees (placeholder)
  const renderAttendees = () => {
    return (
      <div className="flex -space-x-2 mr-2">
        {[1, 2, 3].map((i) => (
          <Avatar key={i} className="h-6 w-6 border-2 border-white">
            <AvatarImage src={`https://i.pravatar.cc/100?img=${i + 10}`} />
            <AvatarFallback>U{i}</AvatarFallback>
          </Avatar>
        ))}
        <div className="h-6 w-6 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center text-xs font-medium">
          +{event.attendees ? event.attendees - 3 : 98}
        </div>
      </div>
    );
  };

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img
          src={event.image || "https://images.unsplash.com/photo-1540317580384-e5d43616b9aa?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=200&w=400"}
          alt={event.title}
          className="w-full h-40 object-cover"
        />
        {isUpcoming && (
          <div className="absolute top-2 right-2 bg-secondary text-white text-xs font-semibold px-2 py-1 rounded">
            UPCOMING
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="flex items-center mb-3">
          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-secondary/10 text-secondary mr-2">
            <CalendarDays className="h-4 w-4" />
          </div>
          <div className="text-sm font-medium text-gray-800">{eventDate}</div>
        </div>
        <h3 className="text-lg font-semibold text-gray-800 mb-2">
          {event.title}
        </h3>
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {event.description || "Join this exciting event to learn, connect, and grow your network."}
        </p>
        <div className="flex items-center text-sm text-gray-600 mb-3">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{event.location || "Online"}</span>
        </div>
        <div className="flex justify-between items-center">
          <div className="flex items-center text-sm">
            {renderAttendees()}
            <span className="text-gray-500">
              <Users className="h-3 w-3 inline mr-1" />
              {event.attendees || 100} attending
            </span>
          </div>
          <Button
            size="sm"
            className="bg-secondary text-white hover:bg-secondary-dark transition"
            asChild
          >
            <Link href={`/events/${event.id}`}>Join Event</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default EventCard;
