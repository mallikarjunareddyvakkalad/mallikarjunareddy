import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MessageSquare } from "lucide-react";
import { Blog, User } from "@shared/schema";

interface BlogCardProps {
  blog: Blog;
  author?: User;
}

const BlogCard = ({ blog, author }: BlogCardProps) => {
  // Format the creation date
  const timeAgo = blog.createdAt 
    ? formatDistanceToNow(new Date(blog.createdAt), { addSuffix: true })
    : 'recently';

  const getAuthorInitials = () => {
    if (!author?.name) return "UN";
    const names = author.name.split(" ");
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return author.name.substring(0, 2).toUpperCase();
  };

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <img
        src={blog.image || "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&h=200&w=400"}
        alt={blog.title}
        className="w-full h-40 object-cover"
      />
      <CardContent className="p-4">
        <div className="flex items-center mb-3">
          <Avatar className="h-8 w-8 mr-2">
            <AvatarImage src={author?.avatar} />
            <AvatarFallback>{getAuthorInitials()}</AvatarFallback>
          </Avatar>
          <div>
            <div className="text-sm font-medium text-gray-800">
              {author?.name || author?.username || "Unknown Author"}
            </div>
            <div className="text-xs text-gray-500">Posted {timeAgo}</div>
          </div>
        </div>
        <h3 className="text-lg font-semibold text-gray-800 mb-2 line-clamp-1">
          {blog.title}
        </h3>
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {blog.content ? blog.content.replace(/<[^>]*>?/gm, '') : "No content available"}
        </p>
        <div className="flex justify-between items-center">
          <div className="flex items-center text-sm text-gray-500">
            <span className="flex items-center mr-3">
              <Heart className="h-4 w-4 mr-1" />
              {blog.likes || 0}
            </span>
            <span className="flex items-center">
              <MessageSquare className="h-4 w-4 mr-1" />
              {blog.comments || 0}
            </span>
          </div>
          <Link
            href={`/blogs/${blog.slug}`}
            className="text-primary hover:text-primary-dark text-sm font-medium"
          >
            Read More
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default BlogCard;
