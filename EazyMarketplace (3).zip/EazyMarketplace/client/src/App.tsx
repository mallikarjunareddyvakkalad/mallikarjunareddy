import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";
import SellerDashboard from "@/pages/SellerDashboard";
import ProductDetail from "@/pages/ProductDetail";
import ChatPage from "@/pages/ChatPage";
import ProfilePage from "@/pages/ProfilePage";
import Marketplace from "@/pages/Marketplace"; 
import Community from "@/pages/Community";
import JobsAndGigs from "@/pages/JobsAndGigs";
import Affiliate from "@/pages/Affiliate";
import MainLayout from "@/components/layout/MainLayout";
import { AuthProvider } from "@/contexts/AuthContext";
import { ChatProvider } from "@/contexts/ChatContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      <Route path="/dashboard" component={SellerDashboard} />
      <Route path="/product/:id" component={ProductDetail} />
      <Route path="/chat" component={ChatPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/marketplace" component={Marketplace} />
      <Route path="/community" component={Community} />
      <Route path="/jobs" component={JobsAndGigs} />
      <Route path="/affiliate" component={Affiliate} />
      <Route path="/affiliates" component={Affiliate} />
      <Route path="/events" component={Community} />
      <Route path="/blogs" component={Community} />
      <Route path="/groups" component={Community} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ChatProvider>
          <MainLayout>
            <Router />
          </MainLayout>
          <Toaster />
        </ChatProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
