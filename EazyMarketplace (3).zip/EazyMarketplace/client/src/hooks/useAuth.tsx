import { useAuth as useAuthContext } from "@/contexts/AuthContext";

// This is a simple re-export of the auth context hook
// to make imports more consistent across the app
export const useAuth = useAuthContext;
