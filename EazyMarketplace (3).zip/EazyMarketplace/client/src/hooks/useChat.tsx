import { useChat as useChatContext } from "@/contexts/ChatContext";

// This is a simple re-export of the chat context hook
// to make imports more consistent across the app
export const useChat = useChatContext;
