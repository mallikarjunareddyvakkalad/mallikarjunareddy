import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Conversation, Message, InsertConversation, InsertMessage } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ChatContextType {
  conversations: Conversation[];
  messages: Message[];
  activeConversation: Conversation | null;
  isTyping: Record<number, boolean>;
  unreadCounts: Record<number, number>;
  isLoadingConversations: boolean;
  isLoadingMessages: boolean;
  sendMessage: (conversationId: number, content: string, type?: string) => Promise<void>;
  setActiveConversation: (conversation: Conversation) => void;
  markAsRead: (conversationId: number) => Promise<void>;
  createConversation: (data: Partial<InsertConversation>) => Promise<Conversation | undefined>;
  sendTypingStatus: (conversationId: number, isTyping: boolean) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

// Initialize WebSocket connection
const setupWebSocket = (userId: number, onMessage: (data: any) => void) => {
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const wsUrl = `${protocol}//${window.location.host}/ws`;
  
  const socket = new WebSocket(wsUrl);
  
  socket.onopen = () => {
    console.log("WebSocket connection established");
    // Authenticate the WebSocket connection
    socket.send(JSON.stringify({
      type: "auth",
      userId: userId
    }));
  };
  
  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      onMessage(data);
    } catch (error) {
      console.error("Error parsing WebSocket message:", error);
    }
  };
  
  socket.onclose = () => {
    console.log("WebSocket connection closed");
    // Attempt to reconnect after a delay
    setTimeout(() => setupWebSocket(userId, onMessage), 3000);
  };
  
  socket.onerror = (error) => {
    console.error("WebSocket error:", error);
  };
  
  return socket;
};

export function ChatProvider({ children }: { children: ReactNode }) {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState<Record<number, boolean>>({});
  const [unreadCounts, setUnreadCounts] = useState<Record<number, number>>({});
  
  // Fetch conversations
  const { 
    data: conversations = [], 
    isLoading: isLoadingConversations,
    refetch: refetchConversations
  } = useQuery<Conversation[]>({
    queryKey: ['/api/conversations'],
    enabled: isAuthenticated,
    refetchInterval: false,
  });
  
  // Fetch messages when active conversation changes
  const { 
    data: fetchedMessages = [], 
    isLoading: isLoadingMessages,
    refetch: refetchMessages
  } = useQuery<Message[]>({
    queryKey: ['/api/conversations', activeConversation?.id, 'messages'],
    enabled: !!activeConversation,
    onSuccess: (data) => {
      setMessages(data);
      if (activeConversation) {
        // Update unread counts by marking messages as read
        markAsRead(activeConversation.id);
      }
    }
  });
  
  // Initialize WebSocket connection
  useEffect(() => {
    if (isAuthenticated && user?.id) {
      const ws = setupWebSocket(user.id, handleWebSocketMessage);
      setSocket(ws);
      
      return () => {
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.close();
        }
      };
    }
  }, [isAuthenticated, user?.id]);
  
  // Handle incoming WebSocket messages
  const handleWebSocketMessage = (data: any) => {
    console.log("WebSocket message received:", data);
    
    switch (data.type) {
      case "auth_response":
        if (data.success) {
          console.log("WebSocket authenticated successfully");
        } else {
          console.error("WebSocket authentication failed");
        }
        break;
        
      case "new_message":
        // Handle new message
        if (data.message) {
          // If message is for active conversation, add it to messages
          if (activeConversation && data.message.conversationId === activeConversation.id) {
            setMessages(prev => [...prev, data.message]);
            // Mark as read immediately
            markAsRead(data.message.conversationId);
          } else {
            // Update unread count for conversation
            setUnreadCounts(prev => ({
              ...prev,
              [data.message.conversationId]: (prev[data.message.conversationId] || 0) + 1
            }));
            
            // Show notification
            toast({
              title: "New message",
              description: data.message.content.substring(0, 50) + (data.message.content.length > 50 ? "..." : ""),
            });
          }
          // Refetch conversations to update last message and timestamp
          refetchConversations();
        }
        break;
        
      case "typing_status":
        // Handle typing status updates
        if (data.conversationId && data.userId !== user?.id) {
          setIsTyping(prev => ({
            ...prev,
            [data.conversationId]: data.isTyping
          }));
          
          // Auto-clear typing indicator after 3 seconds
          if (data.isTyping) {
            setTimeout(() => {
              setIsTyping(prev => ({
                ...prev,
                [data.conversationId]: false
              }));
            }, 3000);
          }
        }
        break;
        
      case "messages_read":
        // Handle message read status updates
        if (data.conversationId) {
          // Reset unread count for this conversation
          setUnreadCounts(prev => ({
            ...prev,
            [data.conversationId]: 0
          }));
        }
        break;
        
      case "unread_messages":
        // Handle unread messages notification
        if (data.conversationId && data.count) {
          setUnreadCounts(prev => ({
            ...prev,
            [data.conversationId]: data.count
          }));
        }
        break;
        
      case "error":
        console.error("WebSocket error:", data.message);
        toast({
          title: "Chat Error",
          description: data.message,
          variant: "destructive",
        });
        break;
    }
  };
  
  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { conversationId: number; content: string; type?: string }) => {
      const res = await apiRequest('POST', `/api/conversations/${data.conversationId}/messages`, {
        conversationId: data.conversationId,
        content: data.content,
        type: data.type || 'text'
      });
      return res.json();
    },
    onSuccess: (newMessage) => {
      setMessages(prev => [...prev, newMessage]);
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to send message",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    }
  });
  
  // Create conversation mutation
  const createConversationMutation = useMutation({
    mutationFn: async (data: Partial<InsertConversation>) => {
      const res = await apiRequest('POST', '/api/conversations', data);
      return res.json();
    },
    onSuccess: (newConversation) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
      setActiveConversation(newConversation);
      toast({
        title: "Conversation created",
        description: "New conversation started successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create conversation",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    }
  });
  
  // Mark messages as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (conversationId: number) => {
      const res = await apiRequest('PATCH', `/api/conversations/${conversationId}/read`, {});
      return res.json();
    },
    onSuccess: (_data, conversationId) => {
      // Update unread count locally
      setUnreadCounts(prev => ({
        ...prev,
        [conversationId]: 0
      }));
      
      // Send WebSocket notification that messages were read
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({
          type: 'read_messages',
          conversationId
        }));
      }
    }
  });
  
  // Send typing status via WebSocket
  const sendTypingStatus = (conversationId: number, isTyping: boolean) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'typing',
        conversationId,
        isTyping
      }));
    }
  };
  
  // Public API functions
  const sendMessage = async (conversationId: number, content: string, type = 'text') => {
    if (!content.trim() && type === 'text') return;
    
    try {
      await sendMessageMutation.mutateAsync({
        conversationId,
        content,
        type
      });
      
      // Send message via WebSocket as well
      if (socket && socket.readyState === WebSocket.OPEN && user?.id) {
        socket.send(JSON.stringify({
          type: 'chat_message',
          conversationId,
          content,
          messageType: type
        }));
      }
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };
  
  const createConversation = async (data: Partial<InsertConversation>) => {
    try {
      const newConversation = await createConversationMutation.mutateAsync(data);
      return newConversation;
    } catch (error) {
      console.error("Error creating conversation:", error);
      return undefined;
    }
  };
  
  const markAsRead = async (conversationId: number) => {
    try {
      await markAsReadMutation.mutateAsync(conversationId);
    } catch (error) {
      console.error("Error marking messages as read:", error);
    }
  };
  
  // Set active conversation handler
  const handleSetActiveConversation = (conversation: Conversation) => {
    setActiveConversation(conversation);
    // When setting active conversation, mark messages as read
    if (conversation) {
      markAsRead(conversation.id);
    }
  };
  
  const value = {
    conversations,
    messages,
    activeConversation,
    isTyping,
    unreadCounts,
    isLoadingConversations,
    isLoadingMessages,
    sendMessage,
    setActiveConversation: handleSetActiveConversation,
    markAsRead,
    createConversation,
    sendTypingStatus,
  };
  
  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
}

export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};
