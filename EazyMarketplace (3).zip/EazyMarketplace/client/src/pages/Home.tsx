import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import HeroBanner from "@/components/HeroBanner";
import FeatureGrid from "@/components/FeatureGrid";
import ProductGrid from "@/components/ProductGrid";
import CommunitySection from "@/components/CommunitySection";
import EarningSection from "@/components/EarningSection";
import AIFeaturesSection from "@/components/AIFeaturesSection";
import GamificationSection from "@/components/GamificationSection";
import CTASection from "@/components/CTASection";
import { Skeleton } from "@/components/ui/skeleton";

const Home = () => {
  // Prefetch products for the trending section
  useEffect(() => {
    // Prefetch top products
    const prefetchProducts = async () => {
      try {
        await fetch('/api/products?limit=4');
      } catch (error) {
        console.error('Error prefetching products:', error);
      }
    };
    
    prefetchProducts();
  }, []);

  // Fetch popular groups
  const { data: groups, isLoading: isLoadingGroups } = useQuery({
    queryKey: ['/api/groups', { limit: 3 }],
  });

  // Fetch recent jobs
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ['/api/jobs', { limit: 3 }],
  });

  // Fetch upcoming events
  const { data: events, isLoading: isLoadingEvents } = useQuery({
    queryKey: ['/api/events', { limit: 2 }],
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Banner */}
      <HeroBanner />

      {/* Platform Features */}
      <FeatureGrid />

      {/* Trending Products Section */}
      <ProductGrid title="Trending Products" limit={4} />

      {/* Community & User-Generated Content Section */}
      <CommunitySection 
        groups={groups || []} 
        isLoadingGroups={isLoadingGroups} 
        jobs={jobs || []} 
        isLoadingJobs={isLoadingJobs}
        events={events || []}
        isLoadingEvents={isLoadingEvents}
      />

      {/* Affiliate & Earning Section */}
      <EarningSection />

      {/* AI Features Highlight Section */}
      <AIFeaturesSection />

      {/* Gamification Features */}
      <GamificationSection />

      {/* CTA Section */}
      <CTASection />
    </div>
  );
};

export default Home;
