import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Job } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter, ArrowDownUp, BriefcaseBusiness, Globe, PanelRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const JobsAndGigs = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [remoteOnly, setRemoteOnly] = useState(false);

  // Fetch jobs
  const { data: jobs, isLoading: jobsLoading } = useQuery<Job[]>({
    queryKey: ['/api/jobs'],
    retry: false,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search logic would go here in a full implementation
    console.log("Searching for:", searchTerm);
  };

  const jobCategories = [
    "Design",
    "Development",
    "Marketing",
    "Writing",
    "Customer Service",
    "Sales",
    "Administrative",
    "Other"
  ];

  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  const filteredJobs = jobs?.filter(job => {
    // Filter by category if any are selected
    if (selectedCategories.length > 0 && job.category) {
      if (!selectedCategories.includes(job.category)) {
        return false;
      }
    }

    // Filter by remote only
    if (remoteOnly && !job.remote) {
      return false;
    }

    // Filter by search term
    if (searchTerm && !job.title.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !job.description.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }

    return true;
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Jobs & Gigs</h1>
        <p className="text-gray-600">
          Find freelance work, full-time positions, and short-term gigs.
        </p>
      </div>

      {/* Search and Filters */}
      <div className="mb-8">
        <form onSubmit={handleSearch} className="flex gap-2 mb-4">
          <div className="relative flex-grow">
            <Input
              type="text"
              placeholder="Search for jobs and gigs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <Button type="submit">Search</Button>
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            aria-expanded={showFilters}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            {showFilters ? "Hide Filters" : "Show Filters"}
          </Button>
        </form>

        {showFilters && (
          <div className="p-4 border rounded-md mb-6 bg-gray-50">
            <h3 className="text-lg font-medium mb-4">Filters</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-2">Categories</h4>
                <div className="grid grid-cols-2 gap-2">
                  {jobCategories.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={`category-${category}`}
                        checked={selectedCategories.includes(category)}
                        onCheckedChange={() => toggleCategory(category)}
                      />
                      <label
                        htmlFor={`category-${category}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Job Type</h4>
                <div className="flex items-center space-x-2 mb-4">
                  <Checkbox
                    id="remote-only"
                    checked={remoteOnly}
                    onCheckedChange={(checked) => setRemoteOnly(checked as boolean)}
                  />
                  <label
                    htmlFor="remote-only"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Remote only
                  </label>
                </div>
                
                <div className="mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedCategories([]);
                      setRemoteOnly(false);
                      setSearchTerm("");
                    }}
                  >
                    Reset Filters
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Job Listings */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">Available Opportunities</h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <ArrowDownUp className="h-4 w-4 mr-2" />
              Sort by Date
            </Button>
            <Button variant="default" size="sm">
              Post a Job
            </Button>
          </div>
        </div>

        {jobsLoading ? (
          <div className="grid grid-cols-1 gap-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="border rounded-lg p-6 animate-pulse">
                <div className="flex justify-between mb-4">
                  <div className="h-7 bg-gray-200 rounded w-1/3"></div>
                  <div className="h-6 bg-gray-200 rounded w-1/6"></div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-2/3 mb-3"></div>
                <div className="h-4 bg-gray-200 rounded w-full mb-3"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
                <div className="flex gap-2">
                  <div className="h-6 bg-gray-200 rounded w-16"></div>
                  <div className="h-6 bg-gray-200 rounded w-20"></div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredJobs && filteredJobs.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {filteredJobs.map((job) => (
              <Card key={job.id} className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{job.title}</CardTitle>
                      <CardDescription className="flex items-center mt-1 text-sm">
                        <BriefcaseBusiness className="h-4 w-4 mr-1" />
                        {job.postedBy}
                        {job.location && (
                          <>
                            <span className="mx-2">•</span>
                            <span>{job.location}</span>
                          </>
                        )}
                        {job.remote && (
                          <>
                            <span className="mx-2">•</span>
                            <div className="flex items-center">
                              <Globe className="h-3 w-3 mr-1" />
                              <span>Remote</span>
                            </div>
                          </>
                        )}
                      </CardDescription>
                    </div>
                    <Badge variant={job.status === 'active' ? 'default' : 'outline'}>
                      {job.budget ? `$${job.budget}` : 'Open Budget'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4 line-clamp-2">
                    {job.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {job.category && (
                      <Badge variant="outline" className="bg-gray-100">
                        {job.category}
                      </Badge>
                    )}
                    {job.skills && job.skills.split(',').map((skill, index) => (
                      <Badge key={index} variant="outline" className="bg-gray-100">
                        {skill.trim()}
                      </Badge>
                    ))}
                  </div>
                  <div className="mt-4 flex justify-between items-center">
                    <Button size="sm">Apply Now</Button>
                    <span className="text-xs text-gray-500">
                      Posted {new Date(job.createdAt || new Date()).toLocaleDateString()}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="py-12 text-center bg-gray-50 rounded-lg">
            <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gray-200 rounded-full mb-4">
              <PanelRight className="h-8 w-8 text-gray-500" />
            </div>
            <h3 className="text-lg font-medium">No jobs found</h3>
            <p className="text-gray-500 mt-2 mb-6">Try adjusting your search or filters</p>
            <Button 
              onClick={() => {
                setSelectedCategories([]);
                setRemoteOnly(false);
                setSearchTerm("");
              }}
            >
              Clear All Filters
            </Button>
          </div>
        )}
      </div>

      {/* Tips Section */}
      <div className="mt-12 bg-gray-50 p-6 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Tips for Job Seekers</h2>
        <ul className="list-disc pl-5 space-y-2">
          <li>Complete your profile to increase your chances of getting hired.</li>
          <li>Be specific about your skills and experience in your applications.</li>
          <li>Respond promptly to employer messages and inquiries.</li>
          <li>Build a portfolio to showcase your previous work.</li>
          <li>Set job alerts to stay updated on new opportunities.</li>
        </ul>
      </div>
    </div>
  );
};

export default JobsAndGigs;