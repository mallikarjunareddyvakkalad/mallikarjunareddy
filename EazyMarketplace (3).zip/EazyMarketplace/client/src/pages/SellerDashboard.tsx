import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Product, InsertProduct } from "@shared/schema";
import SellerSidebar from "@/components/seller/SellerSidebar";
import StatsCard from "@/components/seller/StatsCard";
import ProductListItem from "@/components/seller/ProductListItem";
import OrderListItem from "@/components/seller/OrderListItem";
import MessageListItem from "@/components/seller/MessageListItem";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ShoppingBag, Package, Eye, ArrowUp, Banknote, Coins } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";

// Form schema for adding a product
const productFormSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  price: z.coerce.number().positive("Price must be positive"),
  image: z.string().url("Must be a valid URL").optional(),
  categoryId: z.coerce.number().positive("Category is required"),
  location: z.string().min(2, "Location is required"),
});

type ProductFormValues = z.infer<typeof productFormSchema>;

const SellerDashboard = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isProductDialogOpen, setIsProductDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [dashboardView, setDashboardView] = useState("overview");

  // Form setup
  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      title: "",
      description: "",
      price: 0,
      image: "",
      categoryId: 0,
      location: "",
    },
  });

  // Fetch products owned by the seller
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products/user"],
    queryFn: async () => {
      const res = await fetch(`/api/products?sellerId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch products");
      return res.json();
    },
    enabled: !!user,
  });

  // Fetch orders
  const { data: orders, isLoading: ordersLoading } = useQuery({
    queryKey: ["/api/orders/seller"],
    queryFn: async () => {
      const res = await fetch(`/api/orders?sellerId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch orders");
      return res.json();
    },
    enabled: !!user,
  });

  // Fetch categories for product form
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
    queryFn: async () => {
      const res = await fetch("/api/categories");
      if (!res.ok) throw new Error("Failed to fetch categories");
      return res.json();
    },
  });

  // Add product mutation
  const addProductMutation = useMutation({
    mutationFn: async (data: ProductFormValues) => {
      const res = await apiRequest("POST", "/api/products", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products/user"] });
      toast({
        title: "Product Added",
        description: "Your product has been added successfully",
      });
      setIsProductDialogOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to add product",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });

  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: async (data: { id: number; product: Partial<Product> }) => {
      const res = await apiRequest("PATCH", `/api/products/${data.id}`, data.product);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products/user"] });
      toast({
        title: "Product Updated",
        description: "Your product has been updated successfully",
      });
      setIsProductDialogOpen(false);
      setSelectedProduct(null);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to update product",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });

  // Delete product mutation
  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/products/${id}`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products/user"] });
      toast({
        title: "Product Deleted",
        description: "Your product has been deleted successfully",
      });
      setIsDeleteDialogOpen(false);
      setSelectedProduct(null);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to delete product",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: ProductFormValues) => {
    if (selectedProduct) {
      updateProductMutation.mutate({
        id: selectedProduct.id,
        product: data,
      });
    } else {
      addProductMutation.mutate(data);
    }
  };

  // Handle edit product
  const handleEditProduct = (product: Product) => {
    setSelectedProduct(product);
    form.reset({
      title: product.title,
      description: product.description || "",
      price: product.price,
      image: product.image || "",
      categoryId: product.categoryId || 1,
      location: product.location || "",
    });
    setIsProductDialogOpen(true);
  };

  // Handle delete product
  const handleDeleteProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsDeleteDialogOpen(true);
  };

  // Handle confirm delete
  const confirmDelete = () => {
    if (selectedProduct) {
      deleteProductMutation.mutate(selectedProduct.id);
    }
  };

  // Open dialog for adding product
  const openAddProductDialog = () => {
    setSelectedProduct(null);
    form.reset({
      title: "",
      description: "",
      price: 0,
      image: "",
      categoryId: categories?.[0]?.id || 0,
      location: "",
    });
    setIsProductDialogOpen(true);
  };

  // Determine which dashboard view to show
  const renderDashboardView = () => {
    switch (dashboardView) {
      case "overview":
        return renderOverview();
      case "products":
        return renderProducts();
      case "orders":
        return renderOrders();
      case "messages":
        return renderMessages();
      case "analytics":
        return renderAnalytics();
      case "earnings":
        return renderEarnings();
      default:
        return renderOverview();
    }
  };

  // Render overview dashboard
  const renderOverview = () => (
    <>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Seller Dashboard</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="Total Sales"
          value="₹24,568"
          icon={<ShoppingBag className="text-primary h-5 w-5" />}
          iconBgColor="bg-primary/10 text-primary"
          change={{ value: "12.5%", positive: true }}
        />
        
        <StatsCard
          title="Products"
          value={products?.length || 0}
          icon={<Package className="text-secondary h-5 w-5" />}
          iconBgColor="bg-secondary/10 text-secondary"
          change={{ value: "2", positive: true }}
          changeText="new this month"
        />
        
        <StatsCard
          title="Views"
          value={products?.reduce((acc, p) => acc + (p.views || 0), 0) || 0}
          icon={<Eye className="text-accent h-5 w-5" />}
          iconBgColor="bg-accent/10 text-accent"
          change={{ value: "18.2%", positive: true }}
        />
        
        <StatsCard
          title="Points Earned"
          value={user?.points || 0}
          icon={<Coins className="text-yellow-600 h-5 w-5" />}
          iconBgColor="bg-yellow-100 text-yellow-600"
          change={{ value: `${100 - (user?.points || 0)} more`, positive: true }}
          changeText="to withdraw (₹100)"
        />
      </div>
      
      {/* Recent Products & Add New */}
      <div className="flex flex-col sm:flex-row gap-6 mb-6">
        <Card className="sm:w-2/3">
          <CardHeader className="flex justify-between items-center pb-2">
            <CardTitle className="text-lg font-semibold">Recent Products</CardTitle>
            <Button variant="link" size="sm" onClick={() => setDashboardView("products")}>
              View All
            </Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {productsLoading ? (
              <div className="p-4 text-center">Loading products...</div>
            ) : products?.length ? (
              products.slice(0, 3).map((product) => (
                <ProductListItem
                  key={product.id}
                  product={product}
                  onEdit={handleEditProduct}
                  onDelete={handleDeleteProduct}
                />
              ))
            ) : (
              <div className="p-4 text-center text-gray-500">
                No products found. Add your first product!
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card className="sm:w-1/3">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Add New Product</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 mb-4 flex flex-col items-center justify-center text-center">
              <i className="ri-image-add-line text-4xl text-gray-400 mb-2"></i>
              <p className="text-sm text-gray-500 mb-2">Drag & drop your product images here</p>
              <Button variant="link" size="sm" className="text-primary">
                Browse Files
              </Button>
            </div>
            
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product Name
                </label>
                <Input 
                  type="text" 
                  placeholder="Enter product name"
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price (₹)
                </label>
                <Input 
                  type="number" 
                  placeholder="Enter price"
                  className="w-full"
                />
              </div>
              <Button 
                className="w-full"
                onClick={openAddProductDialog}
              >
                Add Product
              </Button>
            </div>
            
            <div className="mt-4">
              <Button 
                variant="outline" 
                className="w-full flex items-center justify-center"
              >
                <i className="ri-magic-line mr-1"></i> Generate with AI
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Sales Analytics Chart */}
      <Card className="mb-6">
        <CardHeader className="flex justify-between items-center pb-2">
          <CardTitle className="text-lg font-semibold">Sales Analytics</CardTitle>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">Last 7 Days</Button>
            <Button size="sm">Last 30 Days</Button>
            <Button variant="outline" size="sm">This Year</Button>
          </div>
        </CardHeader>
        <CardContent className="h-64 pt-4">
          {/* Simplified placeholder chart */}
          <div className="w-full h-full rounded-lg overflow-hidden">
            <div className="h-full flex items-end pb-4 pt-6 px-4 relative">
              {/* Y-axis labels */}
              <div className="absolute left-0 top-0 bottom-0 flex flex-col justify-between py-5 text-xs text-gray-500">
                <span>₹5k</span>
                <span>₹4k</span>
                <span>₹3k</span>
                <span>₹2k</span>
                <span>₹1k</span>
                <span>₹0</span>
              </div>
              
              {/* Grid lines */}
              <div className="absolute left-8 right-0 top-0 bottom-0 flex flex-col justify-between py-5">
                <div className="border-b border-gray-100 w-full"></div>
                <div className="border-b border-gray-100 w-full"></div>
                <div className="border-b border-gray-100 w-full"></div>
                <div className="border-b border-gray-100 w-full"></div>
                <div className="border-b border-gray-100 w-full"></div>
                <div className="border-b border-gray-100 w-full"></div>
              </div>
              
              {/* Bars */}
              <div className="flex items-end justify-around w-full h-full pl-8 z-10 space-x-8">
                {[32, 40, 36, 52, 48].map((height, index) => (
                  <div key={index} className="group relative flex flex-col items-center">
                    <div className="absolute bottom-full mb-2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                      ₹{height * 100 - 500}
                    </div>
                    <div className={`w-8 bg-primary rounded-t-lg h-${height}`} style={{ height: `${height}%` }}></div>
                    <span className="text-xs text-gray-500 mt-1">
                      {new Date(Date.now() - (6 - index) * 86400000).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Latest Orders & Customer Messages */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex justify-between items-center pb-2">
            <CardTitle className="text-lg font-semibold">Latest Orders</CardTitle>
            <Button variant="link" size="sm" onClick={() => setDashboardView("orders")}>
              View All
            </Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {ordersLoading ? (
              <div className="p-4 text-center">Loading orders...</div>
            ) : orders?.length ? (
              orders.slice(0, 3).map((order) => (
                <OrderListItem
                  key={order.id}
                  order={order}
                  buyerName="Customer" // This would come from a user lookup in a real app
                  productTitle={`Product #${order.productId || order.serviceId}`} // This would also be a lookup
                />
              ))
            ) : (
              <div className="p-4 text-center text-gray-500">
                No orders yet. They will appear here when you receive them.
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex justify-between items-center pb-2">
            <CardTitle className="text-lg font-semibold">Customer Messages</CardTitle>
            <Button variant="link" size="sm" onClick={() => setDashboardView("messages")}>
              View All
            </Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {/* Sample messages */}
            <MessageListItem
              message={{ id: 1, conversationId: 1, senderId: 2, content: "Hi, is the laptop still available? Can you deliver it to Bangalore?", type: "text", read: false, createdAt: new Date() }}
              senderName="Sneha R."
              timestamp={new Date()}
              unread={true}
            />
            <MessageListItem
              message={{ id: 2, conversationId: 2, senderId: 3, content: "Can you offer any discount on bulk order of 3 units?", type: "text", read: true, createdAt: new Date(Date.now() - 86400000) }}
              senderName="Karthik B."
              timestamp={new Date(Date.now() - 86400000)}
            />
            <MessageListItem
              message={{ id: 3, conversationId: 3, senderId: 4, content: "Hello, do you have these headphones in white color?", type: "text", read: true, createdAt: new Date(Date.now() - 172800000) }}
              senderName="Divya T."
              timestamp={new Date(Date.now() - 172800000)}
            />
          </CardContent>
        </Card>
      </div>
    </>
  );

  // Render products view
  const renderProducts = () => (
    <>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">My Products</h1>
        <Button onClick={openAddProductDialog}>Add New Product</Button>
      </div>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <Input
              placeholder="Search products..."
              className="max-w-xs"
            />
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <i className="ri-filter-3-line mr-1"></i> Filter
              </Button>
              <Button variant="outline" size="sm">
                <i className="ri-sort-desc mr-1"></i> Sort
              </Button>
            </div>
          </div>
          
          <div className="border rounded-lg overflow-hidden">
            <div className="grid grid-cols-12 bg-gray-50 p-3 text-sm font-medium text-gray-700">
              <div className="col-span-5">Product</div>
              <div className="col-span-2">Price</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-1">Views</div>
              <div className="col-span-2 text-right">Actions</div>
            </div>
            
            <div className="divide-y">
              {productsLoading ? (
                <div className="p-4 text-center">Loading products...</div>
              ) : products?.length ? (
                products.map((product) => (
                  <div key={product.id} className="grid grid-cols-12 p-3 items-center">
                    <div className="col-span-5 flex items-center">
                      <div className="h-10 w-10 bg-gray-100 rounded-md overflow-hidden mr-3">
                        <img
                          src={product.image || `https://via.placeholder.com/100?text=${encodeURIComponent(
                            product.title.charAt(0)
                          )}`}
                          alt={product.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="font-medium">{product.title}</div>
                        <div className="text-xs text-gray-500">{product.location || "No location"}</div>
                      </div>
                    </div>
                    <div className="col-span-2 font-medium">₹{product.price.toLocaleString("en-IN")}</div>
                    <div className="col-span-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        product.status === 'active' ? 'bg-green-100 text-green-800' : 
                        product.status === 'inactive' ? 'bg-gray-100 text-gray-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {product.status?.toUpperCase()}
                      </span>
                    </div>
                    <div className="col-span-1">{product.views}</div>
                    <div className="col-span-2 flex justify-end space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleEditProduct(product)}
                      >
                        Edit
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-red-500 border-red-200 hover:bg-red-50"
                        onClick={() => handleDeleteProduct(product)}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">
                  No products found. Add your first product!
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );

  // Render orders view
  const renderOrders = () => (
    <>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Orders</h1>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <Input
              placeholder="Search orders..."
              className="max-w-xs"
            />
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <i className="ri-filter-3-line mr-1"></i> Filter
              </Button>
              <Button variant="outline" size="sm">
                <i className="ri-sort-desc mr-1"></i> Sort
              </Button>
            </div>
          </div>
          
          <div className="border rounded-lg overflow-hidden">
            <div className="grid grid-cols-12 bg-gray-50 p-3 text-sm font-medium text-gray-700">
              <div className="col-span-1">ID</div>
              <div className="col-span-3">Customer</div>
              <div className="col-span-3">Product</div>
              <div className="col-span-2">Amount</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-1 text-right">Actions</div>
            </div>
            
            <div className="divide-y">
              {ordersLoading ? (
                <div className="p-4 text-center">Loading orders...</div>
              ) : orders?.length ? (
                orders.map((order) => (
                  <div key={order.id} className="grid grid-cols-12 p-3 items-center">
                    <div className="col-span-1">#{order.id}</div>
                    <div className="col-span-3">Customer #{order.buyerId}</div>
                    <div className="col-span-3">
                      {order.productId ? `Product #${order.productId}` : `Service #${order.serviceId}`}
                    </div>
                    <div className="col-span-2 font-medium">₹{order.amount.toLocaleString("en-IN")}</div>
                    <div className="col-span-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        order.status === 'paid' ? 'bg-green-100 text-green-800' : 
                        order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                        order.status === 'shipped' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {order.status?.toUpperCase()}
                      </span>
                    </div>
                    <div className="col-span-1 flex justify-end">
                      <Button variant="outline" size="sm">View</Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">
                  No orders yet. They will appear here when you receive them.
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );

  // Render messages view
  const renderMessages = () => (
    <>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Messages</h1>
      
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <Input
              placeholder="Search messages..."
              className="max-w-xs"
            />
            <Button>New Message</Button>
          </div>
          
          <div className="border rounded-lg">
            <div className="grid grid-cols-12 bg-gray-50 p-3 text-sm font-medium text-gray-700">
              <div className="col-span-3">Sender</div>
              <div className="col-span-6">Last Message</div>
              <div className="col-span-2">Date</div>
              <div className="col-span-1 text-right">Actions</div>
            </div>
            
            <div className="divide-y">
              {/* Sample messages */}
              <div className="grid grid-cols-12 p-3 items-center">
                <div className="col-span-3 flex items-center">
                  <div className="h-8 w-8 bg-gray-100 rounded-full overflow-hidden mr-2">
                    <img src="https://i.pravatar.cc/100?img=1" alt="Sneha R." className="h-full w-full object-cover" />
                  </div>
                  <div>
                    <div className="font-medium">Sneha R.</div>
                  </div>
                </div>
                <div className="col-span-6 text-gray-600 truncate">
                  Hi, is the laptop still available? Can you deliver it to Bangalore?
                </div>
                <div className="col-span-2 text-sm text-gray-500">Today, 10:23 AM</div>
                <div className="col-span-1 flex justify-end">
                  <Button variant="outline" size="sm">Reply</Button>
                </div>
              </div>
              
              <div className="grid grid-cols-12 p-3 items-center">
                <div className="col-span-3 flex items-center">
                  <div className="h-8 w-8 bg-gray-100 rounded-full overflow-hidden mr-2">
                    <img src="https://i.pravatar.cc/100?img=2" alt="Karthik B." className="h-full w-full object-cover" />
                  </div>
                  <div>
                    <div className="font-medium">Karthik B.</div>
                  </div>
                </div>
                <div className="col-span-6 text-gray-600 truncate">
                  Can you offer any discount on bulk order of 3 units?
                </div>
                <div className="col-span-2 text-sm text-gray-500">Yesterday</div>
                <div className="col-span-1 flex justify-end">
                  <Button variant="outline" size="sm">Reply</Button>
                </div>
              </div>
              
              <div className="grid grid-cols-12 p-3 items-center">
                <div className="col-span-3 flex items-center">
                  <div className="h-8 w-8 bg-gray-100 rounded-full overflow-hidden mr-2">
                    <img src="https://i.pravatar.cc/100?img=3" alt="Divya T." className="h-full w-full object-cover" />
                  </div>
                  <div>
                    <div className="font-medium">Divya T.</div>
                  </div>
                </div>
                <div className="col-span-6 text-gray-600 truncate">
                  Hello, do you have these headphones in white color?
                </div>
                <div className="col-span-2 text-sm text-gray-500">2 days ago</div>
                <div className="col-span-1 flex justify-end">
                  <Button variant="outline" size="sm">Reply</Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );

  // Render analytics view
  const renderAnalytics = () => (
    <>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Analytics</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Product Performance</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <div className="flex h-full items-center justify-center">
              <p className="text-gray-500">Analytics dashboard is under development.</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Customer Demographics</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <div className="flex h-full items-center justify-center">
              <p className="text-gray-500">Analytics dashboard is under development.</p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Traffic Sources</CardTitle>
        </CardHeader>
        <CardContent className="h-80">
          <div className="flex h-full items-center justify-center">
            <p className="text-gray-500">Analytics dashboard is under development.</p>
          </div>
        </CardContent>
      </Card>
    </>
  );

  // Render earnings view
  const renderEarnings = () => (
    <>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Earnings & Points</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Earnings Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">Total Earnings</p>
                <p className="text-2xl font-bold text-gray-800">₹24,568</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">This Month</p>
                <p className="text-2xl font-bold text-gray-800">₹3,245</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">Pending Payouts</p>
                <p className="text-2xl font-bold text-gray-800">₹1,200</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">Completed Orders</p>
                <p className="text-2xl font-bold text-gray-800">32</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Points Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">Current Points Balance</p>
                <p className="text-2xl font-bold text-gray-800">{user?.points || 0} points</p>
                <div className="mt-2 text-sm text-gray-500">
                  <p>{100 - (user?.points || 0)} more points needed to withdraw ₹100</p>
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                    <div 
                      className="bg-primary h-2.5 rounded-full" 
                      style={{ width: `${(user?.points || 0)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <div className="flex-1 bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Referral Points</p>
                  <p className="text-xl font-bold text-gray-800">12</p>
                </div>
                <div className="flex-1 bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Sales Points</p>
                  <p className="text-xl font-bold text-gray-800">24</p>
                </div>
                <div className="flex-1 bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">Activity Points</p>
                  <p className="text-xl font-bold text-gray-800">12</p>
                </div>
              </div>
              
              <Button disabled={(user?.points || 0) < 100}>
                Withdraw Points (Min. 100)
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader className="flex justify-between items-center">
          <CardTitle>Points Transaction History</CardTitle>
          <Button variant="outline" size="sm">Download Report</Button>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-hidden">
            <div className="grid grid-cols-12 bg-gray-50 p-3 text-sm font-medium text-gray-700">
              <div className="col-span-1">ID</div>
              <div className="col-span-2">Date</div>
              <div className="col-span-3">Description</div>
              <div className="col-span-2">Type</div>
              <div className="col-span-2">Reference</div>
              <div className="col-span-2 text-right">Points</div>
            </div>
            
            <div className="divide-y">
              {/* Sample transactions */}
              <div className="grid grid-cols-12 p-3 items-center">
                <div className="col-span-1">#12345</div>
                <div className="col-span-2">15 Jul 2023</div>
                <div className="col-span-3">Signup bonus</div>
                <div className="col-span-2">
                  <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">SIGNUP</span>
                </div>
                <div className="col-span-2">-</div>
                <div className="col-span-2 text-right text-green-600 font-medium">+2</div>
              </div>
              
              <div className="grid grid-cols-12 p-3 items-center">
                <div className="col-span-1">#12346</div>
                <div className="col-span-2">16 Jul 2023</div>
                <div className="col-span-3">Product sale</div>
                <div className="col-span-2">
                  <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">SALE</span>
                </div>
                <div className="col-span-2">Order #1001</div>
                <div className="col-span-2 text-right text-green-600 font-medium">+10</div>
              </div>
              
              <div className="grid grid-cols-12 p-3 items-center">
                <div className="col-span-1">#12347</div>
                <div className="col-span-2">20 Jul 2023</div>
                <div className="col-span-3">Referral bonus</div>
                <div className="col-span-2">
                  <span className="px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800">REFERRAL</span>
                </div>
                <div className="col-span-2">User #42</div>
                <div className="col-span-2 text-right text-green-600 font-medium">+2</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <div className="lg:w-1/4">
          <SellerSidebar />
        </div>
        
        {/* Main Dashboard Content */}
        <div className="lg:w-3/4">
          {renderDashboardView()}
        </div>
      </div>
      
      {/* Add/Edit Product Dialog */}
      <Dialog open={isProductDialogOpen} onOpenChange={setIsProductDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {selectedProduct ? "Edit Product" : "Add New Product"}
            </DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter product title" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter product description" 
                        {...field}
                        rows={4}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price (₹)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="0.00"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <FormControl>
                        <select
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          {...field}
                        >
                          <option value="">Select Category</option>
                          {categories?.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                              {cat.name}
                            </option>
                          ))}
                        </select>
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="image"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URL</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter image URL" 
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter location (e.g. Mumbai, Delhi)" 
                        {...field}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsProductDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={addProductMutation.isPending || updateProductMutation.isPending}
                >
                  {selectedProduct ? "Update Product" : "Add Product"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Product Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the product "{selectedProduct?.title}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-500 text-white hover:bg-red-600"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default SellerDashboard;
