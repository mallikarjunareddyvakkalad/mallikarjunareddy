import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User, PointsTransaction } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CopyIcon, Share2, Trophy, TrendingUp, Users, Wallet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Affiliate = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch points transactions related to affiliate program
  const { data: transactions, isLoading: transactionsLoading } = useQuery<PointsTransaction[]>({
    queryKey: ['/api/points/transactions', user?.id],
    retry: false,
    enabled: !!user,
  });

  // Filter affiliate transactions
  const affiliateTransactions = transactions?.filter(
    (tx) => tx.type === "affiliate" || tx.type === "referral"
  );

  // Calculate statistics
  const totalEarnings = affiliateTransactions?.reduce(
    (sum, tx) => sum + tx.amount,
    0
  ) || 0;

  // Mock referral count - in a real implementation this would come from the backend
  const referralCount = 3;

  const copyReferralLink = () => {
    if (!user?.referralCode) return;

    const referralLink = `${window.location.origin}/register?ref=${user.referralCode}`;
    navigator.clipboard.writeText(referralLink);
    
    toast({
      title: "Referral link copied!",
      description: "Share it with your friends to earn points.",
    });
  };

  const shareReferralLink = () => {
    if (!user?.referralCode) return;

    const referralLink = `${window.location.origin}/register?ref=${user.referralCode}`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Join EazyBuySells',
        text: 'Sign up using my referral link and get bonus points!',
        url: referralLink,
      });
    } else {
      copyReferralLink();
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Affiliate Program</h1>
        <p className="text-gray-600">
          Earn points by referring friends and promoting products on the platform.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="referrals">Referrals</TabsTrigger>
          <TabsTrigger value="earnings">Earnings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Total Earnings</CardDescription>
                <CardTitle className="text-2xl flex items-center">
                  <Wallet className="mr-2 h-5 w-5 text-primary" />
                  {totalEarnings} points
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-500">
                  Convert points to rewards in the shop
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Referrals</CardDescription>
                <CardTitle className="text-2xl flex items-center">
                  <Users className="mr-2 h-5 w-5 text-primary" />
                  {referralCount} users
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-500">
                  Users who signed up with your code
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Rank</CardDescription>
                <CardTitle className="text-2xl flex items-center">
                  <Trophy className="mr-2 h-5 w-5 text-primary" />
                  {referralCount > 10 ? "Gold" : referralCount > 5 ? "Silver" : "Bronze"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-500">
                  Your current affiliate ranking tier
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription>Conversion Rate</CardDescription>
                <CardTitle className="text-2xl flex items-center">
                  <TrendingUp className="mr-2 h-5 w-5 text-primary" />
                  {referralCount > 0 ? "12.5%" : "0%"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-gray-500">
                  Percentage of referral link clicks that convert
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Referral Code Section */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Your Referral Link</CardTitle>
              <CardDescription>
                Share this link to earn points when someone signs up
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <div className="relative flex-grow">
                  <Input
                    readOnly
                    value={user?.referralCode ? `${window.location.origin}/register?ref=${user.referralCode}` : "Login to get your referral link"}
                    className="pr-10"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full"
                    onClick={copyReferralLink}
                    disabled={!user?.referralCode}
                  >
                    <CopyIcon className="h-4 w-4" />
                    <span className="sr-only">Copy</span>
                  </Button>
                </div>
                <Button
                  onClick={shareReferralLink}
                  disabled={!user?.referralCode}
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* How It Works */}
          <Card>
            <CardHeader>
              <CardTitle>How It Works</CardTitle>
              <CardDescription>
                Learn how to earn points through our affiliate program
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal list-inside space-y-4">
                <li className="pl-2">
                  <span className="font-medium">Share your referral link</span>
                  <p className="text-gray-500 ml-6 mt-1">
                    Copy your unique referral link and share it with friends, on social media, or on your website.
                  </p>
                </li>
                <li className="pl-2">
                  <span className="font-medium">Friends sign up</span>
                  <p className="text-gray-500 ml-6 mt-1">
                    When someone uses your link to register, they'll be connected to your account as a referral.
                  </p>
                </li>
                <li className="pl-2">
                  <span className="font-medium">Earn points</span>
                  <p className="text-gray-500 ml-6 mt-1">
                    Earn 50 points for each new user who signs up using your link, and 5% of points they earn on the platform.
                  </p>
                </li>
                <li className="pl-2">
                  <span className="font-medium">Redeem rewards</span>
                  <p className="text-gray-500 ml-6 mt-1">
                    Convert your earned points to discounts, premium features, or cash out once you reach the minimum threshold.
                  </p>
                </li>
              </ol>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="referrals" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Referrals</CardTitle>
              <CardDescription>
                Users who signed up using your referral link
              </CardDescription>
            </CardHeader>
            <CardContent>
              {user ? (
                referralCount > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Joined Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Points Earned</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {/* This would be populated with actual referral data */}
                      <TableRow>
                        <TableCell className="font-medium">Sample User</TableCell>
                        <TableCell>{new Date().toLocaleDateString()}</TableCell>
                        <TableCell>
                          <span className="bg-green-100 text-green-800 text-xs px-2.5 py-0.5 rounded">
                            Active
                          </span>
                        </TableCell>
                        <TableCell className="text-right">50</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12">
                    <Users className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-4 text-lg font-medium">No referrals yet</h3>
                    <p className="mt-2 text-gray-500">
                      Share your referral link to start earning points.
                    </p>
                    <Button className="mt-4" onClick={shareReferralLink}>
                      Share Your Link
                    </Button>
                  </div>
                )
              ) : (
                <div className="text-center py-12">
                  <h3 className="text-lg font-medium">Login to see your referrals</h3>
                  <p className="mt-2 text-gray-500">
                    You need to be logged in to access the referral program.
                  </p>
                  <Button className="mt-4" onClick={() => window.location.href = "/login"}>
                    Login Now
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="earnings" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Earnings History</CardTitle>
              <CardDescription>
                Track all points earned through the affiliate program
              </CardDescription>
            </CardHeader>
            <CardContent>
              {user ? (
                transactionsLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex justify-between py-2 animate-pulse">
                        <div className="w-1/2">
                          <div className="h-5 bg-gray-200 rounded w-3/4 mb-2"></div>
                          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                        </div>
                        <div className="w-1/4">
                          <div className="h-5 bg-gray-200 rounded w-full"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : affiliateTransactions && affiliateTransactions.length > 0 ? (
                  <div className="space-y-4">
                    {affiliateTransactions.map((tx) => (
                      <div key={tx.id} className="flex justify-between border-b pb-3">
                        <div>
                          <p className="font-medium">{tx.description}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(tx.createdAt || new Date()).toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className={`font-medium ${tx.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                            {tx.amount > 0 ? "+" : ""}{tx.amount} points
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Wallet className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-4 text-lg font-medium">No earnings yet</h3>
                    <p className="mt-2 text-gray-500">
                      Start referring users to earn points.
                    </p>
                    <Button className="mt-4" onClick={shareReferralLink}>
                      Share Your Link
                    </Button>
                  </div>
                )
              ) : (
                <div className="text-center py-12">
                  <h3 className="text-lg font-medium">Login to see your earnings</h3>
                  <p className="mt-2 text-gray-500">
                    You need to be logged in to access the affiliate program.
                  </p>
                  <Button className="mt-4" onClick={() => window.location.href = "/login"}>
                    Login Now
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Affiliate;