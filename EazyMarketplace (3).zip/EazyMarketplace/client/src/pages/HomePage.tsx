import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "wouter";
import ProductCard from "@/components/marketplace/ProductCard";
import CategoryCard from "@/components/marketplace/CategoryCard";
import BlogCard from "@/components/community/BlogCard";
import EventCard from "@/components/community/EventCard";
import GroupCard from "@/components/community/GroupCard";
import AffiliateSection from "@/components/shared/AffiliateSection";
import { Product, Category, Blog, Event, Group } from "@shared/schema";
import { Filter, SortDesc } from "lucide-react";

const HomePage = () => {
  const { isAuthenticated } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Fetch products
  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', selectedCategory],
    retry: false,
  });

  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
    retry: false,
  });

  // Fetch community content
  const { data: blogs } = useQuery<Blog[]>({
    queryKey: ['/api/blogs'],
    retry: false,
  });

  const { data: events } = useQuery<Event[]>({
    queryKey: ['/api/events'],
    retry: false,
  });

  const { data: groups } = useQuery<Group[]>({
    queryKey: ['/api/groups'],
    retry: false,
  });

  const handleCategorySelect = (categoryId: string | null) => {
    setSelectedCategory(categoryId);
  };

  return (
    <>
      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-primary-light to-primary relative overflow-hidden">
        <div className="container mx-auto px-4 py-8 md:py-16 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-white text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Buy, Sell, Connect & Earn
            </h1>
            <p className="text-white text-lg mb-6 opacity-90">
              India's innovative marketplace with community features, AI-powered tools, and a
              rewarding point system.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button 
                asChild
                className="bg-white text-primary font-semibold px-6 py-3 hover:bg-gray-100 transition duration-200"
              >
                <Link href="/dashboard">Sell a Product</Link>
              </Button>
              <Button
                asChild
                className="bg-primary-dark text-white font-semibold px-6 py-3 hover:bg-primary-dark/90 transition duration-200"
              >
                <Link href="/products">Browse Products</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="bg-white/20 backdrop-blur-sm text-white border-white/30 font-semibold px-6 py-3 hover:bg-white/30 transition duration-200"
              >
                <Link href="/community">Join Community</Link>
              </Button>
            </div>
            <div className="mt-6 text-white/80 text-sm">
              Get ₹2 in points when you sign up or refer a friend!
            </div>
          </div>
        </div>
        {/* Abstract Shape Backgrounds */}
        <div className="absolute top-1/2 right-0 transform -translate-y-1/2 opacity-10">
          <div className="w-96 h-96 rounded-full bg-white"></div>
        </div>
        <div className="absolute bottom-0 left-1/4 transform translate-y-1/2 opacity-10">
          <div className="w-64 h-64 rounded-full bg-white"></div>
        </div>
      </section>

      {/* Category & Filters */}
      <section className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center space-x-3 overflow-x-auto scrollbar-hide py-1">
              <button
                className={`whitespace-nowrap px-4 py-2 text-sm rounded-full ${
                  !selectedCategory
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => handleCategorySelect(null)}
              >
                All Categories
              </button>
              {categoriesLoading
                ? Array(5)
                    .fill(0)
                    .map((_, i) => (
                      <div
                        key={i}
                        className="whitespace-nowrap px-4 py-2 bg-gray-100 text-gray-700 text-sm rounded-full animate-pulse"
                      >
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                    ))
                : categories?.map((category) => (
                    <button
                      key={category.id}
                      className={`whitespace-nowrap px-4 py-2 text-sm rounded-full ${
                        selectedCategory === category.id.toString()
                          ? "bg-primary text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                      onClick={() => handleCategorySelect(category.id.toString())}
                    >
                      {category.name}
                    </button>
                  ))}
            </div>
            <div className="flex items-center space-x-2">
              <button className="flex items-center space-x-1 text-sm text-gray-600 hover:text-primary">
                <Filter className="h-4 w-4" />
                <span>Filters</span>
              </button>
              <button className="flex items-center space-x-1 text-sm text-gray-600 hover:text-primary">
                <SortDesc className="h-4 w-4" />
                <span>Sort</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6">
        {/* Featured Products */}
        <h2 className="text-2xl font-semibold text-gray-800 mb-6">Featured Products & Services</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {productsLoading
            ? Array(4)
                .fill(0)
                .map((_, i) => (
                  <div
                    key={i}
                    className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse"
                  >
                    <div className="w-full h-48 bg-gray-200"></div>
                    <div className="p-4 space-y-3">
                      <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                      <div className="flex justify-between items-center">
                        <div className="h-6 bg-gray-200 rounded w-1/4"></div>
                        <div className="h-8 bg-gray-200 rounded w-1/4"></div>
                      </div>
                    </div>
                  </div>
                ))
            : products?.slice(0, 4).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
        </div>

        {/* Featured Categories */}
        <div className="mt-12">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6">Browse Categories</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {categoriesLoading
              ? Array(6)
                  .fill(0)
                  .map((_, i) => (
                    <div
                      key={i}
                      className="bg-white shadow-sm rounded-lg p-4 flex flex-col items-center justify-center animate-pulse"
                    >
                      <div className="w-12 h-12 rounded-full bg-gray-200"></div>
                      <div className="mt-2 h-4 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  ))
              : categories?.map((category) => (
                  <CategoryCard key={category.id} category={category} />
                ))}
          </div>
        </div>

        {/* Community Section */}
        <div className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold text-gray-800">Community Highlights</h2>
            <Link
              href="/community"
              className="text-primary hover:text-primary-dark text-sm font-medium"
            >
              View All
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Blog Post */}
            {blogs && blogs.length > 0 && (
              <BlogCard blog={blogs[0]} />
            )}

            {/* Event */}
            {events && events.length > 0 && (
              <EventCard event={events[0]} isUpcoming={true} />
            )}

            {/* Group */}
            {groups && groups.length > 0 && (
              <GroupCard group={groups[0]} />
            )}
          </div>
        </div>

        {/* Affiliate Banner */}
        <AffiliateSection />
      </div>
    </>
  );
};

export default HomePage;
