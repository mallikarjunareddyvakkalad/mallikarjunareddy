import { useState, useRef, useEffect } from "react";
import { useChat } from "@/hooks/useChat";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import ChatContact from "@/components/chat/ChatContact";
import ChatMessage from "@/components/chat/ChatMessage";
import { Conversation, Message } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Search, Phone, Video, Info, Paperclip, Mic, Image, Send } from "lucide-react";

const ChatPage = () => {
  const { isAuthenticated, user } = useAuth();
  const { 
    conversations, 
    activeConversation,
    messages,
    sendMessage,
    setActiveConversation,
    createConversation,
    isLoadingConversations,
    isLoadingMessages,
  } = useChat();
  const { toast } = useToast();
  const [messageInput, setMessageInput] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  // Handle message submission
  const handleSendMessage = () => {
    if (!messageInput.trim()) return;
    if (!activeConversation) {
      toast({
        title: "No active conversation",
        description: "Please select a conversation first",
        variant: "destructive",
      });
      return;
    }

    sendMessage(activeConversation.id, messageInput);
    setMessageInput("");
  };

  // Handle recording voice message
  const handleVoiceRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      toast({
        title: "Recording started",
        description: "Recording voice message..."
      });
    } else {
      toast({
        title: "Recording stopped",
        description: "Voice message ready to send"
      });
    }
  };

  // Handle pressing Enter to send message
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  // Filter conversations based on search
  const filteredConversations = searchInput
    ? conversations?.filter(
        (conv) => 
          conv.name?.toLowerCase().includes(searchInput.toLowerCase())
      )
    : conversations;

  if (!isAuthenticated) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white shadow-md rounded-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Authentication Required</h2>
          <p className="text-gray-600 mb-6">Please log in to access your messages</p>
          <Button asChild>
            <a href="/login">Log In</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex flex-col lg:flex-row h-[calc(100vh-180px)] gap-4">
        {/* Contacts Sidebar */}
        <div className="lg:w-1/4 bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
          <div className="p-4 border-b">
            <h2 className="text-lg font-semibold text-gray-800">Messages</h2>
          </div>
          <div className="p-3 border-b bg-gray-50">
            <div className="relative">
              <Input
                placeholder="Search contacts..."
                className="w-full pl-10"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
            </div>
          </div>
          <div className="overflow-y-auto flex-grow">
            <Tabs defaultValue="all">
              <TabsList className="w-full border-b rounded-none">
                <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
                <TabsTrigger value="unread" className="flex-1">Unread</TabsTrigger>
                <TabsTrigger value="groups" className="flex-1">Groups</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="m-0">
                {isLoadingConversations ? (
                  <div className="p-4 text-center text-gray-500">Loading conversations...</div>
                ) : filteredConversations && filteredConversations.length > 0 ? (
                  filteredConversations.map((conversation) => (
                    <ChatContact
                      key={conversation.id}
                      id={conversation.id}
                      name={conversation.name || `Conversation ${conversation.id}`}
                      avatar={conversation.type === 'group' ? undefined : "https://i.pravatar.cc/100"}
                      lastMessage="Hello, is this still available?"
                      timestamp={conversation.updatedAt ? new Date(conversation.updatedAt) : new Date()}
                      unreadCount={Math.floor(Math.random() * 5)}
                      isOnline={Math.random() > 0.5}
                      isActive={activeConversation?.id === conversation.id}
                      onClick={() => setActiveConversation(conversation)}
                    />
                  ))
                ) : (
                  <div className="p-4 text-center text-gray-500">
                    {searchInput ? "No conversations found" : "No conversations yet"}
                  </div>
                )}
              </TabsContent>
              <TabsContent value="unread" className="m-0">
                <div className="p-4 text-center text-gray-500">No unread messages</div>
              </TabsContent>
              <TabsContent value="groups" className="m-0">
                <div className="p-4 text-center text-gray-500">No group chats</div>
              </TabsContent>
            </Tabs>
          </div>
          <div className="p-3 border-t">
            <Button 
              className="w-full"
              onClick={() => {
                const newConversation = {
                  name: "New Conversation",
                  type: "private",
                  createdBy: user?.id
                };
                createConversation(newConversation);
              }}
            >
              <i className="ri-chat-new-line mr-1"></i> New Message
            </Button>
          </div>
        </div>

        {/* Chat Window */}
        {activeConversation ? (
          <div className="lg:w-3/4 bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
            {/* Chat Header */}
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarImage src={activeConversation.type === 'group' ? undefined : "https://i.pravatar.cc/100"} />
                  <AvatarFallback>
                    {activeConversation.name
                      ? activeConversation.name.substring(0, 2).toUpperCase()
                      : "UC"}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold text-gray-800">
                    {activeConversation.name || `Conversation ${activeConversation.id}`}
                  </div>
                  <div className="text-xs text-gray-500">Last active 2 hours ago</div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="ghost" size="icon" className="text-gray-600">
                  <Phone className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-gray-600">
                  <Video className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-gray-600">
                  <Info className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Chat Messages */}
            <div className="flex-grow p-4 overflow-y-auto bg-gray-50">
              {isLoadingMessages ? (
                <div className="flex justify-center items-center h-full">
                  <div className="text-gray-500">Loading messages...</div>
                </div>
              ) : messages && messages.length > 0 ? (
                <div className="space-y-4">
                  {/* Date Separator */}
                  <div className="flex justify-center">
                    <div className="bg-gray-200 text-gray-600 text-xs px-3 py-1 rounded-full">
                      Today
                    </div>
                  </div>

                  {messages.map((message, index) => (
                    <ChatMessage
                      key={message.id}
                      message={message}
                      isOwn={message.senderId === user?.id}
                      senderName={message.senderId === user?.id ? (user?.name || user?.username || "You") : "Contact"}
                      senderAvatar={message.senderId === user?.id ? user?.avatar : undefined}
                      showSender={index === 0 || messages[index - 1]?.senderId !== message.senderId}
                    />
                  ))}

                  <div ref={messagesEndRef} />
                </div>
              ) : (
                <div className="flex justify-center items-center h-full">
                  <div className="text-center text-gray-500">
                    <div className="mb-2">No messages yet</div>
                    <div className="text-sm">Send a message to start the conversation</div>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <div className="p-3 border-t">
              <div className="flex items-end">
                <div className="flex space-x-1 mr-2">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-gray-600"
                    onClick={() => {
                      toast({
                        title: "Feature not available",
                        description: "This feature is not implemented in the current version"
                      });
                    }}
                  >
                    <Paperclip className="h-5 w-5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={`${isRecording ? "text-red-500" : "text-gray-600"}`}
                    onClick={handleVoiceRecording}
                  >
                    <Mic className="h-5 w-5" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-gray-600"
                    onClick={() => {
                      toast({
                        title: "Feature not available",
                        description: "This feature is not implemented in the current version"
                      });
                    }}
                  >
                    <Image className="h-5 w-5" />
                  </Button>
                </div>
                
                <div className="flex-grow">
                  <Input
                    placeholder={isRecording ? "Recording voice message..." : "Type a message..."}
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={handleKeyPress}
                    disabled={isRecording}
                  />
                </div>
                
                <Button 
                  className="ml-2 rounded-full"
                  onClick={handleSendMessage}
                  disabled={!messageInput.trim() && !isRecording}
                >
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="lg:w-3/4 bg-white rounded-lg shadow-md overflow-hidden flex flex-col">
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-gray-500 p-8">
                <div className="flex justify-center mb-4">
                  <MessageSquare className="h-16 w-16 text-gray-300" />
                </div>
                <h3 className="text-lg font-semibold mb-2">No conversation selected</h3>
                <p className="mb-4">Select a conversation from the sidebar or start a new one</p>
                <Button 
                  onClick={() => {
                    const newConversation = {
                      name: "New Conversation",
                      type: "private",
                      createdBy: user?.id
                    };
                    createConversation(newConversation);
                  }}
                >
                  Start New Conversation
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatPage;

function MessageSquare(props: any) {
  return <div {...props}><i className="ri-message-3-line text-6xl"></i></div>;
}
