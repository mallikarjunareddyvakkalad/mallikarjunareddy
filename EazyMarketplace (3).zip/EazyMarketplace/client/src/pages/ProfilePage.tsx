import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  User, 
  Edit, 
  Share2, 
  LogOut, 
  ShoppingBag, 
  MessageSquare, 
  Star, 
  Heart, 
  Coins, 
  Gift, 
  CreditCard,
  Clipboard,
  CheckCircle
} from "lucide-react";
import { Product, PointsTransaction } from "@shared/schema";
import ProductCard from "@/components/marketplace/ProductCard";

// Profile update form schema
const profileFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  address: z.string().optional(),
  bio: z.string().optional(),
  avatar: z.string().url("Must be a valid URL").optional().or(z.literal(''))
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

// Withdrawal form schema
const withdrawalFormSchema = z.object({
  amount: z.coerce.number().min(100, "Minimum withdrawal amount is 100 points"),
  paymentMethod: z.enum(["bank", "upi", "paytm"]),
  accountDetails: z.string().min(5, "Account details are required")
});

type WithdrawalFormValues = z.infer<typeof withdrawalFormSchema>;

const ProfilePage = () => {
  const { user, isAuthenticated, isLoading, updateProfile, logout } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isWithdrawDialogOpen, setIsWithdrawDialogOpen] = useState(false);
  const [copiedReferral, setCopiedReferral] = useState(false);

  // Profile update form
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      phone: user?.phone || "",
      address: user?.address || "",
      bio: user?.bio || "",
      avatar: user?.avatar || ""
    }
  });

  // Withdrawal form
  const withdrawalForm = useForm<WithdrawalFormValues>({
    resolver: zodResolver(withdrawalFormSchema),
    defaultValues: {
      amount: 100,
      paymentMethod: "upi",
      accountDetails: ""
    }
  });

  // Get user listings (products)
  const { data: userProducts, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products/user'],
    enabled: isAuthenticated,
  });

  // Get user points transactions
  const { data: pointsTransactions, isLoading: transactionsLoading } = useQuery<PointsTransaction[]>({
    queryKey: ['/api/points'],
    enabled: isAuthenticated,
    select: (data) => data.transactions || [],
  });

  // Initialize form values when user data loads
  useState(() => {
    if (user) {
      form.reset({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        address: user.address || "",
        bio: user.bio || "",
        avatar: user.avatar || ""
      });
    }
  });

  // Handle profile update submit
  const onSubmit = async (data: ProfileFormValues) => {
    try {
      await updateProfile(data);
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  };

  // Handle withdrawal submit
  const onWithdrawalSubmit = async (data: WithdrawalFormValues) => {
    try {
      const response = await apiRequest('POST', '/api/points/withdraw', {
        amount: data.amount
      });
      
      const result = await response.json();
      
      toast({
        title: "Withdrawal Request Submitted",
        description: result.message || "Your withdrawal request has been submitted",
      });
      
      setIsWithdrawDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/points'] });
    } catch (error: any) {
      toast({
        title: "Withdrawal Failed",
        description: error.message || "Failed to process withdrawal request",
        variant: "destructive"
      });
    }
  };

  // Copy referral link
  const copyReferralLink = () => {
    if (!user?.referralCode) return;
    
    const referralLink = `${window.location.origin}/register?ref=${user.referralCode}`;
    navigator.clipboard.writeText(referralLink);
    
    setCopiedReferral(true);
    toast({
      title: "Referral Link Copied",
      description: "Your referral link has been copied to clipboard"
    });
    
    setTimeout(() => setCopiedReferral(false), 3000);
  };

  // Calculate points stats
  const calculatePointsStats = () => {
    if (!pointsTransactions) return { earned: 0, spent: 0 };
    
    let earned = 0;
    let spent = 0;
    
    pointsTransactions.forEach(tx => {
      if (tx.amount > 0) {
        earned += tx.amount;
      } else {
        spent += Math.abs(tx.amount);
      }
    });
    
    return { earned, spent };
  };

  const pointsStats = calculatePointsStats();

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center">
          <div className="w-full max-w-4xl">
            <div className="animate-pulse">
              <div className="h-48 bg-gray-200 rounded-lg mb-6"></div>
              <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-full mb-6"></div>
              <div className="grid grid-cols-3 gap-4">
                <div className="h-24 bg-gray-200 rounded"></div>
                <div className="h-24 bg-gray-200 rounded"></div>
                <div className="h-24 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-8">
            <User className="h-16 w-16 text-gray-400 mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Authentication Required</h2>
            <p className="text-gray-600 mb-6 text-center">
              Please log in or create an account to view your profile
            </p>
            <div className="flex gap-4">
              <Button asChild>
                <a href="/login">Log In</a>
              </Button>
              <Button variant="outline" asChild>
                <a href="/register">Create Account</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Get user initials for avatar
  const getUserInitials = () => {
    if (!user.name) return "U";
    const names = user.name.split(" ");
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return user.name.substring(0, 2).toUpperCase();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="md:w-1/4">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>{getUserInitials()}</AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold">{user.name || user.username}</h2>
                <p className="text-gray-500 text-sm mb-2">{user.email}</p>
                <Badge variant="outline" className="mb-4">
                  {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                </Badge>
                
                <div className="w-full flex flex-col gap-2 mt-2">
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-start"
                    onClick={() => setIsEditing(true)}
                  >
                    <Edit className="mr-2 h-4 w-4" /> Edit Profile
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-start"
                    onClick={copyReferralLink}
                  >
                    {copiedReferral ? (
                      <>
                        <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> Copied!
                      </>
                    ) : (
                      <>
                        <Share2 className="mr-2 h-4 w-4" /> Share Referral Link
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full flex items-center justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
                    onClick={logout}
                  >
                    <LogOut className="mr-2 h-4 w-4" /> Logout
                  </Button>
                </div>
              </div>
              
              <div className="border-t mt-6 pt-6">
                <h3 className="font-medium text-gray-800 mb-4">Account Information</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Member since</span>
                    <span>{new Date(user.createdAt).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Status</span>
                    <Badge variant={user.status === 'active' ? 'success' : 'secondary'}>
                      {user.status.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Points Balance</span>
                    <span className="font-semibold">{user.points}</span>
                  </div>
                  {user.referralCode && (
                    <div className="flex justify-between">
                      <span className="text-gray-500">Referral Code</span>
                      <span className="font-mono">{user.referralCode}</span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Main Content */}
        <div className="md:w-3/4">
          <Tabs defaultValue="overview">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="listings">Listings</TabsTrigger>
              <TabsTrigger value="points">Points & Rewards</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            
            {/* Overview Tab */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-blue-100 rounded-full mb-2">
                        <ShoppingBag className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="text-2xl font-bold">{userProducts?.length || 0}</div>
                      <div className="text-sm text-gray-500">Active Listings</div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-green-100 rounded-full mb-2">
                        <MessageSquare className="h-6 w-6 text-green-600" />
                      </div>
                      <div className="text-2xl font-bold">12</div>
                      <div className="text-sm text-gray-500">Messages</div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-purple-100 rounded-full mb-2">
                        <Star className="h-6 w-6 text-purple-600" />
                      </div>
                      <div className="text-2xl font-bold">4.8</div>
                      <div className="text-sm text-gray-500">Rating</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Points Activity</CardTitle>
                    <CardDescription>
                      Your recent points transactions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {transactionsLoading ? (
                      <div className="p-4 text-center">Loading transactions...</div>
                    ) : pointsTransactions && pointsTransactions.length > 0 ? (
                      <div className="space-y-3">
                        {pointsTransactions.slice(0, 3).map((tx, index) => (
                          <div key={index} className="flex justify-between items-center border-b pb-2">
                            <div>
                              <div className="font-medium">{tx.type.charAt(0).toUpperCase() + tx.type.slice(1).replace('_', ' ')}</div>
                              <div className="text-xs text-gray-500">{new Date(tx.createdAt).toLocaleDateString()}</div>
                            </div>
                            <div className={`font-semibold ${tx.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {tx.amount > 0 ? '+' : ''}{tx.amount}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 text-center text-gray-500">
                        No points transactions yet
                      </div>
                    )}
                    
                    <Button variant="link" className="mt-3 w-full" asChild>
                      <a href="#points">View All Transactions</a>
                    </Button>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>
                      Your recent actions and interactions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <div className="bg-blue-100 p-2 rounded-full mr-3">
                          <Heart className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <div className="font-medium">You liked a product</div>
                          <div className="text-sm text-gray-500">Premium Headphones - 2 hours ago</div>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="bg-green-100 p-2 rounded-full mr-3">
                          <MessageSquare className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <div className="font-medium">Message received</div>
                          <div className="text-sm text-gray-500">From Karthik B. - Yesterday</div>
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="bg-purple-100 p-2 rounded-full mr-3">
                          <ShoppingBag className="h-4 w-4 text-purple-600" />
                        </div>
                        <div>
                          <div className="font-medium">You added a new product</div>
                          <div className="text-sm text-gray-500">Gaming Laptop - 3 days ago</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {userProducts && userProducts.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Your Listings</CardTitle>
                    <CardDescription>
                      Your active products and services
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {userProducts.slice(0, 3).map((product) => (
                        <div key={product.id} className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                          <div className="h-32 bg-gray-100">
                            <img
                              src={product.image || `https://via.placeholder.com/300x200?text=${encodeURIComponent(product.title.charAt(0))}`}
                              alt={product.title}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="p-3">
                            <h3 className="font-medium text-gray-800 truncate">{product.title}</h3>
                            <div className="flex justify-between items-center mt-2">
                              <div className="font-semibold">₹{product.price.toLocaleString('en-IN')}</div>
                              <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                                {product.status?.toUpperCase()}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <Button variant="outline" className="w-full mt-4" asChild>
                      <a href="#listings">View All Listings</a>
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            {/* Listings Tab */}
            <TabsContent value="listings">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Your Listings</CardTitle>
                      <CardDescription>
                        Manage your products and services
                      </CardDescription>
                    </div>
                    <Button asChild>
                      <a href="/dashboard">Add New Listing</a>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {productsLoading ? (
                    <div className="p-8 text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                      <p>Loading your listings...</p>
                    </div>
                  ) : userProducts && userProducts.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {userProducts.map((product) => (
                        <ProductCard key={product.id} product={product} />
                      ))}
                    </div>
                  ) : (
                    <div className="p-8 text-center">
                      <ShoppingBag className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-800 mb-2">No Listings Yet</h3>
                      <p className="text-gray-500 mb-4">Start selling by creating your first product listing</p>
                      <Button asChild>
                        <a href="/dashboard">Add Product</a>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Points & Rewards Tab */}
            <TabsContent value="points">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-primary/10 rounded-full mb-2">
                        <Coins className="h-6 w-6 text-primary" />
                      </div>
                      <div className="text-2xl font-bold">{user.points}</div>
                      <div className="text-sm text-gray-500">Current Balance</div>
                      {user.points >= 100 ? (
                        <Button 
                          size="sm" 
                          className="mt-3"
                          onClick={() => setIsWithdrawDialogOpen(true)}
                        >
                          Withdraw
                        </Button>
                      ) : (
                        <div className="text-xs text-gray-500 mt-2">
                          Need {100 - user.points} more points to withdraw
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-green-100 rounded-full mb-2">
                        <Gift className="h-6 w-6 text-green-600" />
                      </div>
                      <div className="text-2xl font-bold">{pointsStats.earned}</div>
                      <div className="text-sm text-gray-500">Total Points Earned</div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center">
                      <div className="p-3 bg-blue-100 rounded-full mb-2">
                        <CreditCard className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="text-2xl font-bold">{pointsStats.spent}</div>
                      <div className="text-sm text-gray-500">Total Points Spent</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Refer & Earn</CardTitle>
                  <CardDescription>
                    Earn 2 points for every friend who signs up using your referral code
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg mb-4">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium">Your Referral Code</div>
                      <div className="text-sm text-gray-500">Share this code with friends</div>
                    </div>
                    <div className="mt-2 flex">
                      <div className="bg-white border rounded-l-md py-2 px-4 font-mono font-medium flex-grow">
                        {user.referralCode || "No referral code available"}
                      </div>
                      <Button 
                        variant="default" 
                        className="rounded-l-none"
                        onClick={copyReferralLink}
                      >
                        {copiedReferral ? <CheckCircle className="h-4 w-4" /> : <Clipboard className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white border rounded-lg p-4">
                      <div className="text-lg font-bold text-center mb-1">2</div>
                      <div className="text-xs text-center text-gray-500">Points per referral</div>
                    </div>
                    <div className="bg-white border rounded-lg p-4">
                      <div className="text-lg font-bold text-center mb-1">₹1</div>
                      <div className="text-xs text-center text-gray-500">Value per point</div>
                    </div>
                    <div className="bg-white border rounded-lg p-4">
                      <div className="text-lg font-bold text-center mb-1">100</div>
                      <div className="text-xs text-center text-gray-500">Min. points to withdraw</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Points History</CardTitle>
                  <CardDescription>
                    Your points transactions and reward history
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {transactionsLoading ? (
                    <div className="p-4 text-center">Loading transactions...</div>
                  ) : pointsTransactions && pointsTransactions.length > 0 ? (
                    <div className="border rounded-lg overflow-hidden">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Points</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {pointsTransactions.map((tx, index) => (
                            <tr key={index}>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {new Date(tx.createdAt).toLocaleDateString()}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-900">
                                {tx.description || `Points ${tx.amount > 0 ? 'earned' : 'spent'} for ${tx.type}`}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <Badge variant="outline">
                                  {tx.type.charAt(0).toUpperCase() + tx.type.slice(1).replace('_', ' ')}
                                </Badge>
                              </td>
                              <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium text-right ${tx.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {tx.amount > 0 ? '+' : ''}{tx.amount}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="p-4 text-center text-gray-500">
                      No points transactions yet
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Settings Tab */}
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Settings</CardTitle>
                  <CardDescription>
                    Update your personal information and account settings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="flex flex-col md:flex-row md:space-x-4 space-y-4 md:space-y-0">
                        <div className="md:w-1/2">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Your full name" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="md:w-1/2">
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email Address</FormLabel>
                                <FormControl>
                                  <Input placeholder="Your email address" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <div className="flex flex-col md:flex-row md:space-x-4 space-y-4 md:space-y-0">
                        <div className="md:w-1/2">
                          <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Phone Number</FormLabel>
                                <FormControl>
                                  <Input placeholder="Your phone number" {...field} value={field.value || ''} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <div className="md:w-1/2">
                          <FormField
                            control={form.control}
                            name="avatar"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Profile Picture URL</FormLabel>
                                <FormControl>
                                  <Input placeholder="URL to your profile picture" {...field} value={field.value || ''} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Input placeholder="Your address" {...field} value={field.value || ''} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="bio"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bio</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Tell us about yourself" 
                                {...field} 
                                value={field.value || ''}
                                rows={4} 
                              />
                            </FormControl>
                            <FormDescription>
                              This will be displayed on your public profile
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="flex justify-end">
                        <Button type="submit">Save Changes</Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>
                    Manage your account preferences and security settings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Password</h3>
                      <p className="text-sm text-gray-500 mb-4">
                        Change your password to keep your account secure
                      </p>
                      <Button>Change Password</Button>
                    </div>
                    
                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium mb-2">Notifications</h3>
                      <p className="text-sm text-gray-500 mb-4">
                        Manage your notification preferences
                      </p>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">Email Notifications</div>
                            <div className="text-sm text-gray-500">Receive updates via email</div>
                          </div>
                          <div className="flex items-center h-5">
                            <input
                              id="email-notifications"
                              type="checkbox"
                              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                              defaultChecked
                            />
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">Marketing Emails</div>
                            <div className="text-sm text-gray-500">Receive marketing communications</div>
                          </div>
                          <div className="flex items-center h-5">
                            <input
                              id="marketing-emails"
                              type="checkbox"
                              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                            />
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">Push Notifications</div>
                            <div className="text-sm text-gray-500">Receive push notifications</div>
                          </div>
                          <div className="flex items-center h-5">
                            <input
                              id="push-notifications"
                              type="checkbox"
                              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                              defaultChecked
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border-t pt-6">
                      <h3 className="text-lg font-medium text-red-600 mb-2">Danger Zone</h3>
                      <p className="text-sm text-gray-500 mb-4">
                        Permanently delete your account and all of your content
                      </p>
                      <Button variant="destructive">Delete Account</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Edit Profile Dialog */}
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
            <DialogDescription>
              Make changes to your profile information
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bio</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="About you" 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="avatar"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Avatar URL</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://example.com/avatar.jpg" 
                        {...field} 
                        value={field.value || ''}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="submit">Save changes</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Points Withdrawal Dialog */}
      <Dialog open={isWithdrawDialogOpen} onOpenChange={setIsWithdrawDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Withdraw Points</DialogTitle>
            <DialogDescription>
              Convert your points to rupees (1 point = ₹1)
            </DialogDescription>
          </DialogHeader>
          <Form {...withdrawalForm}>
            <form onSubmit={withdrawalForm.handleSubmit(onWithdrawalSubmit)} className="space-y-4">
              <FormField
                control={withdrawalForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount (Points)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        {...field} 
                        min={100} 
                        max={user.points} 
                      />
                    </FormControl>
                    <FormDescription>
                      Minimum withdrawal: 100 points | Your balance: {user.points} points
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={withdrawalForm.control}
                name="paymentMethod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Method</FormLabel>
                    <FormControl>
                      <select
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        {...field}
                      >
                        <option value="upi">UPI</option>
                        <option value="bank">Bank Transfer</option>
                        <option value="paytm">Paytm</option>
                      </select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={withdrawalForm.control}
                name="accountDetails"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Details</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter your payment details" 
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      For UPI: Enter your UPI ID (e.g., name@upi)
                      <br />
                      For Bank: Enter account number, IFSC code, and name
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="submit" 
                  disabled={user.points < 100}
                >
                  Withdraw
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProfilePage;
