import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Product, User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Heart, 
  Share2, 
  ShoppingCart, 
  MapPin, 
  Clock,
  MessageSquare,
  Star,
  Shield,
  CreditCard,
  Truck,
  FileText,
  Info
} from "lucide-react";
import ProductCard from "@/components/marketplace/ProductCard";
import { formatDistanceToNow } from "date-fns";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [liked, setLiked] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [message, setMessage] = useState("");

  // Fetch product details
  const { data: product, isLoading } = useQuery<Product>({
    queryKey: [`/api/products/${id}`],
    enabled: !!id,
  });

  // Fetch seller details
  const { data: seller } = useQuery<User>({
    queryKey: [`/api/users/${product?.sellerId}`],
    enabled: !!product?.sellerId,
  });

  // Fetch related products
  const { data: relatedProducts } = useQuery<Product[]>({
    queryKey: ['/api/products', product?.categoryId],
    enabled: !!product?.categoryId,
  });

  // Fetch AI recommendations
  const { data: recommendations } = useQuery<{ recommendations: string[] }>({
    queryKey: ['/api/ai/product-recommendations', user?.id, id],
    enabled: !!product && !!user?.id,
  });

  // Handle like button click
  const handleLike = () => {
    setLiked(!liked);
    toast({
      title: liked ? "Removed from favorites" : "Added to favorites",
      description: liked ? "Product removed from your favorites" : "Product added to your favorites"
    });
  };

  // Handle share button click
  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: product?.title || "Check out this product",
          text: product?.description || "Found on EazyBuySells",
          url
        });
      } catch (error) {
        console.error("Error sharing:", error);
      }
    } else {
      try {
        await navigator.clipboard.writeText(url);
        toast({
          title: "Link copied!",
          description: "Product link copied to clipboard"
        });
      } catch (error) {
        console.error("Error copying to clipboard:", error);
      }
    }
  };

  // Handle contact seller
  const handleContactSeller = () => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication required",
        description: "Please log in to contact the seller",
        variant: "destructive"
      });
      return;
    }

    if (!message.trim()) {
      toast({
        title: "Message required",
        description: "Please enter a message for the seller",
        variant: "destructive"
      });
      return;
    }

    // In a real app, this would create a conversation and send the message
    toast({
      title: "Message sent",
      description: "Your message has been sent to the seller"
    });
    setMessage("");
  };

  // Format timestamp
  const formatDate = (dateString?: Date | string) => {
    if (!dateString) return "Recently";
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8 animate-pulse">
          <div className="md:w-1/2 bg-gray-200 h-96 rounded-lg"></div>
          <div className="md:w-1/2 space-y-4">
            <div className="h-8 bg-gray-200 rounded w-3/4"></div>
            <div className="h-6 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-full"></div>
            <div className="h-4 bg-gray-200 rounded w-full"></div>
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="h-10 bg-gray-200 rounded w-full"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="p-8 text-center">
            <Info className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Product Not Found</h2>
            <p className="text-gray-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
            <Button asChild>
              <Link href="/">Back to Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Product Image */}
        <div className="md:w-1/2">
          <div className="bg-white rounded-lg overflow-hidden shadow-md">
            <img
              src={product.image || "https://via.placeholder.com/600x400?text=No+Image"}
              alt={product.title}
              className="w-full h-auto object-cover aspect-video"
            />
          </div>
          
          <div className="hidden md:grid grid-cols-4 gap-2 mt-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-white p-1 rounded border hover:border-primary cursor-pointer">
                <img
                  src={product.image || `https://via.placeholder.com/150x150?text=Image+${i}`}
                  alt={`Product view ${i}`}
                  className="w-full h-auto aspect-square object-cover"
                />
              </div>
            ))}
          </div>
        </div>
        
        {/* Product Details */}
        <div className="md:w-1/2">
          <Badge 
            className="mb-3 font-medium"
            variant={product.status === 'active' ? 'default' : 'secondary'}
          >
            {product.status?.toUpperCase() || 'ACTIVE'}
          </Badge>
          
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{product.title}</h1>
          
          <div className="flex items-center mb-4 text-sm text-gray-500">
            <div className="flex items-center mr-4">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{product.location || "Location not specified"}</span>
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              <span>Posted {formatDate(product.createdAt)}</span>
            </div>
          </div>
          
          <div className="flex items-center mb-6">
            <div className="flex text-yellow-400">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star 
                  key={star} 
                  className={`h-5 w-5 ${star <= 4 ? 'fill-current' : ''}`} 
                />
              ))}
            </div>
            <span className="ml-2 text-gray-600 text-sm">
              {product.views || 0} views
            </span>
          </div>
          
          <div className="text-3xl font-bold text-gray-900 mb-4 font-montserrat">
            ₹{product.price.toLocaleString('en-IN')}
          </div>
          
          <p className="text-gray-700 mb-6">
            {product.description || "No description provided for this product."}
          </p>
          
          <div className="flex flex-wrap gap-3 mb-6">
            <Button 
              size="lg" 
              className="flex-1"
              onClick={() => toast({
                title: "Feature not available",
                description: "This feature is not implemented in the current version",
              })}
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              Buy Now
            </Button>
            
            <Button 
              variant="outline" 
              size="lg"
              className={liked ? "text-red-500" : ""}
              onClick={handleLike}
            >
              <Heart className={`h-5 w-5 ${liked ? "fill-current" : ""}`} />
            </Button>
            
            <Button 
              variant="outline" 
              size="lg" 
              onClick={handleShare}
            >
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
          
          {/* Seller Info */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex items-center">
                <Avatar className="h-12 w-12 mr-4">
                  <AvatarImage src={seller?.avatar} />
                  <AvatarFallback>
                    {seller?.name 
                      ? seller.name.split(' ').map(n => n[0]).join('').toUpperCase() 
                      : 'S'}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-gray-800">
                    {seller?.name || seller?.username || "Seller"}
                  </h3>
                  <p className="text-sm text-gray-500">
                    Member since {seller?.createdAt 
                      ? new Date(seller.createdAt).toLocaleDateString('en-US', {
                          month: 'short',
                          year: 'numeric'
                        }) 
                      : "recently"}
                  </p>
                </div>
                <Button variant="outline" className="ml-auto" asChild>
                  <Link href={`/profile/${product.sellerId}`}>View Profile</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Contact Form */}
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold text-gray-800 mb-3">
                Contact Seller
              </h3>
              <Textarea
                placeholder="Write your message here..."
                className="mb-3"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
              <Button 
                className="w-full"
                onClick={handleContactSeller}
                disabled={!isAuthenticated}
              >
                <MessageSquare className="h-5 w-5 mr-2" />
                Send Message
              </Button>
              {!isAuthenticated && (
                <p className="text-sm text-gray-500 mt-2 text-center">
                  Please <Link href="/login" className="text-primary hover:underline">log in</Link> to contact the seller
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Product Details Tabs */}
      <div className="mt-12">
        <Tabs defaultValue="details">
          <TabsList className="w-full border-b justify-start">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="shipping">Shipping & Returns</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>
          <TabsContent value="details" className="py-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Product Specifications</h3>
                <table className="w-full">
                  <tbody>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">Category</td>
                      <td className="py-2 font-medium">
                        {product.categoryId ? `Category #${product.categoryId}` : "Not specified"}
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">Condition</td>
                      <td className="py-2 font-medium">New</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">Location</td>
                      <td className="py-2 font-medium">{product.location || "Not specified"}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">Posted On</td>
                      <td className="py-2 font-medium">
                        {product.createdAt 
                          ? new Date(product.createdAt).toLocaleDateString('en-US', {
                              day: 'numeric',
                              month: 'long',
                              year: 'numeric'
                            })
                          : "Recently"}
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">Views</td>
                      <td className="py-2 font-medium">{product.views || 0}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Safety Tips</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Shield className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Meet in a safe, public place</p>
                  </li>
                  <li className="flex items-start">
                    <Shield className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Check the item before paying</p>
                  </li>
                  <li className="flex items-start">
                    <Shield className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Pay only after inspecting the item</p>
                  </li>
                  <li className="flex items-start">
                    <Shield className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Never share your personal financial information</p>
                  </li>
                </ul>
                
                <h3 className="text-lg font-semibold mt-6 mb-4">Payment Options</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <CreditCard className="h-5 w-5 text-secondary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Cash on Delivery</p>
                  </li>
                  <li className="flex items-start">
                    <CreditCard className="h-5 w-5 text-secondary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">UPI Payment</p>
                  </li>
                  <li className="flex items-start">
                    <CreditCard className="h-5 w-5 text-secondary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Bank Transfer</p>
                  </li>
                </ul>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="shipping" className="py-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Shipping Information</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Truck className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Free shipping across India on orders above ₹500</p>
                  </li>
                  <li className="flex items-start">
                    <Truck className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Standard shipping: 3-5 business days</p>
                  </li>
                  <li className="flex items-start">
                    <Truck className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Express shipping: 1-2 business days (additional charges)</p>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Return Policy</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <FileText className="h-5 w-5 text-secondary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">7-day return policy from date of delivery</p>
                  </li>
                  <li className="flex items-start">
                    <FileText className="h-5 w-5 text-secondary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Item must be unused and in original packaging</p>
                  </li>
                  <li className="flex items-start">
                    <FileText className="h-5 w-5 text-secondary mr-2 mt-0.5" />
                    <p className="text-sm text-gray-700">Buyer is responsible for return shipping costs</p>
                  </li>
                </ul>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="reviews" className="py-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/3">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">Customer Reviews</h3>
                  <div className="flex items-center mb-4">
                    <div className="text-3xl font-bold mr-3">4.8</div>
                    <div>
                      <div className="flex text-yellow-400">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star 
                            key={star} 
                            className={`h-5 w-5 ${star <= 4 ? 'fill-current' : ''}`} 
                          />
                        ))}
                      </div>
                      <div className="text-sm text-gray-500">Based on 143 reviews</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {[5, 4, 3, 2, 1].map((rating) => (
                      <div key={rating} className="flex items-center">
                        <span className="text-sm text-gray-600 w-3">{rating}</span>
                        <div className="w-full bg-gray-200 rounded-full h-2 mx-2">
                          <div 
                            className="bg-yellow-400 h-2 rounded-full" 
                            style={{ width: `${rating === 5 ? 75 : rating === 4 ? 18 : rating === 3 ? 5 : 2}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600 w-8">
                          {rating === 5 ? "75%" : rating === 4 ? "18%" : rating === 3 ? "5%" : "2%"}
                        </span>
                      </div>
                    ))}
                  </div>
                  
                  <Button className="w-full mt-4">Write a Review</Button>
                </div>
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-lg font-semibold mb-4">Recent Reviews</h3>
                <div className="space-y-4">
                  {/* Sample reviews */}
                  {[1, 2, 3].map((i) => (
                    <Card key={i} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center">
                            <Avatar className="h-10 w-10 mr-3">
                              <AvatarImage src={`https://i.pravatar.cc/40?img=${i + 10}`} />
                              <AvatarFallback>U{i}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium text-gray-800">
                                {["Priya S.", "Rahul K.", "Anita M."][i - 1]}
                              </div>
                              <div className="text-xs text-gray-500">
                                {formatDate(new Date(Date.now() - i * 86400000 * 3))}
                              </div>
                            </div>
                          </div>
                          <div className="flex text-yellow-400">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star 
                                key={star} 
                                className={`h-4 w-4 ${star <= 5 ? 'fill-current' : ''}`} 
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-700 text-sm">
                          {[
                            "Great product! The quality is excellent and it was delivered promptly. Very satisfied with my purchase.",
                            "The product is good but the delivery took longer than expected. Overall happy with the purchase.",
                            "Excellent value for money. The seller was responsive and helpful."
                          ][i - 1]}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <Button variant="outline" className="w-full mt-4">
                  Load More Reviews
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Similar Products */}
      <div className="mt-12">
        <h2 className="text-2xl font-semibold text-gray-800 mb-6">Similar Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {relatedProducts
            ?.filter(p => p.id !== product.id)
            .slice(0, 4)
            .map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
        </div>
      </div>
      
      {/* AI Recommendations */}
      {recommendations?.recommendations && recommendations.recommendations.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6">Recommended for You</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {recommendations.recommendations.slice(0, 4).map((title, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="h-44 bg-gray-100 flex items-center justify-center">
                  <img
                    src={`https://source.unsplash.com/random/300x200?${title.split(' ')[0]}`}
                    alt={title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-gray-800 mb-2">{title}</h3>
                  <div className="font-montserrat text-lg font-semibold text-gray-900">
                    ₹{(Math.floor(Math.random() * 50) + 10) * 100}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductDetail;
