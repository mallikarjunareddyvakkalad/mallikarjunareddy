import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useParams, useLocation } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  ChevronLeft,
  Heart,
  Share2,
  MapPin,
  Tag,
  Calendar,
  MessageSquare,
  ShoppingBag,
  AlertCircle,
  Star,
  ThumbsUp,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import ProductCard from "@/components/ProductCard";

const ProductDetails = () => {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [comment, setComment] = useState("");
  const [activeImage, setActiveImage] = useState(0);

  // Fetch product details
  const { data: product, isLoading, error } = useQuery({
    queryKey: [`/api/products/${id}`],
  });

  // Fetch product comments
  const { 
    data: comments, 
    isLoading: isLoadingComments, 
    refetch: refetchComments 
  } = useQuery({
    queryKey: [`/api/comments`, { productId: Number(id) }],
  });

  // Fetch seller profile
  const { data: seller, isLoading: isLoadingSeller } = useQuery({
    queryKey: ['/api/users/' + (product?.sellerId) + '/profile'],
    enabled: !!product?.sellerId,
  });

  // Fetch similar products
  const { data: similarProducts, isLoading: isLoadingSimilar } = useQuery({
    queryKey: ['/api/products', { 
      category: product?.category,
      limit: 4,
      exclude: Number(id),
    }],
    enabled: !!product?.category,
  });

  const handleShareProduct = () => {
    const url = `${window.location.origin}/product/${id}`;
    navigator.clipboard.writeText(url);
    
    toast({
      title: "Link copied!",
      description: "Product link copied to clipboard",
    });
  };

  const handleFavoriteProduct = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please sign in to add products to favorites",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Added to favorites!",
      description: "Product has been added to your favorites",
    });
  };

  const handleContactSeller = () => {
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please sign in to contact sellers",
        variant: "destructive",
      });
      return;
    }

    // In a real app, this would open a chat with the seller
    toast({
      title: "Contact initiated!",
      description: "A chat has been opened with the seller",
    });
  };

  const handleSubmitComment = async () => {
    if (!comment.trim()) return;
    
    if (!isAuthenticated) {
      toast({
        title: "Login required",
        description: "Please sign in to comment on products",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest("POST", "/api/comments", {
        productId: Number(id),
        content: comment,
      });
      
      setComment("");
      refetchComments();
      
      toast({
        title: "Comment added!",
        description: "Your comment has been posted",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to post comment",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Button variant="ghost" className="mb-6" onClick={() => setLocation("/marketplace")}>
            <ChevronLeft size={16} className="mr-2" /> Back to Marketplace
          </Button>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <Skeleton className="w-full h-96 rounded-lg mb-4" />
              <div className="grid grid-cols-4 gap-2">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="w-full h-24 rounded-md" />
                ))}
              </div>
            </div>
            
            <div className="space-y-4">
              <Skeleton className="h-10 w-3/4" />
              <Skeleton className="h-6 w-1/4" />
              <Skeleton className="h-8 w-1/3" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
              <div className="pt-4">
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center py-16">
          <AlertCircle size={64} className="mx-auto text-red-500 mb-4" />
          <h2 className="text-2xl font-bold mb-2">Product Not Found</h2>
          <p className="text-gray-600 mb-6">
            Sorry, we couldn't find the product you're looking for.
          </p>
          <Button onClick={() => setLocation("/marketplace")}>
            Return to Marketplace
          </Button>
        </div>
      </div>
    );
  }

  const productImages = product.images && product.images.length > 0 
    ? product.images 
    : ["https://images.unsplash.com/photo-1553531384-cc64ac80f931?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=350&q=80"];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Button variant="ghost" className="mb-6" onClick={() => setLocation("/marketplace")}>
        <ChevronLeft size={16} className="mr-2" /> Back to Marketplace
      </Button>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {/* Product Images */}
        <div>
          <div className="mb-4 rounded-lg overflow-hidden border">
            <img 
              src={productImages[activeImage]} 
              className="w-full h-96 object-cover object-center"
              alt={product.title} 
            />
          </div>
          
          {productImages.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {productImages.map((image, index) => (
                <div 
                  key={index}
                  className={`cursor-pointer rounded-md overflow-hidden border ${activeImage === index ? 'ring-2 ring-primary' : ''}`}
                  onClick={() => setActiveImage(index)}
                >
                  <img 
                    src={image} 
                    className="w-full h-24 object-cover object-center"
                    alt={`${product.title} - image ${index + 1}`} 
                  />
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Product Info */}
        <div>
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <h1 className="text-2xl md:text-3xl font-bold">{product.title}</h1>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={handleFavoriteProduct}
              >
                <Heart size={18} />
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                onClick={handleShareProduct}
              >
                <Share2 size={18} />
              </Button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {product.isService ? (
              <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">
                Service
              </Badge>
            ) : (
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                Product
              </Badge>
            )}
            
            {product.status && (
              <Badge variant="outline" className={
                product.status === "active" 
                  ? "bg-green-100 text-green-800 hover:bg-green-200"
                  : "bg-red-100 text-red-800 hover:bg-red-200"
              }>
                {product.status.charAt(0).toUpperCase() + product.status.slice(1)}
              </Badge>
            )}
            
            {product.rating && (
              <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
                <Star size={12} className="mr-1" /> {product.rating}
              </Badge>
            )}
          </div>
          
          <div className="mb-5">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold">₹{product.price.toLocaleString()}</span>
              {product.originalPrice && (
                <span className="text-lg line-through text-gray-400">₹{product.originalPrice.toLocaleString()}</span>
              )}
            </div>
            
            {product.originalPrice && (
              <span className="text-sm text-green-600">
                Save ₹{(product.originalPrice - product.price).toLocaleString()} ({Math.round((1 - product.price / product.originalPrice) * 100)}% off)
              </span>
            )}
          </div>
          
          <div className="mb-6 space-y-3 text-gray-600">
            <div className="flex items-start">
              <Tag size={16} className="mr-2 mt-1 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-700">Category</p>
                <p>{product.category}</p>
              </div>
            </div>
            
            {product.location && (
              <div className="flex items-start">
                <MapPin size={16} className="mr-2 mt-1 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Location</p>
                  <p>{product.location}</p>
                </div>
              </div>
            )}
            
            <div className="flex items-start">
              <Calendar size={16} className="mr-2 mt-1 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-700">Listed On</p>
                <p>{format(new Date(product.createdAt), 'PPP')}</p>
              </div>
            </div>
          </div>
          
          <Button className="w-full mb-4" size="lg" onClick={handleContactSeller}>
            <MessageSquare size={16} className="mr-2" /> Contact Seller
          </Button>
          
          {/* Seller Info */}
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold mb-3">Seller Information</h3>
              
              {isLoadingSeller ? (
                <div className="flex items-center space-x-3">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
              ) : seller ? (
                <Link href={`/profile/${product.sellerId}`}>
                  <a className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarImage src={seller.avatar || `https://ui-avatars.com/api/?name=${seller.username}`} />
                      <AvatarFallback>{seller.username?.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{seller.fullName || seller.username}</p>
                      <p className="text-sm text-gray-500">{seller.location || "Member"}</p>
                    </div>
                  </a>
                </Link>
              ) : (
                <p className="text-gray-500">Seller information not available</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Tabs for Description, Features, and Comments */}
      <Tabs defaultValue="description" className="mb-12">
        <TabsList className="mb-4">
          <TabsTrigger value="description">Description</TabsTrigger>
          {product.tags && product.tags.length > 0 && (
            <TabsTrigger value="features">Features</TabsTrigger>
          )}
          <TabsTrigger value="comments">
            Comments ({isLoadingComments ? "..." : comments?.length || 0})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="description" className="p-4">
          <div className="prose max-w-none">
            <p className="whitespace-pre-line">{product.description}</p>
          </div>
        </TabsContent>
        
        {product.tags && product.tags.length > 0 && (
          <TabsContent value="features" className="p-4">
            <ul className="list-disc ml-6 space-y-2">
              {product.tags.map((tag: string, index: number) => (
                <li key={index}>{tag}</li>
              ))}
            </ul>
          </TabsContent>
        )}
        
        <TabsContent value="comments" className="p-4">
          {isAuthenticated ? (
            <div className="mb-6">
              <Textarea
                placeholder="Write a comment..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="mb-2"
              />
              <Button onClick={handleSubmitComment}>Post Comment</Button>
            </div>
          ) : (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg text-center">
              <p className="mb-2">Please sign in to leave a comment</p>
              <Link href="/login">
                <Button variant="outline">Sign In</Button>
              </Link>
            </div>
          )}
          
          {isLoadingComments ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex space-x-3">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-full mb-1" />
                    <Skeleton className="h-3 w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : comments && comments.length > 0 ? (
            <div className="space-y-6">
              {comments.map((comment: any) => (
                <div key={comment.id} className="flex space-x-3">
                  <Avatar>
                    <AvatarImage src={`https://ui-avatars.com/api/?name=${comment.username || "U"}`} />
                    <AvatarFallback>{comment.username?.substring(0, 2).toUpperCase() || "U"}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{comment.username || "User"}</p>
                      <p className="text-xs text-gray-500">
                        {format(new Date(comment.createdAt), 'PPp')}
                      </p>
                    </div>
                    <p className="mt-1">{comment.content}</p>
                    <div className="mt-2">
                      <Button variant="ghost" size="sm" className="h-auto p-0">
                        <ThumbsUp size={14} className="mr-1" /> Like
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <MessageSquare size={48} className="mx-auto text-gray-300 mb-3" />
              <p className="text-gray-500">No comments yet. Be the first to comment!</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Similar Products Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6">Similar Products</h2>
        
        {isLoadingSimilar ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="bg-white overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <div className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-1/2 mb-3" />
                  <Skeleton className="h-5 w-1/4 mb-3" />
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-1/3" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : similarProducts && similarProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {similarProducts.map((product: any) => (
              <ProductCard
                key={product.id}
                id={product.id}
                title={product.title}
                price={product.price}
                originalPrice={product.originalPrice}
                category={product.category}
                location={product.location || "Online"}
                rating={product.rating}
                image={product.images ? product.images[0] : undefined}
                isNew={new Date(product.createdAt).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000}
                isService={product.isService}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-8 border rounded-lg">
            <ShoppingBag size={48} className="mx-auto text-gray-300 mb-3" />
            <p className="text-gray-500">No similar products found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetails;
